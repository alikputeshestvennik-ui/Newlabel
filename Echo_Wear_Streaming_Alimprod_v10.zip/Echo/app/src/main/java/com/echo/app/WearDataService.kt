package com.echo.app

import android.content.Context
import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class WearDataService : WearableListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val liveBacklog = java.util.ArrayDeque<ByteArray>()
    @Volatile private var liveStarting = false
    @Volatile private var liveActive = false
    @Volatile private var liveNodeId: String? = null
    private var liveAnswerBuffer = StringBuilder()

    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            WearBridge.ACTION_PATH -> handleCardAction(event)
            WearBridge.LIVE_CONTROL_PATH -> handleLiveControl(event)
        }
    }

    private fun handleCardAction(event: MessageEvent) {
        scope.launch {
            try {
                val o = JSONObject(String(event.data, Charsets.UTF_8))
                val id = o.getLong("id")
                when (o.getString("action")) {
                    "favorite" -> {
                        val db = EchoDb.get(this@WearDataService)
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().setFavorite(id, !card.favorite)
                    }
                    "delete" -> {
                        val db = EchoDb.get(this@WearDataService)
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().delete(id)
                        card.audioPath?.let { try { File(it).delete() } catch (_: Exception) {} }
                    }
                }
                WearBridge.syncCards(this@WearDataService, EchoDb.get(this@WearDataService).cards().all())
            } catch (_: Exception) { }
        }
    }

    private fun handleLiveControl(event: MessageEvent) {
        try {
            val action = JSONObject(String(event.data, Charsets.UTF_8)).optString("action")
            when (action) {
                "start" -> {
                    liveNodeId = event.sourceNodeId
                    startWatchLive(event.sourceNodeId)
                }
                "stop" -> stopWatchLive("Остановлено")
            }
        } catch (_: Exception) { }
    }

    private fun startWatchLive(nodeId: String) {
        if (liveActive || liveStarting) return
        liveStarting = true
        scope.launch {
            try {
                val context = LiveQaContext.build(this@WearDataService)
                val ready = LiveQA.start(
                    systemContext = context,
                    onAnswerChunk = { /* text-first watch version; phone keeps full audio path */ },
                    onSubtitleChunk = { text ->
                        synchronized(liveAnswerBuffer) {
                            liveAnswerBuffer.append(text)
                            sendLiveText(nodeId, "text", liveAnswerBuffer.toString())
                        }
                    },
                    onTurnComplete = {
                        sendLiveText(nodeId, "turn", "")
                        synchronized(liveAnswerBuffer) { liveAnswerBuffer.setLength(0) }
                    },
                    audioOutput = false
                )
                if (!ready) {
                    liveStarting = false
                    liveActive = false
                    sendLiveText(nodeId, "error", "Нет связи с Gemini")
                    return@launch
                }
                liveActive = true
                liveStarting = false
                synchronized(liveAnswerBuffer) { liveAnswerBuffer.setLength(0) }
                sendLiveText(nodeId, "ready", "Слушаю…")
                synchronized(liveBacklog) {
                    while (liveBacklog.isNotEmpty()) {
                        LiveQA.sendAudio(liveBacklog.removeFirst())
                    }
                }
            } catch (_: Exception) {
                liveStarting = false
                liveActive = false
                sendLiveText(nodeId, "error", "Не удалось запустить Gemini Live")
            }
        }
    }

    private fun stopWatchLive(reason: String) {
        val node = liveNodeId
        liveActive = false
        liveStarting = false
        synchronized(liveAnswerBuffer) { liveAnswerBuffer.setLength(0) }
        synchronized(liveBacklog) { liveBacklog.clear() }
        LiveQA.stop()
        if (node != null) sendLiveText(node, "stopped", reason)
        liveNodeId = null
    }

    override fun onChannelOpened(channel: ChannelClient.Channel) {
        when {
            channel.path.startsWith(WearBridge.AUDIO_PATH_PREFIX) -> openManualAudio(channel)
            channel.path.startsWith(WearBridge.LIVE_AUDIO_PATH_PREFIX) -> openLiveAudio(channel)
        }
    }

    private fun openManualAudio(channel: ChannelClient.Channel) {
        val createdAt = channel.path.substringAfterLast('/').toLongOrNull() ?: System.currentTimeMillis()
        val pcm = File(filesDir, "watch_${createdAt}.pcm")
        Wearable.getChannelClient(this).getInputStream(channel)
            .addOnSuccessListener { input ->
                Thread {
                    try {
                        val buffer = ByteArray(16 * 1024)
                        var segmentStart = createdAt
                        var segmentFile = pcm
                        var out = FileOutputStream(segmentFile)
                        var ok = false
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            out.write(buffer, 0, n)
                            ok = true
                            if (System.currentTimeMillis() - segmentStart >= MAX_SEGMENT_MS) {
                                out.flush(); out.close()
                                saveWatchCard(segmentStart, segmentFile)
                                segmentStart = System.currentTimeMillis()
                                segmentFile = File(filesDir, "watch_${segmentStart}.pcm")
                                out = FileOutputStream(segmentFile)
                            }
                        }
                        out.flush(); out.close()
                        if (ok && segmentFile.length() > 0) saveWatchCard(segmentStart, segmentFile)
                        else segmentFile.delete()
                    } catch (_: Exception) {
                        try { pcm.delete() } catch (_: Exception) {}
                    } finally {
                        try { input.close() } catch (_: Exception) {}
                        Wearable.getChannelClient(this).close(channel)
                    }
                }.start()
            }
    }

    private fun openLiveAudio(channel: ChannelClient.Channel) {
        Wearable.getChannelClient(this).getInputStream(channel)
            .addOnSuccessListener { input ->
                Thread {
                    try {
                        val buffer = ByteArray(3200) // 100 ms @ 16 kHz
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            val bytes = if (n == buffer.size) buffer.copyOf() else buffer.copyOf(n)
                            if (liveActive && LiveQA.isConnected()) {
                                LiveQA.sendAudio(bytes)
                            } else {
                                synchronized(liveBacklog) {
                                    if (liveBacklog.size >= 20) liveBacklog.removeFirst()
                                    liveBacklog.addLast(bytes)
                                }
                            }
                        }
                    } catch (_: Exception) { }
                    finally {
                        try { input.close() } catch (_: Exception) {}
                        Wearable.getChannelClient(this).close(channel)
                    }
                }.start()
            }
    }

    private fun sendLiveText(nodeId: String, kind: String, text: String) {
        scope.launch {
            try {
                val payload = JSONObject().put("kind", kind).put("text", text)
                    .toString().toByteArray(Charsets.UTF_8)
                Wearable.getMessageClient(this@WearDataService)
                    .sendMessage(nodeId, WearBridge.LIVE_TEXT_PATH, payload)
                    .await()
            } catch (_: Exception) { }
        }
    }

    private fun saveWatchCard(createdAt: Long, file: File) {
        scope.launch {
            try {
                val db = EchoDb.get(this@WearDataService)
                db.cards().insert(SpeechCard(
                    createdAt = createdAt,
                    text = "Ожидает отправки",
                    audioPath = file.absolutePath,
                    pendingUpload = true
                ))
                WearBridge.syncCards(this@WearDataService, db.cards().all())
            } catch (_: Exception) { }
        }
    }

    override fun onDestroy() {
        LiveQA.stop()
        scope.coroutineContext.cancel()
        super.onDestroy()
    }

    companion object {
        private const val MAX_SEGMENT_MS = 29L * 60L * 1000L
    }
}
