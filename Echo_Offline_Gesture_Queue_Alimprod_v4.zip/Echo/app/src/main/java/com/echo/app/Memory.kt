package com.echo.app

import android.content.Context
import androidx.room.*

@Entity(tableName="speech_cards", indices=[Index(value=["createdAt"])])
data class SpeechCard(
    @PrimaryKey(autoGenerate=true) val id:Long=0,
    val createdAt:Long,
    val text:String,
    val audioPath:String?,
    val favorite:Boolean=false,
    val pendingUpload:Boolean=false
)

// Unique on (category, subject, fact) so the daily extractor can re-insert the
// same recurring fact day after day without piling up duplicates --
// OnConflictStrategy.IGNORE below just keeps the first one.
@Entity(tableName="long_term_memory", indices=[Index(value=["category","subject","fact"], unique=true)])
data class MemoryFact(@PrimaryKey(autoGenerate=true) val id:Long=0,val category:String,val subject:String,val fact:String,val sourceDate:String)

// One row per calendar day. isFinal marks the 22:00 run -- after that the day
// is "locked" and won't be regenerated again until the next calendar day.
// Keeping every day (not just today's) is what lets Live Q&A answer questions
// about the user's history over time.
@Entity(tableName="day_summaries", indices=[Index(value=["date"], unique=true)])
data class DaySummaryEntry(@PrimaryKey(autoGenerate=true) val id:Long=0,val date:String,val text:String,val generatedAt:Long,val isFinal:Boolean=false)

@Dao interface CardDao {
    @Insert suspend fun insert(c:SpeechCard):Long
    @Query("SELECT * FROM speech_cards ORDER BY createdAt DESC") suspend fun all():List<SpeechCard>
    @Query("SELECT * FROM speech_cards WHERE createdAt >= :since ORDER BY createdAt ASC") suspend fun since(since:Long):List<SpeechCard>
    @Query("UPDATE speech_cards SET text = :text WHERE id = :id") suspend fun updateText(id:Long,text:String)
    @Query("SELECT * FROM speech_cards WHERE id = :id LIMIT 1") suspend fun byId(id:Long):SpeechCard?
    @Query("DELETE FROM speech_cards WHERE id = :id") suspend fun delete(id:Long)
    @Query("UPDATE speech_cards SET favorite = :favorite WHERE id = :id") suspend fun setFavorite(id:Long,favorite:Boolean)
    @Query("UPDATE speech_cards SET text = :text, pendingUpload = :pending WHERE id = :id") suspend fun updateTranscription(id:Long,text:String,pending:Boolean)
}

@Dao interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertAll(x:List<MemoryFact>)
    @Query("SELECT * FROM long_term_memory ORDER BY category,subject") suspend fun all():List<MemoryFact>
    @Query("DELETE FROM long_term_memory") suspend fun clear()
}

@Dao interface DaySummaryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e:DaySummaryEntry)
    @Query("SELECT * FROM day_summaries WHERE date = :date LIMIT 1") suspend fun forDate(date:String):DaySummaryEntry?
    @Query("SELECT * FROM day_summaries ORDER BY date ASC") suspend fun all():List<DaySummaryEntry>
}

@Database(entities=[SpeechCard::class,MemoryFact::class,DaySummaryEntry::class],version=3,exportSchema=false)
abstract class EchoDb:RoomDatabase(){
    abstract fun cards():CardDao
    abstract fun memory():MemoryDao
    abstract fun daySummaries():DaySummaryDao
    companion object {
        @Volatile private var I:EchoDb?=null
        fun get(c:Context)=I?:synchronized(this){I?:Room.databaseBuilder(c.applicationContext,EchoDb::class.java,"echo.db").fallbackToDestructiveMigration().build().also{I=it}}
    }
}
