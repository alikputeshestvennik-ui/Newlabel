package com.echo.app.wear

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

private class EdgeSwipeLayout(context: Context) : FrameLayout(context) {
    var onPullFromTop: (() -> Unit)? = null
    private var downY = 0f
    private var tracking = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = ev.y
                tracking = ev.y <= dp(104f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (tracking && ev.y - downY > dp(48f)) {
                    tracking = false
                    onPullFromTop?.invoke()
                    return true
                }
            }
            MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_UP -> tracking = false
        }
        return false
    }

    private fun dp(v: Float): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()
}

class WatchMainActivity : Activity() {
    private lateinit var root: EdgeSwipeLayout
    private lateinit var pages: FrameLayout
    private lateinit var recordPage: FrameLayout
    private lateinit var cardsPage: FrameLayout
    private lateinit var recordRing: WatchEchoRingView
    private lateinit var status: TextView
    private lateinit var cardsList: LinearLayout
    private lateinit var sourceButton: ImageButton
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var recording = false
    @Volatile private var remoteRecording = false
    private var remoteRecordingSource = ""
    private var audioSource = "watch"
    private var showingCards = false
    private var cards: List<WatchCard> = emptyList()

    private val recordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            when (intent.getStringExtra("state")) {
                "started" -> {
                    recording = true
                    remoteRecording = false
                    recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                    recordRing.start()
                    status.text = "Запись с часов · тап — стоп"
                    updateSourceButton()
                }
                "level" -> {
                    if (recording) recordRing.setAudioLevel(intent.getFloatExtra("level", 0f))
                }
                "stopped" -> {
                    recording = false
                    remoteRecording = false
                    remoteRecordingSource = ""
                    getSharedPreferences("recording", Context.MODE_PRIVATE)
                        .edit().putBoolean("remoteActive", false).apply()
                    recordRing.setAudioLevel(0f)
                    recordRing.setMode(WatchEchoRingView.MODE_CLOSING)
                    handler.postDelayed({
                        recordRing.stop()
                        recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
                    }, 260)
                    status.text = "Передано телефону · готово"
                    updateSourceButton()
                    loadCards()
                }
                "error" -> {
                    recording = false
                    recordRing.stop()
                    status.text = intent.getStringExtra("message") ?: "Ошибка записи"
                    updateSourceButton()
                }
            }
        }
    }

    private val remoteRecordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            remoteRecording = intent.getBooleanExtra("active", false)
            remoteRecordingSource = intent.getStringExtra("source") ?: ""
            getSharedPreferences("recording", Context.MODE_PRIVATE).edit()
                .putBoolean("remoteActive", remoteRecording)
                .putString("remoteSource", remoteRecordingSource)
                .apply()

            if (remoteRecording && !WatchRecordingService.isRunning) {
                recording = true
                recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                recordRing.start()
                status.text = if (remoteRecordingSource == "phone") {
                    "Запись на телефоне · тап — стоп"
                } else {
                    "Идёт запись · тап — стоп"
                }
            } else if (!remoteRecording && !WatchRecordingService.isRunning) {
                recording = false
                recordRing.setAudioLevel(0f)
                recordRing.stop()
                recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
                status.text = "Тап — запись · свайп сверху — карточки"
            }
            updateSourceButton()
        }
    }

    data class WatchCard(
        val id: Long,
        val text: String,
        val date: String,
        val time: String,
        val favorite: Boolean,
        val fromWatch: Boolean,
        val pendingUpload: Boolean
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioSource = getSharedPreferences("watch_settings", MODE_PRIVATE)
            .getString("audioSource", "watch") ?: "watch"

        buildUi()

        val flags = if (android.os.Build.VERSION.SDK_INT >= 33) {
            Context.RECEIVER_NOT_EXPORTED
        } else 0
        ContextCompat.registerReceiver(this, recordingReceiver,
            IntentFilter(WatchRecordingService.ACTION_STATE), flags)
        ContextCompat.registerReceiver(this, remoteRecordingReceiver,
            IntentFilter(WatchDataService.ACTION_REMOTE_RECORDING), flags)

        syncStateFromPrefs()
        loadCards()
        handler.post(uiTicker)
    }

    override fun onResume() {
        super.onResume()
        syncStateFromPrefs()
        loadCards()
    }

    override fun onDestroy() {
        handler.removeCallbacks(uiTicker)
        try { unregisterReceiver(recordingReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(remoteRecordingReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private val uiTicker = object : Runnable {
        override fun run() {
            if (isFinishing) return
            syncStateFromPrefs()
            if (showingCards) loadCards()
            handler.postDelayed(this, 350L)
        }
    }

    private fun syncStateFromPrefs() {
        val local = WatchRecordingService.isRunning
        val remote = getSharedPreferences("recording", MODE_PRIVATE)
            .getBoolean("remoteActive", false)
        val source = getSharedPreferences("recording", MODE_PRIVATE)
            .getString("remoteSource", "") ?: ""

        if (local) {
            recording = true
            remoteRecording = false
            status.text = "Запись с часов · тап — стоп"
            updateSourceButton()
        } else if (remote) {
            val changed = !remoteRecording || remoteRecordingSource != source || !recording
            remoteRecording = true
            remoteRecordingSource = source
            recording = true
            if (changed) {
                recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                recordRing.start()
                status.text = if (source == "phone") {
                    "Запись на телефоне · тап — стоп"
                } else {
                    "Запись · тап — стоп"
                }
            }
            updateSourceButton()
        } else if (remoteRecording && !local) {
            remoteRecording = false
            recording = false
            recordRing.stop()
            recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
            status.text = "Тап — запись · свайп сверху — карточки"
            updateSourceButton()
        }
    }

    private fun dp(value: Float): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun buildUi() {
        root = EdgeSwipeLayout(this).apply {
            setBackgroundColor(Color.parseColor("#05060A"))
        }
        pages = FrameLayout(this)
        root.addView(pages, FrameLayout.LayoutParams(-1, -1))

        recordPage = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#05060A"))
        }
        cardsPage = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#05060A"))
        }
        pages.addView(recordPage, FrameLayout.LayoutParams(-1, -1))
        pages.addView(cardsPage, FrameLayout.LayoutParams(-1, -1))

        buildRecordPage()
        buildCardsPage()

        cardsPage.visibility = View.INVISIBLE
        cardsPage.translationY = resources.displayMetrics.heightPixels.toFloat()

        root.onPullFromTop = { switchScreen() }
        setContentView(root)
        updateSourceButton()
    }

    private fun buildRecordPage() {
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18f), dp(14f), dp(18f), 0)
        }

        sourceButton = ImageButton(this).apply {
            background = rounded(Color.TRANSPARENT, 50f)
            setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(Color.WHITE)
            contentDescription = "Источник звука"
            setOnClickListener {
                if (recording || remoteRecording) return@setOnClickListener
                audioSource = if (audioSource == "watch") "phone" else "watch"
                getSharedPreferences("watch_settings", MODE_PRIVATE).edit()
                    .putString("audioSource", audioSource).apply()
                updateSourceButton()
                performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
            }
        }
        top.addView(sourceButton, LinearLayout.LayoutParams(dp(56f), dp(52f)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, dp(46f), 1f))
        top.addView(TextView(this).apply {
            text = "СВАЙП СВЕРХУ"
            textSize = 8.5f
            setTextColor(Color.parseColor("#596274"))
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }, LinearLayout.LayoutParams(dp(110f), dp(46f)))

        recordPage.addView(top, FrameLayout.LayoutParams(-1, dp(64f), Gravity.TOP))

        recordRing = WatchEchoRingView(this).apply {
            setOnClickListener {
                if (WatchRecordingService.isRunning) {
                    stopRecording()
                } else if (remoteRecording) {
                    WatchDataService.sendRecordingStop(this@WatchMainActivity)
                } else {
                    startRecording()
                }
            }
            contentDescription = "Запись"
        }
        recordPage.addView(
            recordRing,
            FrameLayout.LayoutParams(dp(190f), dp(190f), Gravity.CENTER)
        )

        status = TextView(this).apply {
            text = "Тап — запись · свайп сверху — карточки"
            textSize = 11f
            setTextColor(Color.parseColor("#7A8499"))
            gravity = Gravity.CENTER
        }
        val statusLp = FrameLayout.LayoutParams(-1, dp(40f), Gravity.BOTTOM)
        statusLp.leftMargin = dp(12f)
        statusLp.rightMargin = dp(12f)
        statusLp.bottomMargin = dp(14f)
        recordPage.addView(status, statusLp)
    }

    private fun buildCardsPage() {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14f), dp(12f), dp(12f), dp(4f))
        }
        header.addView(TextView(this).apply {
            text = "КАРТОЧКИ"
            textSize = 10f
            setTextColor(Color.parseColor("#596274"))
            letterSpacing = 0.12f
        }, LinearLayout.LayoutParams(0, dp(40f), 1f))
        header.addView(TextView(this).apply {
            text = "↓  запись"
            textSize = 9f
            setTextColor(Color.parseColor("#596274"))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(90f), dp(40f)))

        // The cards header is a dedicated, reliable pull target. This makes the
        // reverse transition work even when the ScrollView owns the rest of the
        // page's touch stream.
        var headerDownY = 0f
        var headerSwitched = false
        header.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    headerDownY = event.y
                    headerSwitched = false
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_MOVE -> {
                    if (event.actionMasked == MotionEvent.ACTION_MOVE &&
                        !headerSwitched && event.y - headerDownY > dp(48f)) {
                        headerSwitched = true
                        switchScreen()
                        true
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        true
                    } else true
                }
                else -> true
            }
        }

        cardsPage.addView(header, FrameLayout.LayoutParams(-1, dp(56f), Gravity.TOP))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_ALWAYS
        }
        cardsList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8f), dp(6f), dp(8f), dp(18f))
        }
        scroll.addView(cardsList, ViewGroup.LayoutParams(-1, -2))
        val lp = FrameLayout.LayoutParams(-1, -1)
        lp.topMargin = dp(56f)
        cardsPage.addView(scroll, lp)
    }

    private fun updateSourceButton() {
        if (!::sourceButton.isInitialized) return
        sourceButton.setImageResource(
            if (audioSource == "watch") R.drawable.ic_source_watch
            else R.drawable.ic_source_phone
        )
        sourceButton.alpha = if (recording || remoteRecording) 0.3f else 0.92f
        sourceButton.isEnabled = !(recording || remoteRecording)
    }

    private fun switchScreen() {
        val height = root.height.coerceAtLeast(resources.displayMetrics.heightPixels)
        val outgoing = if (showingCards) cardsPage else recordPage
        val incoming = if (showingCards) recordPage else cardsPage
        showingCards = !showingCards

        incoming.visibility = View.VISIBLE
        incoming.translationY = if (showingCards) height.toFloat() else -height.toFloat()
        incoming.alpha = 0.96f
        outgoing.animate().cancel()
        incoming.animate().cancel()

        outgoing.animate()
            .translationY(if (showingCards) -height.toFloat() else height.toFloat())
            .alpha(0.92f)
            .setDuration(330)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.7f))
            .start()

        incoming.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(360)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.7f))
            .withEndAction {
                outgoing.visibility = View.INVISIBLE
                outgoing.translationY = 0f
                loadCards()
            }
            .start()
    }

    private fun loadCards() {
        if (!::cardsList.isInitialized) return
        val json = getSharedPreferences("watch", MODE_PRIVATE)
            .getString("cards", "[]") ?: "[]"
        val parsed = mutableListOf<WatchCard>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                parsed += WatchCard(
                    o.getLong("id"),
                    o.getString("text"),
                    o.optString("date", ""),
                    o.optString("time", ""),
                    o.getBoolean("favorite"),
                    o.optBoolean("fromWatch", false),
                    o.optBoolean("pendingUpload", false)
                )
            }
        } catch (_: Exception) {}
        cards = parsed
        cardsList.removeAllViews()

        if (cards.isEmpty()) {
            cardsList.addView(TextView(this).apply {
                text = "Нет карточек"
                textSize = 13f
                setTextColor(Color.parseColor("#5A6478"))
                gravity = Gravity.CENTER
                setPadding(0, dp(42f), 0, dp(42f))
            })
            return
        }

        cards.forEach { card ->
            val cardBox = FrameLayout(this).apply {
                background = rounded(Color.rgb(20, 20, 23), 24f)
                setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
                setOnLongClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "favorite")
                    handler.postDelayed({ loadCards() }, 180)
                    true
                }
            }

            val text = TextView(this).apply {
                val prefix = if (card.favorite) "★ " else ""
                val source = if (card.fromWatch) " · с часов" else ""
                this.text = "$prefix${card.text}\n${card.date} · ${card.time}$source"
                textSize = 12.5f
                setTextColor(Color.WHITE)
                setLineSpacing(0f, 1.18f)
                setPadding(0, 0, if (card.pendingUpload) dp(40f) else 0, 0)
            }
            cardBox.addView(text, FrameLayout.LayoutParams(-1, -2))

            if (card.pendingUpload) {
                val transcribe = TextView(this).apply {
                    setText("↗")
                    textSize = 17f
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#00E5C3"))
                    background = rounded(Color.TRANSPARENT, 50f)
                    contentDescription = "Отправить на расшифровку"
                    setOnClickListener {
                        isEnabled = false
                        alpha = 0.35f
                        WatchDataService.sendAction(this@WatchMainActivity, card.id, "transcribe")
                        Toast.makeText(this@WatchMainActivity, "Отправляю на расшифровку…", Toast.LENGTH_SHORT).show()
                    }
                }
                cardBox.addView(transcribe, FrameLayout.LayoutParams(dp(40f), dp(40f), Gravity.END or Gravity.CENTER_VERTICAL))
            }

            val deleteBg = View(this@WatchMainActivity).apply {
                setBackgroundColor(Color.parseColor("#B91C1C"))
                alpha = 0f
                scaleX = 0f
                pivotY = 0.5f
            }
            val cardHost = FrameLayout(this@WatchMainActivity).apply {
                clipChildren = false
                clipToPadding = false
            }
            cardHost.addView(deleteBg, FrameLayout.LayoutParams(-1, -1, Gravity.END))
            cardHost.addView(cardBox, FrameLayout.LayoutParams(-1, -2))

            attachCardSwipe(cardBox, card.id, deleteBg)

            cardsList.addView(cardHost, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(8f)
            })
        }
    }

    private fun attachCardSwipe(cardView: View, id: Long, deleteBg: View) {
        var downX = 0f
        var downY = 0f
        var moved = false
        var longPressed = false
        val longPress = Runnable {
            if (!moved) {
                longPressed = true
                cardView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                WatchDataService.sendAction(this@WatchMainActivity, id, "favorite")
                handler.postDelayed({ loadCards() }, 180)
            }
        }
        cardView.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    longPressed = false
                    handler.removeCallbacks(longPress)
                    handler.postDelayed(longPress, 520L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (abs(dx) > dp(12f) || abs(dy) > dp(12f)) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (abs(dx) > dp(12f) && abs(dx) > abs(dy) * 1.25f && dx < 0) {
                        v.translationX = dx.coerceAtLeast(-v.width.toFloat())
                        val progress = (-v.translationX / v.width.coerceAtLeast(1)).coerceIn(0f, 1f)
                        deleteBg.pivotX = deleteBg.width.toFloat()
                        deleteBg.scaleX = progress
                        deleteBg.alpha = (0.18f + progress * 0.72f).coerceAtMost(0.9f)
                        v.alpha = 1f - progress * 0.18f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    val dx = event.rawX - downX
                    if (dx < -v.width * 0.52f && !longPressed) {
                        deleteBg.animate().scaleX(1f).alpha(0.92f).setDuration(120).start()
                        v.animate()
                            .translationX(-v.width.toFloat())
                            .alpha(0f)
                            .setDuration(220)
                            .withEndAction {
                                WatchDataService.sendAction(this@WatchMainActivity, id, "delete")
                                handler.postDelayed({ loadCards() }, 260)
                            }.start()
                    } else {
                        deleteBg.animate().scaleX(0f).alpha(0f).setDuration(140).start()
                        v.animate().translationX(0f).alpha(1f).setDuration(180)
                            .setInterpolator(android.view.animation.DecelerateInterpolator(1.7f)).start()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun startRecording() {
        if (remoteRecording || WatchRecordingService.isRunning) return

        if (audioSource == "phone") {
            recording = true
            remoteRecording = true
            remoteRecordingSource = "phone"
            status.text = "Запуск записи на телефоне…"
            recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
            recordRing.start()
            updateSourceButton()
            WatchDataService.sendRecordingStart(this)
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }

        recording = true
        val intent = android.content.Intent(this, WatchRecordingService::class.java).apply {
            action = WatchRecordingService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
        recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
        recordRing.start()
        status.text = "Подключаюсь к телефону…"
        updateSourceButton()
    }

    private fun stopRecording() {
        if (WatchRecordingService.isRunning) {
            recording = false
            ContextCompat.startForegroundService(this, android.content.Intent(this, WatchRecordingService::class.java).apply {
                action = WatchRecordingService.ACTION_STOP
            })
        } else if (remoteRecording) {
            WatchDataService.sendRecordingStop(this)
        }
    }
}

private class WatchEchoRingView(context: Context) : View(context) {
    companion object {
        const val MODE_CONNECTING = 0
        const val MODE_LISTENING = 1
        const val MODE_RESPONDING = 2
        const val MODE_CLOSING = 3
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = android.graphics.BlurMaskFilter(14f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val motePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val coreGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = android.graphics.BlurMaskFilter(8f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

    private var phase = 0f
    private var running = false
    private var mode = MODE_CONNECTING
    @Volatile private var targetAudio = 0f
    private var audio = 0f
    private var modeBlend = 0f
    private var targetModeBlend = 0f

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.038f + audio * 0.09f
            audio += (targetAudio - audio) * 0.22f
            modeBlend += (targetModeBlend - modeBlend) * 0.16f
            invalidate()
            postOnAnimation(this)
        }
    }

    init { setLayerType(LAYER_TYPE_HARDWARE, null) }

    fun setAudioLevel(level: Float) { targetAudio = level.coerceIn(0f, 1f) }
    fun setMode(m: Int) {
        mode = m
        targetModeBlend = if (m == MODE_RESPONDING) 1f else 0f
        invalidate()
    }
    fun start() {
        running = true
        removeCallbacks(frame)
        postOnAnimation(frame)
    }
    fun stop() {
        running = false
        targetAudio = 0f
        audio = 0f
        removeCallbacks(frame)
        invalidate()
    }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * x).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * x).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val size = min(width, height).toFloat()
        if (size <= 0f) return

        val response = modeBlend
        val breath = 0.5f + 0.5f * sin(phase * 1.35f)
        val voice = audio * (0.70f + 0.30f * breath)
        val energy = (voice + response * 0.18f).coerceIn(0f, 1f)

        val teal = Color.parseColor("#00E5C3")
        val violet = Color.parseColor("#A78BFA")
        val accent = mix(teal, violet, response)
        val soft = Color.parseColor("#E8F8F6")

        val baseR = size * 0.30f
        val r = baseR * (1f + 0.04f * breath + 0.11f * voice + 0.03f * response)

        haloPaint.color = accent
        haloPaint.strokeWidth = size * (0.09f + 0.06f * energy)
        haloPaint.alpha = (30 + 105 * energy).toInt().coerceAtMost(180)
        canvas.drawCircle(cx, cy, r * 1.07f, haloPaint)

        for (i in 0 until 3) {
            val wp = (phase * 0.52f + i * 0.82f) % 6.2832f
            val expand = 0.5f + 0.5f * ((sin(wp) + 1f) * 0.5f)
            val wr = r * (0.74f + 0.34f * expand + 0.05f * voice)
            wavePaint.color = accent
            wavePaint.strokeWidth = size * (0.006f + 0.003f * energy)
            wavePaint.alpha = ((52 + 68 * energy) * (1f - expand * 0.52f)).toInt().coerceIn(0, 150)
            canvas.drawCircle(cx, cy, wr, wavePaint)
        }

        ringPaint.color = mix(soft, accent, 0.38f + 0.42f * response)
        ringPaint.strokeWidth = size * (0.055f + 0.02f * voice)
        ringPaint.alpha = 232
        canvas.drawCircle(cx, cy, r, ringPaint)

        ringPaint.color = accent
        ringPaint.strokeWidth = size * (0.012f + 0.007f * energy)
        ringPaint.alpha = (158 + 72 * energy).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.048f, ringPaint)

        motePaint.color = accent
        for (i in 0 until 5) {
            val speed = 0.48f + i * 0.11f + energy * 0.3f
            val a = phase * speed * (if (i % 2 == 0) 1f else -1f) + i * 1.2566f
            val orbit = r * (0.79f + 0.07f * sin(phase * 1.15f + i))
            val px = cx + kotlin.math.cos(a.toDouble()).toFloat() * orbit
            val py = cy + kotlin.math.sin(a.toDouble()).toFloat() * orbit
            val moteR = size * (0.011f + 0.009f * energy)
            motePaint.alpha = (90 + 135 * energy).toInt().coerceAtMost(235)
            canvas.drawCircle(px, py, moteR, motePaint)
            motePaint.alpha = (30 + 48 * energy).toInt()
            canvas.drawCircle(px, py, moteR * 2.0f, motePaint)
        }

        val pulse = size * (0.048f + 0.055f * voice + 0.022f * response + 0.015f * breath)
        coreGlowPaint.color = accent
        coreGlowPaint.alpha = (60 + 140 * energy).toInt().coerceAtMost(220)
        canvas.drawCircle(cx, cy, pulse * 1.55f, coreGlowPaint)

        corePaint.color = mix(soft, accent, 0.25f + 0.55f * response)
        corePaint.alpha = (170 + 75 * energy).toInt().coerceAtMost(250)
        canvas.drawCircle(cx, cy, pulse * (0.28f + 0.20f * energy), corePaint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }
}
