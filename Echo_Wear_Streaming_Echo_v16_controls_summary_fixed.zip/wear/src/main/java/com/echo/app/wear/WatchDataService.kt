package com.echo.app.wear

import android.content.Context
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await

class WatchDataService : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        events.forEach { event ->
            if (event.type == DataEvent.TYPE_CHANGED && event.dataItem.uri.path == "/echo/cards") {
                val json = DataMapItem.fromDataItem(event.dataItem).dataMap.getString("json", "[]")
                getSharedPreferences("watch", Context.MODE_PRIVATE).edit()
                    .putString("cards", json)
                    .apply()
            }
        }
    }

    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            RECORDING_STATE_PATH -> handleRecordingState(event)
            RECORDING_CONTROL_PATH -> handleRecordingControl(event)
        }
    }

    private fun handleRecordingState(event: MessageEvent) {
        try {
            val o = JSONObject(String(event.data, Charsets.UTF_8))
            val active = o.optBoolean("active", false)
            val source = o.optString("source", "phone")
            getSharedPreferences("recording", Context.MODE_PRIVATE).edit()
                .putBoolean("remoteActive", active)
                .putString("remoteSource", source)
                .apply()
            sendBroadcast(
                android.content.Intent(ACTION_REMOTE_RECORDING)
                    .setPackage(packageName)
                    .putExtra("active", active)
                    .putExtra("source", source)
            )
        } catch (_: Exception) { }
    }

    private fun handleRecordingControl(event: MessageEvent) {
        try {
            val o = JSONObject(String(event.data, Charsets.UTF_8))
            if (o.optString("action") == "stop") {
                stopService(
                    android.content.Intent(this, WatchRecordingService::class.java)
                )
            }
        } catch (_: Exception) { }
    }

    companion object {
        const val CARDS_PATH = "/echo/cards"
        const val ACTION_PATH = "/echo/card/action"
        const val RECORDING_STATE_PATH = "/echo/recording/state"
        const val RECORDING_CONTROL_PATH = "/echo/recording/control"
        const val ACTION_REMOTE_RECORDING = "com.echo.app.wear.REMOTE_RECORDING_STATE"

        fun sendRecordingState(context: Context, active: Boolean, source: String) {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject().apply {
                            put("active", active)
                            put("source", source)
                            put("at", System.currentTimeMillis())
                        }.toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context)
                            .sendMessage(node.id, RECORDING_STATE_PATH, payload)
                            .await()
                    } catch (_: Exception) { }
                }
            }.start()
        }

        fun sendRecordingStart(context: Context, source: String = "watch") {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject()
                            .put("action", "start")
                            .put("source", source)
                            .toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context)
                            .sendMessage(node.id, RECORDING_CONTROL_PATH, payload)
                            .await()
                    } catch (_: Exception) { }
                }
            }.start()
        }

        fun sendRecordingStop(context: Context) {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject().put("action", "stop").toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context)
                            .sendMessage(node.id, RECORDING_CONTROL_PATH, payload)
                            .await()
                    } catch (_: Exception) { }
                }
            }.start()
        }

        fun sendAction(context: Context, id: Long, action: String) {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject().apply {
                            put("id", id)
                            put("action", action)
                        }.toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context).sendMessage(node.id, ACTION_PATH, payload).await()
                    } catch (_: Exception) { }
                }
            }.start()
        }
    }
}
