package com.echo.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    private lateinit var cards: LinearLayout
    private lateinit var contentHost: FrameLayout
    private lateinit var brandLogo: ImageView
    private lateinit var searchField: EditText
    private lateinit var fabButton: ImageView
    private lateinit var ringView: EchoRingView
    private lateinit var fabContainer: FrameLayout
    private lateinit var pageContainer: FrameLayout
    private var selectedTab = 0
    private var currentSearchQuery = ""
    private val navIcons = mutableListOf<ImageView>()
    private var qaPanel: View? = null
    private var isListening = false

    // Quiet dark palette
    private val bg = Color.parseColor("#07080B")
    private val panel = Color.parseColor("#12141A")
    private val panelElevated = Color.parseColor("#1A1D26")
    private val stroke = Color.parseColor("#2A2E3A")
    private val primaryText = Color.parseColor("#F2F4F8")
    private val muted = Color.parseColor("#8B91A0")
    private val accent = Color.parseColor("#6EA8FF")
    private val accentSoft = Color.parseColor("#1A2A44")
    private val danger = Color.parseColor("#FF3B4A")
    private val success = Color.parseColor("#5CDBA0")
    private val navBarColor = Color.argb(180, 22, 24, 30)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }

        isListening = getPreferences(0).getBoolean("running", false)
        buildUi()
        refreshLoop()
        DigestAlarmReceiver.schedule(this)

        lifecycleScope.launch {
            MemoryExtraction.runIfDue(this@MainActivity)
            if (selectedTab == 2) loadMemory()
            else if (selectedTab == 1) loadAnalysis()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(
        color: Int,
        radius: Int = 18,
        strokeColor: Int? = null,
        strokeWidthDp: Int = 1
    ): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) {
                setStroke(dp(strokeWidthDp), strokeColor)
            }
        }

    private fun label(value: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            includeFontPadding = false
            letterSpacing = 0.01f
        }

    private fun sectionTitle(value: String): TextView =
        label(value.uppercase(Locale.getDefault()), 11f, accent).apply {
            letterSpacing = 0.12f
            setPadding(dp(4), dp(4), dp(4), dp(8))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }

    private fun primaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            letterSpacing = 0.04f
            background = rounded(accent, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun secondaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(primaryText)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = rounded(panelElevated, 14, stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(bg)
        }

        // Main vertical stack
        val stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Top inset so logo clears status bar / clock
            val topInset = statusBarInset()
            setPadding(dp(20), topInset + dp(8), dp(20), 0)
        }

        // —— Premium header: transparent logo + compact search action ——
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        brandLogo = ImageView(this).apply {
            setImageResource(R.drawable.echo_logo_premium)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Эхо"
        }
        header.addView(brandLogo, LinearLayout.LayoutParams(dp(112), dp(52)))

        val headerSpacer = Space(this)
        header.addView(headerSpacer, LinearLayout.LayoutParams(0, dp(52), 1f))

        val searchButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            contentDescription = "Поиск"
            background = rounded(Color.TRANSPARENT, 50)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(primaryText)
            setOnClickListener {
                if (searchField.visibility == View.VISIBLE) {
                    searchField.text?.clear()
                    searchField.visibility = View.GONE
                    currentSearchQuery = ""
                    loadCards()
                } else {
                    searchField.visibility = View.VISIBLE
                    searchField.requestFocus()
                    val imm = getSystemService(android.view.inputmethod.InputMethodManager::class.java)
                    imm?.showSoftInput(searchField, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                }
            }
        }
        header.addView(searchButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply {
            marginEnd = dp(2)
        })

        stack.addView(header, LinearLayout.LayoutParams(-1, dp(56)).apply {
            bottomMargin = dp(2)
        })

        searchField = EditText(this).apply {
            hint = ""
            setHintTextColor(Color.TRANSPARENT)
            setTextColor(primaryText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.argb(150, 18, 24, 34), 18, Color.argb(100, 110, 168, 255))
            visibility = View.GONE
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s?.toString()?.trim() ?: ""
                    currentSearchQuery = query
                    filterCards(query)
                }
            })
        }
        stack.addView(searchField, LinearLayout.LayoutParams(-1, dp(46)).apply {
            bottomMargin = dp(4)
        })

        // —— Swipeable page host ——
        pageContainer = FrameLayout(this)
        contentHost = FrameLayout(this)
        cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(180))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(cards)
        }
        contentHost.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        pageContainer.addView(contentHost, FrameLayout.LayoutParams(-1, -1))
        attachPageSwipe(pageContainer)
        stack.addView(pageContainer, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(stack, FrameLayout.LayoutParams(-1, -1))

        // —— Airy premium recorder button: transparent artwork changes with state ——
        (root as? ViewGroup)?.clipChildren = false
        fabContainer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        ringView = EchoRingView(this).apply {
            visibility = View.INVISIBLE
            alpha = 0f
        }
        fabButton = ImageView(this).apply {
            setImageResource(R.drawable.echo_idle)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Начать запись"
            elevation = dp(10).toFloat()
        }
        fabContainer.addView(ringView, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        fabContainer.addView(fabButton, FrameLayout.LayoutParams(dp(148), dp(148), Gravity.CENTER))
        attachFabGesture(fabContainer)
        val fabParams = FrameLayout.LayoutParams(dp(160), dp(160), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabParams.bottomMargin = dp(36) + navBarInset()
        root.addView(fabContainer, fabParams)
        fabContainer.elevation = dp(24).toFloat()

        // —— Thin translucent nav bar ——
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10) + navBarInset())
            // Frosted bar: translucent gray (true backdrop-blur needs API 31
            // window blur which is device-dependent; alpha keeps content readable).
            setBackgroundColor(navBarColor)
            elevation = dp(8).toFloat()
        }

        navIcons.clear()
        listOf(
            R.drawable.ic_nav_feed to 0,
            R.drawable.ic_nav_analysis to 1,
            R.drawable.ic_nav_memory to 2
        ).forEach { (iconRes, tab) ->
            val iv = ImageView(this).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setColorFilter(muted)
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { selectTab(tab, animate = true) }
            }
            navIcons.add(iv)
            nav.addView(iv, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        root.addView(nav, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        applyFabListeningState(animated = false)
        selectTab(0, animate = false)
    }

    private fun statusBarInset(): Int {
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(28)
    }

    private fun navBarInset(): Int {
        val resId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(8)
    }

    private fun attachPageSwipe(target: View) {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float
            ): Boolean {
                if (qaActive) return false
                if (kotlin.math.abs(velocityX) < 600) return false
                if (kotlin.math.abs(velocityX) < kotlin.math.abs(velocityY) * 1.2f) return false
                if (velocityX < 0 && selectedTab < 2) {
                    selectTab(selectedTab + 1, animate = true)
                    return true
                }
                if (velocityX > 0 && selectedTab > 0) {
                    selectTab(selectedTab - 1, animate = true)
                    return true
                }
                return false
            }
        })
        // Attach to every child ScrollView so horizontal fling works over list content
        fun wire(v: View) {
            v.setOnTouchListener { _, e ->
                detector.onTouchEvent(e)
                false
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) wire(v.getChildAt(i))
            }
        }
        wire(target)
        target.setOnTouchListener { _, e ->
            detector.onTouchEvent(e)
            false
        }
    }

    private fun updateNavSelection() {
        navIcons.forEachIndexed { index, iv ->
            val active = index == selectedTab
            iv.setColorFilter(if (active) accent else muted)
            iv.animate().scaleX(if (active) 1.12f else 1f).scaleY(if (active) 1.12f else 1f)
                .setDuration(160).start()
        }
    }

    private fun selectTab(tab: Int, animate: Boolean = true) {
        if (tab == selectedTab && animate) {
            loadTabContent(tab)
            updateNavSelection()
            return
        }
        val direction = if (tab > selectedTab) 1 else -1
        selectedTab = tab
        updateNavSelection()
        if (tab != 0) searchField.visibility = View.GONE

        if (!animate) {
            loadTabContent(tab)
            contentHost.translationX = 0f
            contentHost.alpha = 1f
            return
        }

        contentHost.animate()
            .translationX(-direction * dp(40).toFloat())
            .alpha(0f)
            .setDuration(140)
            .withEndAction {
                loadTabContent(tab)
                contentHost.translationX = direction * dp(40).toFloat()
                contentHost.animate()
                    .translationX(0f)
                    .alpha(1f)
                    .setDuration(180)
                    .start()
            }
            .start()
    }

    private fun loadTabContent(tab: Int) {
        when (tab) {
            0 -> if (currentSearchQuery.isBlank()) loadCards() else filterCards(currentSearchQuery)
            1 -> loadAnalysis()
            2 -> loadMemory()
        }
    }

    private fun addEmpty(message: String) {
        cards.addView(label(message, 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(48), dp(12), dp(48))
            setLineSpacing(0f, 1.25f)
        })
    }

    private fun loadCards() {
        lifecycleScope.launch {
            val list = EchoDb.get(this@MainActivity).cards().all()
            cards.removeAllViews()
            if (list.isEmpty()) {
                addEmpty("Пока нет записей.\nНажми точку и начни говорить.")
                return@launch
            }
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            list.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(15))
                    background = rounded(panel, 16, stroke)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    setLineSpacing(0f, 1.28f)
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun loadAnalysis() {
        cards.removeAllViews()
        addDaySummarySection()
    }

    private fun loadMemory() {
        cards.removeAllViews()
        addMemoryRefreshButton()

        lifecycleScope.launch {
            val facts = EchoDb.get(this@MainActivity).memory().all()
            if (facts.isEmpty()) {
                addEmpty("Здесь появятся устойчивые факты, которые Эхо запомнило.")
                return@launch
            }

            var lastCategory = ""
            facts.forEach { f ->
                if (f.category != lastCategory) {
                    lastCategory = f.category
                    cards.addView(sectionTitle(f.category.replaceFirstChar { it.uppercase() }))
                }
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 16, stroke)
                }
                row.addView(label(f.subject, 12f, muted).apply {
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                })
                row.addView(label(f.fact, 15f, primaryText).apply {
                    setPadding(0, dp(6), 0, 0)
                    setLineSpacing(0f, 1.25f)
                })
                cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
            }
        }
    }

    // "Анализ дня" -- an artistic recap of today's cards, sitting above the
    // long-term memory list. Shows the cached digest instantly (if any) while
    // a fresh one is fetched in the background, throttled to once an hour.
    private fun addDaySummarySection() {
        cards.addView(sectionTitle("Анализ дня"))

        val body = label("Собираю впечатления за сегодня...", 15f, primaryText).apply {
            setLineSpacing(0f, 1.3f)
        }
        val caption = label("", 11f, muted).apply { setPadding(0, dp(10), 0, 0) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 16, stroke)
        }
        card.addView(body)
        card.addView(caption)
        cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(20)
        })

        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        fun show(result: DaySummary.Result) {
            body.text = result.text
            caption.text = "Обновлено в ${timeFmt.format(Date(result.generatedAt))}" +
                if (result.isFinal) " · итог дня зафиксирован" else ""
        }

        lifecycleScope.launch {
            // Avoid a "Собираю..." flash on every reopen if we already have something.
            val cachedResult = DaySummary.cached(this@MainActivity)
            cachedResult?.let { show(it) }

            val result = DaySummary.runIfDue(this@MainActivity)
            if (result != null) {
                show(result)
            } else if (cachedResult == null) {
                body.text = "Пока рановато подводить итоги — скажи что-нибудь вслух."
                caption.text = ""
            }
        }
    }

    private fun addMemoryRefreshButton() {
        val row = FrameLayout(this).apply {
            minimumHeight = dp(42)
        }
        val refresh = ImageButton(this).apply {
            setImageResource(R.drawable.ic_refresh)
            contentDescription = "Обновить память"
            background = rounded(Color.TRANSPARENT, 50)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setColorFilter(muted)
            elevation = dp(2).toFloat()
        }
        refresh.setOnClickListener {
            refresh.isEnabled = false
            refresh.animate().rotationBy(360f).setDuration(420).start()
            lifecycleScope.launch {
                val added = MemoryExtraction.runNow(this@MainActivity)
                Toast.makeText(
                    this@MainActivity,
                    if (added > 0) "Новых фактов: $added" else "Новых фактов не найдено",
                    Toast.LENGTH_SHORT
                ).show()
                refresh.isEnabled = true
                if (selectedTab == 2) loadMemory()
            }
        }
        row.addView(refresh, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.TOP))
        cards.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply {
            bottomMargin = dp(2)
        })
    }

    // Tap = play back the recording (tap again while it's playing = stop it),
    // long-press = copy the text, swipe left = delete the card + its audio,
    // swipe right = toggle favorite (snaps back, doesn't remove the card).
    private fun attachCardGestures(view: View, card: SpeechCard, star: TextView) {
        var isFavorite = card.favorite

        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playingCardId == card.id && isPlaying) {
                    stopPlayback()
                } else {
                    playCard(card)
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Эхо", card.text))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            }
        })

        var downX = 0f
        var downY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && abs(dx) > dp(16) && abs(dx) > abs(dy)) {
                        dragging = true
                        v.parent.requestDisallowInterceptTouchEvent(true)
                    }
                    if (dragging) {
                        v.translationX = dx
                        // Fade only previews the delete (left) direction.
                        v.alpha = if (dx < 0) {
                            1f - (-dx / v.width.coerceAtLeast(1)).coerceIn(0f, 0.8f)
                        } else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        val dx = event.rawX - downX
                        when {
                            dx < -v.width * 0.35f -> {
                                v.animate().translationX(-v.width.toFloat()).alpha(0f)
                                    .setDuration(180)
                                    .withEndAction { deleteCard(card, v) }
                                    .start()
                            }
                            dx > v.width * 0.35f -> {
                                isFavorite = !isFavorite
                                star.text = if (isFavorite) "★" else ""
                                lifecycleScope.launch {
                                    EchoDb.get(this@MainActivity).cards().setFavorite(card.id, isFavorite)
                                }
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                            else -> {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                        }
                    }
                    dragging = false
                    true
                }
                else -> true
            }
        }
    }

    private fun deleteCard(card: SpeechCard, view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
        stopPlayback()
        lifecycleScope.launch {
            EchoDb.get(this@MainActivity).cards().delete(card.id)
            card.audioPath?.let { path -> try { File(path).delete() } catch (_: Exception) {} }
        }
    }

    // Raw 16 kHz / mono / 16-bit PCM playback of a card's saved recording.
    private var playThread: Thread? = null
    @Volatile private var isPlaying = false
    @Volatile private var playingCardId: Long? = null

    private fun playCard(card: SpeechCard) {
        val path = card.audioPath
        if (path == null) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists() || file.length() == 0L) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }

        stopPlayback()
        isPlaying = true
        playingCardId = card.id
        playThread = Thread {
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    16000,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096),
                    AudioTrack.MODE_STREAM
                )
                track.play()
                file.inputStream().use { input ->
                    val buf = ByteArray(3200)
                    while (isPlaying) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        track.write(buf, 0, n)
                    }
                }
                track.stop()
                track.release()
            } catch (e: Exception) {
                android.util.Log.e("EchoPlayback", "Playback failed", e)
            } finally {
                isPlaying = false
                if (playingCardId == card.id) playingCardId = null
            }
        }
        playThread?.start()
    }

    private fun stopPlayback() {
        isPlaying = false
        try { playThread?.join(200) } catch (_: Exception) {}
        playThread = null
        playingCardId = null
    }

    override fun onStop() {
        stopPlayback()
        if (qaActive) stopLiveQA()
        super.onStop()
    }

    private fun refreshLoop() {
        lifecycleScope.launch {
            while (!isFinishing) {
                if (selectedTab == 0) {
                    if (currentSearchQuery.isBlank()) loadCards()
                    else filterCards(currentSearchQuery)
                }
                delay(2500)
            }
        }
    }

    private fun toggle() {
        val running = getPreferences(0).getBoolean("running", false)
        val intent = Intent(this, ListeningService::class.java).apply {
            action = if (running) "stop" else "start"
        }
        if (running) stopService(intent) else startForegroundService(intent)
        getPreferences(0).edit().putBoolean("running", !running).apply()
        isListening = !running
        applyFabListeningState(animated = true)
    }

    private fun applyFabListeningState(animated: Boolean) {
        val res = if (isListening) R.drawable.echo_recording else R.drawable.echo_idle
        fabButton.contentDescription = if (isListening) "Остановить запись" else "Начать запись"
        if (!animated) {
            fabButton.setImageResource(res)
            return
        }
        fabButton.animate()
            .scaleX(0.82f).scaleY(0.82f).alpha(0.55f)
            .setDuration(90)
            .withEndAction {
                fabButton.setImageResource(res)
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(170).start()
            }
            .start()
    }

    private fun attachFabGesture(fab: View) {
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (qaActive) stopLiveQA() else toggle()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!qaActive) startLiveQA()
            }
        })
        fab.setOnTouchListener { _, event ->
            gesture.onTouchEvent(event)
            true
        }
    }

    @Volatile private var qaActive = false
    @Volatile private var qaRecording = false
    private var qaRecordThread: Thread? = null
    private var qaOverlay: View? = null
    private var qaStatus: TextView? = null
    private var qaAnswer: TextView? = null

    // Live QA model audio playback (Gemini Live returns 24 kHz PCM mono).
    private var qaTrack: AudioTrack? = null
    private val qaTrackLock = Any()

    // Two AudioRecord sessions on the mic at once is unreliable across
    // devices -- pause background listening while a question is being asked,
    // and always resume it (if it was running) once the overlay closes.
    private var qaPausedBackgroundListening = false

    private fun startLiveQA() {
        qaActive = true
        // Haptic tick
        try {
            fabContainer.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        } catch (_: Exception) {}

        qaPausedBackgroundListening = getPreferences(0).getBoolean("running", false)
        if (qaPausedBackgroundListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
        }

        // Dot shrinks away → premium animated ring appears
        fabButton.animate()
            .scaleX(0f).scaleY(0f).alpha(0f)
            .setDuration(180)
            .withEndAction {
                fabButton.visibility = View.INVISIBLE
                ringView.visibility = View.VISIBLE
                ringView.alpha = 0f
                ringView.animate().alpha(1f).setDuration(220).start()
                ringView.start()
            }
            .start()

        showQaPanel()
        ensureQaTrack()

        lifecycleScope.launch {
            val context = LiveQaContext.build(this@MainActivity)
            val ready = LiveQA.start(
                systemContext = context,
                onAnswerChunk = { pcm ->
                    writeQaAudio(pcm)
                    runOnUiThread { qaStatus?.text = "Эхо отвечает..." }
                },
                onSubtitleChunk = { text ->
                    runOnUiThread { qaAnswer?.append(text) }
                },
                onTurnComplete = {
                    runOnUiThread { qaStatus?.text = "Слушаю…" }
                }
            )
            if (!qaActive) return@launch
            if (!ready) {
                runOnUiThread { qaStatus?.text = "Не удалось подключиться" }
                return@launch
            }
            runOnUiThread { qaStatus?.text = "Слушаю…" }
            beginQaRecording()
        }
    }

    private fun stopLiveQA() {
        qaActive = false
        qaRecording = false
        LiveQA.stop()
        releaseQaTrack()
        closeQaPanel()
        // Animated ring → dot
        ringView.setAudioLevel(0f)
        ringView.stop()
        ringView.animate()
            .alpha(0f)
            .setDuration(180)
            .withEndAction {
                ringView.visibility = View.INVISIBLE
                fabButton.visibility = View.VISIBLE
                fabButton.alpha = 0f
                fabButton.scaleX = 0f
                fabButton.scaleY = 0f
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200).start()
                applyFabListeningState(animated = false)
            }
            .start()
        if (qaPausedBackgroundListening) {
            qaPausedBackgroundListening = false
            startForegroundService(Intent(this, ListeningService::class.java).apply { action = "start" })
        }
    }

    private fun ensureQaTrack() {
        synchronized(qaTrackLock) {
            if (qaTrack != null) return
            // Gemini Live AUDIO modality delivers 24 kHz 16-bit mono PCM.
            val sampleRate = 24000
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4800),
                AudioTrack.MODE_STREAM
            )
            track.play()
            qaTrack = track
        }
    }

    private fun writeQaAudio(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        synchronized(qaTrackLock) {
            val track = qaTrack ?: return
            try {
                track.write(pcm, 0, pcm.size)
            } catch (e: Exception) {
                android.util.Log.e("EchoLiveQA", "writeQaAudio failed", e)
            }
        }
    }

    private fun releaseQaTrack() {
        synchronized(qaTrackLock) {
            try {
                qaTrack?.stop()
            } catch (_: Exception) {}
            try {
                qaTrack?.release()
            } catch (_: Exception) {}
            qaTrack = null
        }
    }

    private fun beginQaRecording() {
        qaRecording = true
        qaRecordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(6400, minBuf)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return@Thread
            }
            ar.startRecording()
            try {
                val buf = ShortArray(320)
                while (qaRecording) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    // Drive the Live QA ring from the real microphone energy.
                    // RMS is normalized to 0..1 and smoothed inside EchoRingView.
                    var sumSquares = 0.0
                    for (k in 0 until n) {
                        val sample = buf[k].toDouble() / 32768.0
                        sumSquares += sample * sample
                    }
                    val rms = sqrt(sumSquares / n.coerceAtLeast(1))
                    val voiceLevel = (rms * 7.5).coerceIn(0.0, 1.0).toFloat()
                    runOnUiThread {
                        ringView.setAudioLevel(if (LiveQA.modelSpeaking) 0f else voiceLevel)
                    }

                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    LiveQA.sendAudio(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }
        qaRecordThread?.start()
    }

    // filterCards: re-renders the cards list filtered by query (case-insensitive substring match).
    // Empty query restores the full list for the current tab.
    private fun filterCards(query: String) {
        if (query.isEmpty()) {
            when (selectedTab) {
                0 -> loadCards()
                1 -> loadAnalysis()
                2 -> loadMemory()
            }
            return
        }
        lifecycleScope.launch {
            val db = EchoDb.get(this@MainActivity)
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            val lower = query.lowercase()
            val results = db.cards().all().filter { it.text.lowercase().contains(lower) }
            cards.removeAllViews()
            if (results.isEmpty()) {
                addEmpty("Ничего не найдено по запросу «$query»")
                return@launch
            }
            results.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(15))
                    background = rounded(panel, 16, stroke)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    setLineSpacing(0f, 1.28f)
                })
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    // Bottom Live-QA sheet: edge-to-edge, sits under the 150dp blob.
    private fun showQaPanel() {
        val root = window.decorView.findViewById<ViewGroup>(android.R.id.content)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(16) + navBarInset())
            background = rounded(Color.WHITE, 24)
            elevation = dp(16).toFloat()
            // Swipe down to close
            var downY = 0f
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = e.rawY - downY
                        if (dy > 0) v.translationY = dy
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (e.rawY - downY > dp(80)) stopLiveQA()
                        else v.animate().translationY(0f).setDuration(160).start()
                        true
                    }
                    else -> false
                }
            }
        }

        val handle = View(this).apply {
            background = rounded(Color.parseColor("#C5CAD3"), 4)
        }
        panel.addView(handle, LinearLayout.LayoutParams(dp(40), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })

        val status = label("Подключаюсь…", 13f, Color.parseColor("#6B7280")).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        val answer = label("", 16f, Color.parseColor("#111318")).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(10), 0, dp(8))
            setLineSpacing(0f, 1.35f)
        }
        val scroll = ScrollView(this).apply { addView(answer) }
        panel.addView(status)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Sheet height; blob sits fully above its top edge
        val panelH = (resources.displayMetrics.heightPixels * 0.38f).toInt().coerceAtLeast(dp(240))
        val params = FrameLayout.LayoutParams(-1, panelH, Gravity.BOTTOM)
        panel.translationY = panelH.toFloat()
        root.addView(panel, params)

        // Lift FAB so the 150dp blob rests just above the sheet (not under it)
        val lift = (panelH - dp(20)).toFloat()
        fabContainer.bringToFront()
        fabContainer.elevation = dp(28).toFloat()
        fabContainer.animate()
            .translationY(-lift)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()

        panel.animate()
            .translationY(0f)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()

        qaPanel = panel
        qaOverlay = panel
        qaStatus = status
        qaAnswer = answer
    }

    private fun closeQaPanel() {
        val panel = qaPanel ?: return
        val h = panel.height.takeIf { it > 0 } ?: dp(300)
        panel.animate()
            .translationY(h.toFloat())
            .setDuration(220)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction { (panel.parent as? ViewGroup)?.removeView(panel) }
            .start()
        // Return FAB to resting position
        fabContainer.animate()
            .translationY(0f)
            .setDuration(220)
            .start()
        qaPanel = null
        qaOverlay = null
        qaStatus = null
        qaAnswer = null
    }

    private object ColorDrawableCompat {
        operator fun invoke(color: Int) = android.graphics.drawable.ColorDrawable(color)
    }
}

/**
 * Premium animated Echo ring used for Live QA.
 *
 * The old organic blob is intentionally removed. The ring combines:
 *  - a soft luminous halo,
 *  - a clean white/cyan core ring,
 *  - counter-rotating orbital filaments,
 *  - a breathing center pulse,
 *  - subtle circumference modulation that reacts to animation time.
 */
class EchoRingView(context: android.content.Context) : View(context) {
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#F7FBFF")
    }
    private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#65D8FF")
    }
    private val filamentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#70DFFF")
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#55D8FF")
        maskFilter = android.graphics.BlurMaskFilter(18f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        maskFilter = android.graphics.BlurMaskFilter(7f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    private var phase = 0f
    private var running = false
    @Volatile private var targetAudioLevel = 0f
    private var audioLevel = 0f

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.045f + audioLevel * 0.11f
            audioLevel += (targetAudioLevel - audioLevel) * 0.18f
            invalidate()
            postOnAnimation(this)
        }
    }

    init {
        // BlurMaskFilter needs software rendering on some Android devices.
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    fun setAudioLevel(level: Float) {
        targetAudioLevel = level.coerceIn(0f, 1f)
    }

    fun start() {
        running = true
        removeCallbacks(frame)
        postOnAnimation(frame)
    }

    fun stop() {
        running = false
        targetAudioLevel = 0f
        audioLevel = 0f
        removeCallbacks(frame)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val size = kotlin.math.min(width, height).toFloat()

        // The microphone level drives the whole visual system: size, glow,
        // filament motion and center pulse. Silence remains alive but calm.
        val breath = 0.5f + 0.5f * kotlin.math.sin(phase * 1.55f)
        val reactive = audioLevel * (0.72f + 0.28f * breath)
        val baseR = size * 0.335f
        val r = baseR * (1f + 0.025f * breath + 0.095f * reactive)

        // Deep halo expands with voice energy.
        glowPaint.strokeWidth = size * (0.075f + 0.055f * reactive)
        glowPaint.alpha = (42 + 125 * reactive + 22 * breath).toInt().coerceAtMost(190)
        canvas.drawCircle(cx, cy, r, glowPaint)

        // Clean luminous core ring.
        corePaint.strokeWidth = size * (0.068f + 0.016f * reactive)
        corePaint.alpha = 245
        canvas.drawCircle(cx, cy, r, corePaint)

        // Fine cyan inner edge.
        cyanPaint.strokeWidth = size * (0.011f + 0.008f * reactive)
        cyanPaint.alpha = (175 + 75 * reactive).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.055f, cyanPaint)

        // Woven orbital filaments react to speech volume. Louder speech
        // increases their speed, arc length and displacement.
        val filamentR = r - size * 0.01f
        for (i in 0 until 7) {
            val direction = if (i % 2 == 0) 1f else -1f
            val speed = 0.42f + i * 0.065f + reactive * (1.2f + i * 0.12f)
            val rotation = Math.toDegrees((phase * direction * speed).toDouble()).toFloat()
            val sweep = 105f + 20f * kotlin.math.sin(phase * 1.1f + i) + 48f * reactive
            val start = rotation + i * 51f + 10f * kotlin.math.sin(phase + i * 0.7f) * reactive

            filamentPaint.strokeWidth = size * (0.0075f + i * 0.0010f + 0.004f * reactive)
            filamentPaint.alpha = (82 + i * 18 + 85 * reactive).toInt().coerceAtMost(235)
            canvas.save()
            canvas.rotate(start, cx, cy)
            canvas.drawArc(
                cx - filamentR, cy - filamentR,
                cx + filamentR, cy + filamentR,
                18f, sweep, false, filamentPaint
            )
            canvas.restore()
        }

        // Short inner threads make the center look woven rather than like a
        // simple spinner. Their movement is strongly tied to speech energy.
        for (i in 0 until 5) {
            val rr = r - size * (0.040f + i * 0.024f)
            val start = -phase * (18f + 42f * reactive) + i * 72f
            filamentPaint.strokeWidth = size * (0.0045f + 0.0035f * reactive)
            filamentPaint.alpha = (55 + i * 15 + 70 * reactive).toInt().coerceAtMost(190)
            canvas.drawArc(
                cx - rr, cy - rr, cx + rr, cy + rr,
                start, 45f + 35f * reactive + 10f * breath, false, filamentPaint
            )
        }

        // Center pulse: barely visible in silence, noticeably brighter when
        // the user speaks.
        val pulse = size * (0.058f + 0.045f * reactive + 0.012f * breath)
        innerGlowPaint.strokeWidth = size * (0.012f + 0.012f * reactive)
        innerGlowPaint.alpha = (75 + 150 * reactive).toInt().coerceAtMost(225)
        canvas.drawCircle(cx, cy, pulse, innerGlowPaint)

        centerPaint.alpha = (150 + 95 * reactive).toInt().coerceAtMost(245)
        canvas.drawCircle(cx, cy, pulse * (0.22f + 0.18f * reactive), centerPaint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }
}
