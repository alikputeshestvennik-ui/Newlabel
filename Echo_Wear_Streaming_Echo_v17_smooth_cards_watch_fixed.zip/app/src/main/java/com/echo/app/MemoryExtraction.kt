package com.echo.app

import android.content.Context
import android.util.Log
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.security.MessageDigest

// Turns the day's raw speech cards into a short list of durable facts,
// stored separately in long_term_memory so the "Память" tab isn't just a
// growing wall of every sentence ever said.
object MemoryExtraction {

    private const val TAG = "EchoMemory"
    private const val PREFS = "echo_memory"
    private const val KEY_LAST_RUN = "last_extracted_at"
    private const val KEY_INPUT_SIGNATURE = "last_input_signature"
    private const val THROTTLE_MS = 15 * 60 * 1000L
    private const val WINDOW_MS = 24 * 60 * 60 * 1000L

    // Re-check the source text periodically. This catches cards that were created
    // as "Расшифровка..." and received their real text later. Identical input is
    // not sent again, which keeps quota usage low.
    suspend fun runIfDue(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getLong(KEY_LAST_RUN, 0L)
        if (System.currentTimeMillis() - last < THROTTLE_MS) return
        val cards = EchoDb.get(context).cards().since(System.currentTimeMillis() - WINDOW_MS)
            .filter { it.text.isNotBlank() && it.text != "Расшифровка..." && it.text != "Ожидает отправки" }
        val signature = inputSignature(cards)
        if (signature.isBlank() || signature == prefs.getString(KEY_INPUT_SIGNATURE, "")) return
        runNow(context)
    }

    // Runs immediately regardless of when it last ran (used by the manual
    // "Обновить" button). Returns how many new facts were saved.
    suspend fun runNow(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val db = EchoDb.get(context)

        // Rolling source window instead of createdAt > last-run: a card can be
        // transcribed after it was created and must still become a memory source.
        val cards = db.cards().since(System.currentTimeMillis() - WINDOW_MS)
            .filter { it.text.isNotBlank() && it.text != "Расшифровка..." && it.text != "Ожидает отправки" }

        // Do not advance the watermark before the API succeeds. If Gemini is
        // rate-limited or temporarily unavailable, the same cards must remain
        // eligible for the next run instead of being silently lost.
        if (cards.isEmpty()) return 0

        val transcript = cards.joinToString("\n") { "- ${it.text}" }
        val response = try {
            Gemini.extract(buildPrompt(transcript))
        } catch (e: Exception) {
            Log.e(TAG, "Extraction request failed", e)
            return 0
        }

        if (response.isBlank()) return 0

        val facts = parseFacts(response)
        if (facts.isNotEmpty()) {
            db.memory().insertAll(facts)
            Log.d(TAG, "Extracted ${facts.size} fact(s) from ${cards.size} card(s)")
        }

        // Advance only after a valid model response (including a valid empty
        // array). This prevents quota/network errors from consuming the cards.
        prefs.edit()
            .putLong(KEY_LAST_RUN, System.currentTimeMillis())
            .putString(KEY_INPUT_SIGNATURE, inputSignature(cards))
            .apply()
        return facts.size
    }

    private fun inputSignature(cards: List<SpeechCard>): String {
        if (cards.isEmpty()) return ""
        val raw = cards.sortedBy { it.id }
            .joinToString("\n") { "${it.id}|${it.createdAt}|${it.text.trim()}" }
        return try {
            MessageDigest.getInstance("SHA-256")
                .digest(raw.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            raw.hashCode().toString()
        }
    }

    private fun buildPrompt(transcript: String): String = """
        Ты — модуль долговременной памяти голосового ассистента "Эхо".
        Ниже — расшифровки того, что пользователь говорил вслух за день (это его
        собственная речь, не диалог с ассистентом).

        Извлеки только УСТОЙЧИВЫЕ факты о пользователе: то, что останется правдой
        надолго — работа, привычки, отношения, интересы, планы, предпочтения.
        НЕ включай разовые события без долгосрочной ценности, тестовые фразы
        ("проверка", "работает ли"), случайные обрывки и бессмыслицу.
        Если устойчивых фактов нет, верни пустой массив.

        Ответ — строго JSON-массив объектов, без markdown и пояснений:
        [{"category": "...", "subject": "...", "fact": "..."}]

        category — одно из: "работа", "отношения", "здоровье", "интересы", "планы", "привычки", "прочее"
        subject — короткая тема, 2-4 слова
        fact — сам факт одним предложением от третьего лица, на русском

        Расшифровки за день:
        $transcript
    """.trimIndent()

    private fun parseFacts(response: String): List<MemoryFact> {
        return try {
            val cleaned = response.trim()
                .removePrefix("```json").removePrefix("```")
                .removeSuffix("```").trim()
            val arr = JSONArray(cleaned)
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val category = obj.optString("category").trim()
                val subject = obj.optString("subject").trim()
                val fact = obj.optString("fact").trim()
                if (category.isBlank() || subject.isBlank() || fact.isBlank()) null
                else MemoryFact(category = category, subject = subject, fact = fact, sourceDate = today)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Could not parse extraction response: $response", e)
            emptyList()
        }
    }
}
