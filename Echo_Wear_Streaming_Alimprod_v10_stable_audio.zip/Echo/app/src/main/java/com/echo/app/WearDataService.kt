package com.echo.app

import android.content.Context
import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class WearDataService : WearableListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onMessageReceived(event: MessageEvent) {
        if (event.path != WearBridge.ACTION_PATH) return
        scope.launch {
            try {
                val o = JSONObject(String(event.data, Charsets.UTF_8))
                val id = o.getLong("id")
                when (o.getString("action")) {
                    "favorite" -> {
                        val db = EchoDb.get(this@WearDataService)
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().setFavorite(id, !card.favorite)
                    }
                    "delete" -> {
                        val db = EchoDb.get(this@WearDataService)
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().delete(id)
                        card.audioPath?.let { try { File(it).delete() } catch (_: Exception) {} }
                    }
                }
                WearBridge.syncCards(this@WearDataService, EchoDb.get(this@WearDataService).cards().all())
            } catc    override fun onChannelOpened(channel: ChannelClient.Channel) {
        if (!channel.path.startsWith(WearBridge.AUDIO_PATH_PREFIX)) return
        val createdAt = channel.path.substringAfterLast('/').toLongOrNull() ?: System.currentTimeMillis()

        Wearable.getChannelClient(this).getInputStream(channel)
            .addOnSuccessListener { input ->
                // Keep the entire channel read alive on a dedicated worker. The old
                // implementation returned from onChannelOpened immediately after
                // starting a raw Thread, which could lose the worker if Android
                // reclaimed the listener service/process.
                scope.launch {
                    var currentFile: File? = null
                    var out: FileOutputStream? = null
                    var segmentStart = createdAt
                    var ok = false
                    try {
                        val buffer = ByteArray(16 * 1024)
                        currentFile = File(filesDir, "watch_${segmentStart}.pcm")
                        out = FileOutputStream(currentFile!!)

                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            out!!.write(buffer, 0, n)
                            ok = true

                            if (System.currentTimeMillis() - segmentStart >= MAX_SEGMENT_MS) {
                                out!!.flush()
                                out!!.close()
                                saveWatchCard(segmentStart, currentFile!!)
                                segmentStart = System.currentTimeMillis()
                                currentFile = File(filesDir, "watch_${segmentStart}.pcm")
                                out = FileOutputStream(currentFile!!)
                            }
                        }

                        out?.flush()
                        out?.close()
                        out = null

                        if (ok && currentFile != null && currentFile!!.length() > 0L) {
                            saveWatchCard(segmentStart, currentFile!!)
                        } else {
                            currentFile?.delete()
                        }
                    } catch (_: Exception) {
                        try { out?.close() } catch (_: Exception) { }
                        try { currentFile?.delete() } catch (_: Exception) { }
                    } finally {
                        try { input.close() } catch (_: Exception) { }
                        try { Wearable.getChannelClient(this@WearDataService).close(channel) } catch (_: Exception) { }
                    }
                }
            }
    }

    private fun saveWatchCard(createdAt: Long, file: File) {
        scope.launch {
            try {
                val db = EchoDb.get(this@WearDataService)
                val id = db.cards().insert(
                    SpeechCard(
                        createdAt = createdAt,
                        text = "Ожидает отправки",
                        audioPath = file.absolutePath,
                        pendingUpload = true
                    )
                )
                val all = db.cards().all()
                WearBridge.syncCards(this@WearDataService, all)

                // Explicit acknowledgement so the watch knows the PCM really
                // reached the phone and was saved as a card.
                val nodes = Wearable.getNodeClient(this@WearDataService).connectedNodes
                    .await()
                val node = nodes.firstOrNull()
                if (node != null) {
                    val payload = JSONObject().apply {
                        put("createdAt", createdAt)
                        put("cardId", id)
                    }.toString().toByteArray(Charsets.UTF_8)
                    Wearable.getMessageClient(this@WearDataService)
                        .sendMessage(node.id, WearBridge.AUDIO_ACK_PATH, payload)
                }
            } catch (_: Exception) { }
        }
    }

h (_: Exception) { }
        }
    }

    companion object {
        private const val MAX_SEGMENT_MS = 29L * 60L * 1000L
    }
}
