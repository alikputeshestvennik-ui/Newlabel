package com.echo.app

import android.content.Context
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WearBridge {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    const val CARDS_PATH = "/echo/cards"
    const val ACTION_PATH = "/echo/card/action"
    const val AUDIO_PATH_PREFIX = "/echo/manual-audio/"
    const val RECORDING_STATE_PATH = "/echo/recording/state"
    const val RECORDING_CONTROL_PATH = "/echo/recording/control"


    fun sendRecordingState(context: Context, active: Boolean, source: String) {
        scope.launch {
            try {
                val nodes = Wearable.getNodeClient(context.applicationContext).connectedNodes.await()
                val node = nodes.firstOrNull() ?: return@launch
                val payload = JSONObject().apply {
                    put("active", active)
                    put("source", source)
                    put("at", System.currentTimeMillis())
                }.toString().toByteArray(Charsets.UTF_8)
                Wearable.getMessageClient(context.applicationContext)
                    .sendMessage(node.id, RECORDING_STATE_PATH, payload)
                    .await()
            } catch (_: Exception) { }
        }
    }

    fun sendRecordingStop(context: Context) {
        scope.launch {
            try {
                val nodes = Wearable.getNodeClient(context.applicationContext).connectedNodes.await()
                val node = nodes.firstOrNull() ?: return@launch
                val payload = JSONObject().put("action", "stop").toString().toByteArray(Charsets.UTF_8)
                Wearable.getMessageClient(context.applicationContext)
                    .sendMessage(node.id, RECORDING_CONTROL_PATH, payload)
                    .await()
            } catch (_: Exception) { }
        }
    }

    fun syncCards(context: Context, cards: List<SpeechCard>) {
        scope.launch {
            try {
                val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
                val arr = JSONArray()
                cards.take(50).forEach { c ->
                    arr.put(JSONObject().apply {
                        put("id", c.id)
                        put("text", c.text)
                        put("date", dateFmt.format(Date(c.createdAt)))
                        put("time", timeFmt.format(Date(c.createdAt)))
                        put("fromWatch", c.audioPath?.substringAfterLast('/')?.startsWith("watch_") == true)
                        put("favorite", c.favorite)
                    })
                }
                val request = PutDataMapRequest.create(CARDS_PATH).apply {
                    dataMap.putString("json", arr.toString())
                    dataMap.putLong("updatedAt", System.currentTimeMillis())
                }.asPutDataRequest().setUrgent()
                Wearable.getDataClient(context.applicationContext).putDataItem(request)
            } catch (_: Exception) { }
        }
    }
}
