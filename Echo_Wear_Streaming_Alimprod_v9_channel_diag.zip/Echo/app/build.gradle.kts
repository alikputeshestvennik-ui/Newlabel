plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.devtools.ksp") }

android {
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    namespace = "com.echo.app"
    compileSdk = 35

    signingConfigs {
        create("release") {
            val ksFile = layout.buildDirectory.file("generated/echo-release.jks").get().asFile
            storeFile = ksFile
            storePassword = System.getenv("ECHO") ?: ""
            keyAlias = "Alimprod"
            keyPassword = System.getenv("ECHO_KEY_PASSWORD") ?: System.getenv("ECHO") ?: ""
        }
    }

    defaultConfig {
        applicationId = "com.echo.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.0-diag"
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            buildConfigField(
                "String",
                "GEMINI_API_KEY",
                "\"${System.getenv("GEMINI") ?: System.getenv("GEMINI_API_KEY") ?: ""}\""
            )
        }
        getByName("debug") {
            buildConfigField(
                "String",
                "GEMINI_API_KEY",
                "\"${System.getenv("GEMINI") ?: System.getenv("GEMINI_API_KEY") ?: ""}\""
            )
        }
    }

    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.android.gms:play-services-wearable:20.0.1")
}


kotlin {
    jvmToolchain(17)
}
