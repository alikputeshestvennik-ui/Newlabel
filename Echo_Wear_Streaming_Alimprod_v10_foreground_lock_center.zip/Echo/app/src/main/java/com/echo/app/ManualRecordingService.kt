package com.echo.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

/**
 * Owns manual/offline microphone capture independently of MainActivity.
 * Recording survives screen-off and Activity recreation.
 */
class ManualRecordingService : Service() {
    private var recorder: AudioRecord? = null
    private var thread: Thread? = null
    private var output: FileOutputStream? = null
    private var file: File? = null
    private var segmentStartedAt = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    @Volatile private var recording = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = notification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> if (!recording) startCapture()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        recording = true
        isRunning = true
        try {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Echo:ManualRecording")?.apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) { }

        segmentStartedAt = System.currentTimeMillis()
        openSegment(segmentStartedAt)

        thread = Thread {
            val minBuffer = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(6400, minBuffer)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
            recorder = ar
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                recording = false
                isRunning = false
                sendState("error")
                stopSelf()
                return@Thread
            }

            try {
                ar.startRecording()
                val buf = ShortArray(320) // 20 ms at 16 kHz
                while (recording) {
                    val n = ar.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                    if (n <= 0) continue
                    val bytes = ByteArray(n * 2)
                    var sum = 0.0
                    for (i in 0 until n) {
                        val s = buf[i].toInt()
                        bytes[i * 2] = (s and 255).toByte()
                        bytes[i * 2 + 1] = (s shr 8).toByte()
                        val x = s / 32768.0
                        sum += x * x
                    }
                    synchronized(this) { output?.write(bytes) }
                    sendLevel((sqrt(sum / n) * 5.5).coerceIn(0.02, 1.0).toFloat())

                    if (System.currentTimeMillis() - segmentStartedAt >= MAX_SEGMENT_MS) {
                        rotateSegment()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e(TAG, "manual capture failed", e)
            } finally {
                try { ar.stop() } catch (_: Exception) { }
                ar.release()
                recorder = null
            }
        }.also { it.start() }
        sendState("started")
    }

    private fun openSegment(startedAt: Long) {
        synchronized(this) {
            try { output?.flush() } catch (_: Exception) { }
            try { output?.close() } catch (_: Exception) { }
            file = File(filesDir, "offline_${startedAt}.pcm")
            output = FileOutputStream(file!!)
        }
    }

    private fun rotateSegment() {
        val finished: File
        val started: Long
        synchronized(this) {
            finished = file ?: return
            started = segmentStartedAt
            try { output?.flush() } catch (_: Exception) { }
            try { output?.close() } catch (_: Exception) { }
            output = null
            file = null
            segmentStartedAt = System.currentTimeMillis()
            openSegment(segmentStartedAt)
        }
        saveSegment(finished, started, rotated = true)
    }

    private fun stopCapture() {
        if (!recording) {
            stopSelf()
            return
        }
        recording = false
        isRunning = false
        try { recorder?.stop() } catch (_: Exception) { }
        try { thread?.join(1200) } catch (_: Exception) { }
        thread = null

        val finished: File?
        val started: Long
        synchronized(this) {
            finished = file
            started = segmentStartedAt
            try { output?.flush() } catch (_: Exception) { }
            try { output?.close() } catch (_: Exception) { }
            output = null
            file = null
        }

        if (finished != null) saveSegment(finished, started, rotated = false)
        sendLevel(0f)
        sendState("stopped")
        releaseWakeLock()
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun saveSegment(file: File, startedAt: Long, rotated: Boolean) {
        if (!file.exists() || file.length() <= 0L) {
            try { file.delete() } catch (_: Exception) { }
            return
        }
        runBlocking(Dispatchers.IO) {
            try {
                val db = EchoDb.get(this@ManualRecordingService)
                db.cards().insert(
                    SpeechCard(
                        createdAt = startedAt,
                        text = "Ожидает отправки",
                        audioPath = file.absolutePath,
                        pendingUpload = true
                    )
                )
                WearBridge.syncCards(this@ManualRecordingService, db.cards().all())
            } catch (e: Exception) {
                android.util.Log.e(TAG, "Could not save manual card", e)
            }
        }
        if (rotated) sendState("rotated")
    }

    private fun sendLevel(level: Float) {
        sendBroadcast(
            Intent(ACTION_STATE).setPackage(packageName)
                .putExtra("state", "level")
                .putExtra("level", level)
        )
    }

    private fun sendState(state: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra("state", state))
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) { }
        wakeLock = null
    }

    override fun onDestroy() {
        if (recording) stopCapture()
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Ручная запись Echo",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    private fun notification(): Notification =
        if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Echo записывает")
                .setContentText("Ручная запись продолжается")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Echo записывает")
                .setContentText("Ручная запись продолжается")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }

    companion object {
        const val ACTION_START = "com.echo.app.MANUAL_START"
        const val ACTION_STOP = "com.echo.app.MANUAL_STOP"
        const val ACTION_STATE = "com.echo.app.MANUAL_STATE"
        private const val CHANNEL_ID = "echo_manual_recording"
        private const val NOTIFICATION_ID = 18
        private const val TAG = "EchoManualService"
        private const val SAMPLE_RATE = 16000
        private const val MAX_SEGMENT_MS = 29L * 60L * 1000L

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
