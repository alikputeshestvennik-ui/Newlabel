# GitHub Actions build

The project is configured for Android release signing with keystore alias `Alimprod`.

Required GitHub Actions repository secrets:

- `ECHO_KEYSTORE_BASE64` — the complete `.jks`/`.keystore` file encoded as Base64.
- `ECHO_STORE_PASSWORD` — keystore password.
- `ECHO_KEY_PASSWORD` — password for the key with alias `Alimprod`.
- `GEMINI` — Gemini API key.

If the keystore password and key password are identical, put the same value in the two password secrets.

## Important

GitHub Actions only loads workflow files from `.github/workflows/` in the repository itself. A workflow stored *inside this ZIP* is not executed while the ZIP remains unextracted.

If you keep the project only as a ZIP in the repository, copy this file to the repository path:

`.github/workflows/build.yml`

The workflow will then find the project ZIP, extract it on the temporary GitHub runner, restore the signing keystore from the secret, and build the signed release APK.
