# Echo Watch

Wear OS companion for Galaxy Watch.

Two screens only:

1. **Recording** — manual microphone recording. Tap the ring to start/stop. Audio is streamed to the phone with Wear OS `ChannelClient` as 16 kHz mono 16-bit PCM. No internet/Gemini logic is used on the watch.
2. **Cards** — recent Echo cards. Tap toggles favorite; long press deletes.

The phone receives the stream and saves it locally. The phone splits a continuous stream into 29-minute cards without stopping the watch microphone stream.
