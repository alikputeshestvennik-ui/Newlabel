package com.echo.app

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// Rolling 24-hour digest of the actual speech cards. The digest is regenerated
// whenever a newer card exists than the cached digest (with a small throttle
// only when nothing has changed). This keeps the source cards attached to the
// summary instead of making the UI look empty/stale.
object DaySummary {

    private const val TAG = "EchoDaySummary"
    private const val THROTTLE_MS = 15 * 60 * 1000L
    private const val LOCK_HOUR = 22
    private const val WINDOW_MS = 24 * 60 * 60 * 1000L

    data class Result(val text: String, val generatedAt: Long, val isFinal: Boolean)

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private fun isPastLockHour(): Boolean =
        Calendar.getInstance().get(Calendar.HOUR_OF_DAY) >= LOCK_HOUR

    private fun windowStartMillis(): Long = System.currentTimeMillis() - WINDOW_MS

    suspend fun cached(context: Context): Result? {
        val e = EchoDb.get(context).daySummaries().forDate(today()) ?: return null
        return Result(e.text, e.generatedAt, e.isFinal)
    }

    suspend fun runIfDue(context: Context, force: Boolean = false): Result? {
        val db = EchoDb.get(context)
        val dao = db.daySummaries()
        val today = today()
        val existing = dao.forDate(today)
        val cards = db.cards().since(windowStartMillis())
            .filter {
                it.text.isNotBlank() &&
                it.text != "Расшифровка..." &&
                (it.text != "Ожидает отправки" && it.text != "Ожидает отправки на сервер")
            }

        // No cards really means no source material. Do not fabricate a summary.
        if (cards.isEmpty()) {
            return existing?.let { Result(it.text, it.generatedAt, it.isFinal) }
        }

        val newestCardAt = cards.maxOf { it.createdAt }
        val changedSinceDigest = existing == null || newestCardAt > existing.generatedAt
        if (!force && existing != null && existing.isFinal && !changedSinceDigest) {
            return Result(existing.text, existing.generatedAt, true)
        }
        if (!force && existing != null && !changedSinceDigest &&
            System.currentTimeMillis() - existing.generatedAt < THROTTLE_MS) {
            return Result(existing.text, existing.generatedAt, existing.isFinal)
        }

        val transcript = cards.joinToString("\n") { card ->
            val stamp = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(card.createdAt))
            "[$stamp] ${card.text.trim()}"
        }

        val response = try {
            Gemini.summarize(buildPrompt(transcript, cards.size))
        } catch (e: Exception) {
            Log.e(TAG, "Day summary request failed", e)
            null
        }?.trim()

        // Keep a previous good digest if the network/model is temporarily unavailable.
        if (response.isNullOrBlank()) {
            return existing?.let { Result(it.text, it.generatedAt, it.isFinal) }
        }

        val now = System.currentTimeMillis()
        val locksNow = !force && isPastLockHour()
        val entry = DaySummaryEntry(
            date = today,
            text = response,
            generatedAt = now,
            isFinal = locksNow
        )
        dao.upsert(entry)
        return Result(response, now, locksNow)
    }

    suspend fun allText(context: Context): String =
        EchoDb.get(context).daySummaries().all()
            .joinToString("\n\n") { "${it.date}: ${it.text}" }

    private fun buildPrompt(transcript: String, count: Int): String = """
        Ты — Эхо, тёплый и наблюдательный рассказчик личного голосового дневника.
        Ниже находится ПОЛНЫЙ набор расшифрованных карточек, созданных за последние 24 часа.
        Это единственный источник фактов для этого ответа. Не проси пользователя что-либо
        сказать вслух и не утверждай, что карточек нет: они уже переданы ниже.

        Проанализируй все $count карточек и сделай связный короткий пересказ дня в 4-8 предложениях.
        Выдели важные темы, события, решения, настроение и повторяющиеся мысли. Сохраняй смысл
        исходных карточек, но не цитируй их дословно. Не выдумывай отсутствующие события.
        Если часть карточек похожа на технические тесты, просто не придавай им большого веса.

        Карточки за последние 24 часа:
        $transcript
    """.trimIndent()
}
