package com.echo.app

import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class WearDataService : WearableListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onMessageReceived(event: MessageEvent) {
        if (event.path != WearBridge.ACTION_PATH) return

        scope.launch {
            try {
                val o = JSONObject(String(event.data, Charsets.UTF_8))
                val id = o.getLong("id")
                val db = EchoDb.get(this@WearDataService)

                when (o.getString("action")) {
                    "favorite" -> {
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().setFavorite(id, !card.favorite)
                    }

                    "delete" -> {
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().delete(id)
                        card.audioPath?.let {
                            try { File(it).delete() } catch (_: Exception) {}
                        }
                    }
                }

                WearBridge.syncCards(this@WearDataService, db.cards().all())
            } catch (_: Exception) {
            }
        }
    }

    override fun onChannelOpened(channel: ChannelClient.Channel) {
        if (!channel.path.startsWith(WearBridge.AUDIO_PATH_PREFIX)) return

        val createdAt =
            channel.path.substringAfterLast('/').toLongOrNull()
                ?: System.currentTimeMillis()

        Wearable.getChannelClient(this).getInputStream(channel)
            .addOnSuccessListener { input ->
                scope.launch {
                    var currentFile: File? = null
                    var out: FileOutputStream? = null
                    var segmentStart = createdAt
                    var wroteAnyBytes = false

                    try {
                        val buffer = ByteArray(16 * 1024)

                        currentFile = File(filesDir, "watch_${segmentStart}.pcm")
                        out = FileOutputStream(currentFile!!)

                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break

                            out!!.write(buffer, 0, n)
                            wroteAnyBytes = true

                            if (System.currentTimeMillis() - segmentStart >= MAX_SEGMENT_MS) {
                                out!!.flush()
                                out!!.close()
                                out = null

                                saveWatchCard(segmentStart, currentFile!!)

                                segmentStart = System.currentTimeMillis()
                                currentFile = File(filesDir, "watch_${segmentStart}.pcm")
                                out = FileOutputStream(currentFile!!)
                                wroteAnyBytes = false
                            }
                        }

                        out?.flush()
                        out?.close()
                        out = null

                        if (wroteAnyBytes && currentFile != null && currentFile!!.length() > 0L) {
                            saveWatchCard(segmentStart, currentFile!!)
                        } else {
                            currentFile?.delete()
                        }
                    } catch (_: Exception) {
                        try { out?.close() } catch (_: Exception) {}
                        try { currentFile?.delete() } catch (_: Exception) {}
                    } finally {
                        try { input.close() } catch (_: Exception) {}
                        try {
                            Wearable.getChannelClient(this@WearDataService).close(channel)
                        } catch (_: Exception) {}
                    }
                }
            }
    }

    private fun saveWatchCard(createdAt: Long, file: File) {
        scope.launch {
            try {
                val db = EchoDb.get(this@WearDataService)

                val id = db.cards().insert(
                    SpeechCard(
                        createdAt = createdAt,
                        text = "Ожидает отправки",
                        audioPath = file.absolutePath,
                        pendingUpload = true
                    )
                )

                WearBridge.syncCards(
                    this@WearDataService,
                    db.cards().all()
                )

                // Do not use kotlinx-coroutines Task.await here.
                // Keep the phone app independent from kotlinx-coroutines-play-services.
                Wearable.getNodeClient(this@WearDataService)
                    .connectedNodes
                    .addOnSuccessListener { nodes ->
                        val node = nodes.firstOrNull() ?: return@addOnSuccessListener

                        val payload = JSONObject().apply {
                            put("createdAt", createdAt)
                            put("cardId", id)
                        }.toString().toByteArray(Charsets.UTF_8)

                        Wearable.getMessageClient(this@WearDataService)
                            .sendMessage(
                                node.id,
                                WearBridge.AUDIO_ACK_PATH,
                                payload
                            )
                    }
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        private const val MAX_SEGMENT_MS = 29L * 60L * 1000L
    }
}
