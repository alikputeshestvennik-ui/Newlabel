package com.echo.app.wear

import android.content.Context
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await

class WatchDataService : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        events.forEach { event ->
            if (event.type == DataEvent.TYPE_CHANGED && event.dataItem.uri.path == "/echo/cards") {
                val json = DataMapItem.fromDataItem(event.dataItem).dataMap.getString("json", "[]")
                getSharedPreferences("watch", Context.MODE_PRIVATE).edit()
                    .putString("cards", json)
                    .apply()
            }
        }
    }

    override fun onMessageReceived(event: MessageEvent) {
        if (event.path == AUDIO_ACK_PATH) {
            try {
                val o = JSONObject(String(event.data, Charsets.UTF_8))
                getSharedPreferences("watch", Context.MODE_PRIVATE).edit()
                    .putString("lastAudioAck", o.toString())
                    .apply()
            } catch (_: Exception) { }
        }
    }

    companion object {
        const val CARDS_PATH = "/echo/cards"
        const val ACTION_PATH = "/echo/card/action"
        const val AUDIO_ACK_PATH = "/echo/manual-audio/ack"

        fun sendAction(context: Context, id: Long, action: String) {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject().apply {
                            put("id", id)
                            put("action", action)
                        }.toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context).sendMessage(node.id, ACTION_PATH, payload).await()
                    } catch (_: Exception) { }
                }
            }.start()
        }
    }
}
