package com.echo.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewConfiguration
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

private class SwipePageContainer(context: android.content.Context) : FrameLayout(context) {
    var swipeInterceptListener: ((MotionEvent) -> Boolean)? = null
    var swipeTouchListener: ((MotionEvent) -> Boolean)? = null
    // When a card owns the gesture, let the card/ScrollView receive the stream.
    // This keeps vertical scrolling alive while still allowing horizontal card swipes.
    var cardGestureActive: Boolean = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (cardGestureActive) return false
        return swipeInterceptListener?.invoke(ev) ?: super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return swipeTouchListener?.invoke(event) ?: super.onTouchEvent(event)
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var cards: LinearLayout
    private lateinit var contentHost: FrameLayout
    private lateinit var brandLogo: ImageView
    private lateinit var searchField: EditText
    private lateinit var fabButton: ImageView
    private lateinit var ringView: EchoRingView
    private lateinit var fabContainer: FrameLayout
    private lateinit var pageContainer: SwipePageContainer
    private lateinit var rootContainer: FrameLayout
    private lateinit var mainContentView: View
    private var manualLockOverlay: View? = null
    private var manualLockIcon: ImageView? = null
    private var manualUiLocked = false
    private var selectedTab = 0
    private var currentSearchQuery = ""
    private val navIcons = mutableListOf<ImageView>()
    private var qaPanel: View? = null
    private var isListening = false
    @Volatile private var manualRecording = false
    @Volatile private var remoteRecording = false
    private var remoteRecordingSource = ""
    private var fabDownX = 0f
    private var fabDownY = 0f
    private var fabDraggingUp = false
    private val manualStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context, intent: Intent) {
            when (intent.getStringExtra("state")) {
                "started" -> {
                    manualRecording = true
                    remoteRecording = false
                    showManualRing("phone")
                }
                "level" -> {
                    val level = intent.getFloatExtra("level", 0f)
                    if (manualRecording) ringView.setAudioLevel(level)
                }
                "rotated" -> {
                    if (manualRecording) {
                        Toast.makeText(this@MainActivity, "29 минут · продолжаю запись", Toast.LENGTH_SHORT).show()
                        loadCards()
                    }
                }
                "stopped" -> {
                    manualRecording = false
                    remoteRecording = false
                    remoteRecordingSource = ""
                    getPreferences(0).edit().putBoolean("remoteActive", false).apply()
                    restoreFabAfterManual()
                    loadCards()
                }
                "error" -> {
                    manualRecording = false
                    restoreFabAfterManual()
                    Toast.makeText(this@MainActivity, "Не удалось открыть микрофон", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    private val remoteRecordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context, intent: Intent) {
            remoteRecording = intent.getBooleanExtra("active", false)
            remoteRecordingSource = intent.getStringExtra("source") ?: ""
            getPreferences(0).edit()
                .putBoolean("remoteActive", remoteRecording)
                .putString("remoteSource", remoteRecordingSource)
                .apply()
            if (remoteRecording && !manualRecording) {
                showManualRing(remoteRecordingSource)
            } else if (!remoteRecording && !manualRecording) {
                restoreFabAfterManual()
            }
        }
    }

    
    // Lumina palette
    private val bg = Color.parseColor("#05060A")
    private val panel = Color.parseColor("#0E1118")
    private val panelElevated = Color.parseColor("#161B26")
    private val stroke = Color.parseColor("#252B3A")
    private val primaryText = Color.parseColor("#E8ECF4")
    private val muted = Color.parseColor("#7A8499")
    private val accent = Color.parseColor("#00E5C3")
    private val accentSoft = Color.parseColor("#0A2A28")
    private val danger = Color.parseColor("#F87171")
    private val success = Color.parseColor("#34D399")
    private val navBarColor = Color.argb(200, 8, 12, 18)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }

        isListening = getPreferences(0).getBoolean("running", false)
        buildUi()
        val receiverFlags = if (android.os.Build.VERSION.SDK_INT >= 33) {
            android.content.Context.RECEIVER_NOT_EXPORTED
        } else 0
        androidx.core.content.ContextCompat.registerReceiver(
            this,
            manualStateReceiver,
            IntentFilter(ManualRecordingService.ACTION_STATE),
            receiverFlags
        )
        androidx.core.content.ContextCompat.registerReceiver(
            this,
            remoteRecordingReceiver,
            IntentFilter(WearDataService.ACTION_REMOTE_RECORDING),
            receiverFlags
        )
        manualRecording = ManualRecordingService.isRunning
        remoteRecording = getPreferences(0).getBoolean("remoteActive", false)
        remoteRecordingSource = getPreferences(0).getString("remoteSource", "") ?: ""
        if (manualRecording) showManualRing("phone")
        else if (remoteRecording) showManualRing(remoteRecordingSource)
        refreshLoop()
        DigestAlarmReceiver.schedule(this)

        lifecycleScope.launch {
            WearBridge.syncCards(this@MainActivity, EchoDb.get(this@MainActivity).cards().all())
            MemoryExtraction.runIfDue(this@MainActivity)
            if (selectedTab == 2) loadMemory()
            else if (selectedTab == 1) loadAnalysis()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(
        color: Int,
        radius: Int = 18,
        strokeColor: Int? = null,
        strokeWidthDp: Int = 1
    ): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) {
                setStroke(dp(strokeWidthDp), strokeColor)
            }
        }

    private fun label(value: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            includeFontPadding = false
            letterSpacing = 0.01f
        }

    private fun sectionTitle(value: String): TextView =
        label(value.uppercase(Locale.getDefault()), 11f, accent).apply {
            letterSpacing = 0.12f
            setPadding(dp(4), dp(4), dp(4), dp(8))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }

    private fun primaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            letterSpacing = 0.04f
            background = rounded(accent, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun secondaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(primaryText)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = rounded(panelElevated, 14, stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(bg)
        }
        rootContainer = root

        // Main vertical stack
        val stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Top inset so logo clears status bar / clock
            val topInset = statusBarInset()
            setPadding(dp(20), topInset + dp(8), dp(20), 0)
        }

        // —— Premium header: transparent logo + compact search action ——
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        brandLogo = ImageView(this).apply {
            setImageResource(R.drawable.echo_logo_premium)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Эхо"
        }
        header.addView(brandLogo, LinearLayout.LayoutParams(dp(112), dp(52)))

        val headerSpacer = Space(this)
        header.addView(headerSpacer, LinearLayout.LayoutParams(0, dp(52), 1f))

        val searchButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            contentDescription = "Поиск"
            background = rounded(Color.TRANSPARENT, 50)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(primaryText)
            setOnClickListener {
                if (searchField.visibility == View.VISIBLE) {
                    searchField.text?.clear()
                    searchField.visibility = View.GONE
                    currentSearchQuery = ""
                    loadCards()
                } else {
                    searchField.visibility = View.VISIBLE
                    searchField.requestFocus()
                    val imm = getSystemService(android.view.inputmethod.InputMethodManager::class.java)
                    imm?.showSoftInput(searchField, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                }
            }
        }
        header.addView(searchButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply {
            marginEnd = dp(2)
        })

        stack.addView(header, LinearLayout.LayoutParams(-1, dp(56)).apply {
            bottomMargin = dp(2)
        })

        searchField = EditText(this).apply {
            hint = ""
            setHintTextColor(Color.TRANSPARENT)
            setTextColor(primaryText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.argb(180, 14, 17, 24), 18, Color.argb(90, 0, 229, 195))
            visibility = View.GONE
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s?.toString()?.trim() ?: ""
                    currentSearchQuery = query
                    filterCards(query)
                }
            })
        }
        stack.addView(searchField, LinearLayout.LayoutParams(-1, dp(46)).apply {
            bottomMargin = dp(4)
        })

        // —— Swipeable page host ——
        pageContainer = SwipePageContainer(this)
        contentHost = FrameLayout(this)
        cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(180))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(cards)
        }
        contentHost.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        pageContainer.addView(contentHost, FrameLayout.LayoutParams(-1, -1))
        attachPageSwipe(pageContainer)
        stack.addView(pageContainer, LinearLayout.LayoutParams(-1, 0, 1f))

        mainContentView = stack
        root.addView(stack, FrameLayout.LayoutParams(-1, -1))

        // —— Airy premium recorder button: transparent artwork changes with state ——
        (root as? ViewGroup)?.clipChildren = false
        fabContainer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        ringView = EchoRingView(this).apply {
            visibility = View.INVISIBLE
            alpha = 0f
            isClickable = true
            // Once manual/remote recording is active, the visible ring itself
            // is the only stop control. This bypasses the drag gesture state
            // on the parent container, so stopping requires exactly one tap.
            setOnClickListener {
                if (manualRecording) {
                    stopManualRecording()
                } else if (remoteRecording) {
                    WearBridge.sendRecordingStop(this@MainActivity)
                }
            }
        }
        fabButton = ImageView(this).apply {
            setImageResource(R.drawable.echo_idle)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Начать запись"
            elevation = dp(10).toFloat()
        }
        fabContainer.addView(ringView, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        fabContainer.addView(fabButton, FrameLayout.LayoutParams(dp(148), dp(148), Gravity.CENTER))
        attachFabGesture(fabContainer)
        val fabParams = FrameLayout.LayoutParams(dp(160), dp(160), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabParams.bottomMargin = dp(56) + navBarInset()
        root.addView(fabContainer, fabParams)
        fabContainer.elevation = dp(24).toFloat()

        // —— Thin translucent nav bar ——
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10) + navBarInset())
            // Frosted bar: translucent gray (true backdrop-blur needs API 31
            // window blur which is device-dependent; alpha keeps content readable).
            setBackgroundColor(navBarColor)
            elevation = dp(8).toFloat()
        }

        navIcons.clear()
        listOf(
            R.drawable.ic_nav_feed to 0,
            R.drawable.ic_nav_analysis to 1,
            R.drawable.ic_nav_memory to 2
        ).forEach { (iconRes, tab) ->
            val iv = ImageView(this).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setColorFilter(muted)
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { selectTab(tab, animate = true) }
            }
            navIcons.add(iv)
            nav.addView(iv, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        root.addView(nav, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        applyFabListeningState(animated = false)
        selectTab(0, animate = false)
    }

    private fun statusBarInset(): Int {
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(28)
    }

    private fun navBarInset(): Int {
        val resId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(8)
    }

    private fun attachPageSwipe(target: SwipePageContainer) {
        var downX = 0f
        var downY = 0f
        var dragging = false

        fun handle(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    contentHost.animate().cancel()
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    if (!dragging) return false
                    // Once the parent has intercepted a horizontal gesture,
                    // keep the page exactly under the finger.
                    contentHost.translationX = dx
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!dragging) return false
                    val dx = event.rawX - downX
                    val width = target.width.coerceAtLeast(1)
                    val threshold = width * 0.22f
                    val next = when {
                        dx < -threshold && selectedTab < 2 -> selectedTab + 1
                        dx > threshold && selectedTab > 0 -> selectedTab - 1
                        else -> -1
                    }
                    if (next >= 0) {
                        val direction = if (next > selectedTab) 1 else -1
                        contentHost.animate()
                            .translationX(if (direction > 0) -width.toFloat() else width.toFloat())
                            .setDuration(170)
                            .withEndAction {
                                loadTabContent(next)
                                selectedTab = next
                                updateNavSelection()
                                contentHost.translationX = if (direction > 0) width.toFloat() else -width.toFloat()
                                contentHost.animate().translationX(0f).setDuration(170).start()
                            }.start()
                    } else {
                        contentHost.animate().translationX(0f).setDuration(180).start()
                    }
                    dragging = false
                    return true
                }
            }
            return false
        }

        target.swipeInterceptListener = { event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                contentHost.animate().cancel()
                false
            } else if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                // Clear horizontal intent: modest dead-zone + stronger dx dominance
                // so page swipe coexists with vertical scroll and card left/right swipes.
                if (!dragging && abs(dx) > dp(12) && abs(dx) > abs(dy) * 1.35f) {
                    dragging = true
                    target.requestDisallowInterceptTouchEvent(true)
                    true
                } else dragging
            } else dragging
        }
        target.swipeTouchListener = { event -> handle(event) }
    }

    private fun updateNavSelection() {
        navIcons.forEachIndexed { index, iv ->
            val active = index == selectedTab
            iv.setColorFilter(if (active) accent else muted)
            iv.animate().scaleX(if (active) 1.12f else 1f).scaleY(if (active) 1.12f else 1f)
                .setDuration(160).start()
        }
    }

    private fun selectTab(tab: Int, animate: Boolean = true) {
        if (tab == selectedTab && animate) {
            loadTabContent(tab)
            updateNavSelection()
            return
        }
        val direction = if (tab > selectedTab) 1 else -1
        selectedTab = tab
        updateNavSelection()
        if (tab != 0) searchField.visibility = View.GONE

        if (!animate) {
            loadTabContent(tab)
            contentHost.translationX = 0f
            contentHost.alpha = 1f
            return
        }

        contentHost.animate()
            .translationX(-direction * dp(40).toFloat())
            .alpha(0f)
            .setDuration(140)
            .withEndAction {
                loadTabContent(tab)
                contentHost.translationX = direction * dp(40).toFloat()
                contentHost.animate()
                    .translationX(0f)
                    .alpha(1f)
                    .setDuration(180)
                    .start()
            }
            .start()
    }

    private fun loadTabContent(tab: Int) {
        when (tab) {
            0 -> if (currentSearchQuery.isBlank()) loadCards() else filterCards(currentSearchQuery)
            1 -> loadAnalysis()
            2 -> loadMemory()
        }
    }

    private fun addEmpty(message: String) {
        cards.addView(label(message, 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(48), dp(12), dp(48))
            setLineSpacing(0f, 1.25f)
        })
    }

    private fun cardMeta(c: SpeechCard): String {
        val fmt = SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault())
        val source = if (c.audioPath?.substringAfterLast('/')?.startsWith("watch_") == true) {
            "  ·  с часов"
        } else ""
        return fmt.format(Date(c.createdAt)) + source
    }

    private fun loadCards() {
        lifecycleScope.launch {
            val list = EchoDb.get(this@MainActivity).cards().all()
            WearBridge.syncCards(this@MainActivity, list)
            cards.removeAllViews()
            if (list.isEmpty()) {
                addEmpty("Тишина.\nНажми кольцо — и Эхо начнёт слушать.")
                return@launch
            }
            list.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(18), dp(16), dp(18), dp(16))
                    background = rounded(panelElevated, 20, stroke)
                    elevation = dp(2).toFloat()
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(cardMeta(c), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    setLineSpacing(0f, 1.28f)
                })
                if (c.pendingUpload) {
                    val upload = ImageButton(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_upload_queue)
                        contentDescription = "Отправить запись"
                        background = rounded(Color.TRANSPARENT, 50)
                        setPadding(dp(6), dp(6), dp(6), dp(6))
                        setColorFilter(accent)
                        alpha = if (hasInternet()) 0.72f else 0.30f
                        setOnClickListener { uploadOfflineCard(c, this) }
                    }
                    val actionRow = FrameLayout(this@MainActivity).apply {
                        setPadding(0, dp(6), 0, 0)
                    }
                    actionRow.addView(upload, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.END))
                    card.addView(actionRow)
                }
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun loadAnalysis() {
        cards.removeAllViews()
        addDaySummarySection()
    }

    private fun loadMemory() {
        cards.removeAllViews()
        addMemoryRefreshButton()

        lifecycleScope.launch {
            val facts = EchoDb.get(this@MainActivity).memory().all()
            if (facts.isEmpty()) {
                addEmpty("Память пуста.\nФакты появятся после разговоров.")
                return@launch
            }

            var lastCategory = ""
            facts.forEach { f ->
                if (f.category != lastCategory) {
                    lastCategory = f.category
                    cards.addView(sectionTitle(f.category.replaceFirstChar { it.uppercase() }))
                }
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(18), dp(15), dp(18), dp(15))
                    background = rounded(panelElevated, 18, stroke)
                }
                row.addView(label(f.subject, 12f, muted).apply {
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                })
                row.addView(label(f.fact, 15f, primaryText).apply {
                    setPadding(0, dp(6), 0, 0)
                    setLineSpacing(0f, 1.25f)
                })
                cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
            }
        }
    }

    // "Анализ дня" -- an artistic recap of today's cards, sitting above the
    // long-term memory list. Shows the cached digest instantly (if any) while
    // a fresh one is fetched in the background, throttled to once an hour.
    private fun addDaySummarySection() {
        cards.addView(sectionTitle("Анализ дня"))

        val body = label("Собираю впечатления за сегодня...", 15f, primaryText).apply {
            setLineSpacing(0f, 1.3f)
        }
        val caption = label("", 11f, muted).apply { setPadding(0, dp(10), 0, 0) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(panelElevated, 20, stroke)
        }
        card.addView(body)
        card.addView(caption)
        cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(20)
        })

        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        fun show(result: DaySummary.Result) {
            body.text = result.text
            caption.text = "Обновлено в ${timeFmt.format(Date(result.generatedAt))}" +
                if (result.isFinal) " · итог дня зафиксирован" else ""
        }

        lifecycleScope.launch {
            // Avoid a "Собираю..." flash on every reopen if we already have something.
            val cachedResult = DaySummary.cached(this@MainActivity)
            cachedResult?.let { show(it) }

            val result = DaySummary.runIfDue(this@MainActivity)
            if (result != null) {
                show(result)
            } else if (cachedResult == null) {
                body.text = "Пока рановато подводить итоги — скажи что-нибудь вслух."
                caption.text = ""
            }
        }
    }

    private fun addMemoryRefreshButton() {
        val row = FrameLayout(this).apply {
            minimumHeight = dp(42)
        }
        val refresh = ImageButton(this).apply {
            setImageResource(R.drawable.ic_refresh)
            contentDescription = "Обновить память"
            background = rounded(Color.TRANSPARENT, 50)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setColorFilter(muted)
            elevation = dp(2).toFloat()
        }
        refresh.setOnClickListener {
            refresh.isEnabled = false
            refresh.animate().rotationBy(360f).setDuration(420).start()
            lifecycleScope.launch {
                val added = MemoryExtraction.runNow(this@MainActivity)
                Toast.makeText(
                    this@MainActivity,
                    if (added > 0) "Новых фактов: $added" else "Новых фактов не найдено",
                    Toast.LENGTH_SHORT
                ).show()
                refresh.isEnabled = true
                if (selectedTab == 2) loadMemory()
            }
        }
        row.addView(refresh, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.TOP))
        cards.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply {
            bottomMargin = dp(2)
        })
    }

    // Tap = play back the recording (tap again while it's playing = stop it),
    // long-press = copy the text, swipe left = delete the card + its audio,
    // swipe right = toggle favorite (snaps back, doesn't remove the card).
    private fun attachCardGestures(view: View, card: SpeechCard, star: TextView) {
        var isFavorite = card.favorite

        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playingCardId == card.id && isPlaying) {
                    stopPlayback()
                } else {
                    playCard(card)
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Эхо", card.text))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            }
        })

        var downX = 0f
        var downY = 0f
        var dragging = false
        var touchMode = false
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    touchMode = true
                    pageContainer.cardGestureActive = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!touchMode) return@setOnTouchListener false
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    val ax = abs(dx)
                    val ay = abs(dy)
                    // Give vertical gestures to ScrollView. We only capture a swipe
                    // after a clear horizontal intent, with a generous dead zone.
                    if (!dragging && maxOf(ax, ay) > touchSlop + dp(10)) {
                        if (ax > dp(18) && ax > ay * 1.30f) {
                            dragging = true
                            v.parent.requestDisallowInterceptTouchEvent(true)
                        } else if (ay > ax * 1.35f) {
                            touchMode = false
                            v.parent.requestDisallowInterceptTouchEvent(false)
                            return@setOnTouchListener false
                        }
                    }
                    if (dragging) {
                        v.translationX = dx
                        // Fade only previews the delete (left) direction.
                        v.alpha = if (dx < 0) {
                            1f - (-dx / v.width.coerceAtLeast(1)).coerceIn(0f, 0.8f)
                        } else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!touchMode) {
                        pageContainer.cardGestureActive = false
                        return@setOnTouchListener false
                    }
                    if (dragging) {
                        val dx = event.rawX - downX
                        when {
                            dx < -v.width * 0.40f -> {
                                v.animate().translationX(-v.width.toFloat()).alpha(0f)
                                    .setDuration(180)
                                    .withEndAction { deleteCard(card, v) }
                                    .start()
                            }
                            dx > v.width * 0.30f -> {
                                isFavorite = !isFavorite
                                star.text = if (isFavorite) "★" else ""
                                lifecycleScope.launch {
                                    EchoDb.get(this@MainActivity).cards().setFavorite(card.id, isFavorite)
                                }
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                            else -> {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                        }
                    }
                    dragging = false
                    touchMode = false
                    pageContainer.cardGestureActive = false
                    v.parent.requestDisallowInterceptTouchEvent(false)
                    true
                }
                else -> touchMode
            }
        }
    }

    private fun deleteCard(card: SpeechCard, view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
        stopPlayback()
        lifecycleScope.launch {
            EchoDb.get(this@MainActivity).cards().delete(card.id)
            card.audioPath?.let { path -> try { File(path).delete() } catch (_: Exception) {} }
        }
    }

    // Raw 16 kHz / mono / 16-bit PCM playback of a card's saved recording.
    private var playThread: Thread? = null
    @Volatile private var isPlaying = false
    @Volatile private var playingCardId: Long? = null

    private fun playCard(card: SpeechCard) {
        val path = card.audioPath
        if (path == null) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists() || file.length() == 0L) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }

        stopPlayback()
        isPlaying = true
        playingCardId = card.id
        playThread = Thread {
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    16000,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096),
                    AudioTrack.MODE_STREAM
                )
                track.play()
                file.inputStream().use { input ->
                    val buf = ByteArray(3200)
                    while (isPlaying) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        track.write(buf, 0, n)
                    }
                }
                track.stop()
                track.release()
            } catch (e: Exception) {
                android.util.Log.e("EchoPlayback", "Playback failed", e)
            } finally {
                isPlaying = false
                if (playingCardId == card.id) playingCardId = null
            }
        }
        playThread?.start()
    }

    private fun stopPlayback() {
        isPlaying = false
        try { playThread?.join(200) } catch (_: Exception) {}
        playThread = null
        playingCardId = null
    }

    override fun onDestroy() {
        try { unregisterReceiver(manualStateReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(remoteRecordingReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onStop() {
        stopPlayback()
        if (qaActive) stopLiveQA()
        super.onStop()
    }

    private fun refreshLoop() {
        lifecycleScope.launch {
            while (!isFinishing) {
                if (!manualRecording && !ManualRecordingService.isRunning) {
                    val remote = getPreferences(0).getBoolean("remoteActive", false)
                    if (remote != remoteRecording) {
                        remoteRecording = remote
                        remoteRecordingSource = getPreferences(0).getString("remoteSource", "") ?: ""
                        if (remote) showManualRing(remoteRecordingSource) else restoreFabAfterManual()
                    }
                }
                if (selectedTab == 0) {
                    if (currentSearchQuery.isBlank()) loadCards()
                    else filterCards(currentSearchQuery)
                }
                delay(500)
            }
        }
    }

    private fun toggle() {
        val running = getPreferences(0).getBoolean("running", false)
        val intent = Intent(this, ListeningService::class.java).apply {
            action = if (running) "stop" else "start"
        }
        if (running) stopService(intent) else startForegroundService(intent)
        getPreferences(0).edit().putBoolean("running", !running).apply()
        isListening = !running
        applyFabListeningState(animated = true)
    }

    private fun applyFabListeningState(animated: Boolean) {
        val res = if (isListening) R.drawable.echo_recording else R.drawable.echo_idle
        fabButton.contentDescription = if (isListening) "Остановить запись" else "Начать запись"
        if (!animated) {
            fabButton.setImageResource(res)
            return
        }
        fabButton.animate()
            .scaleX(0.82f).scaleY(0.82f).alpha(0.55f)
            .setDuration(90)
            .withEndAction {
                fabButton.setImageResource(res)
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(170).start()
            }
            .start()
    }

    private fun attachFabGesture(fab: View) {
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (fabDraggingUp) return true
                if (manualRecording) stopManualRecording()
                else if (remoteRecording) WearBridge.sendRecordingStop(this@MainActivity)
                else if (qaActive) stopLiveQA() else toggle()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!manualRecording && !qaActive) startLiveQA()
            }
        })
        var fabTouchActive = false
        val fabHitRadius = dp(76).toFloat()

        fab.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // The visual container is intentionally larger than the actual
                    // touch target. Ignore taps in the surrounding empty area so the
                    // tab bar and the ScrollView keep receiving their own gestures.
                    val cx = v.width / 2f
                    val cy = v.height / 2f
                    val x = event.x - cx
                    val y = event.y - cy
                    fabTouchActive = x * x + y * y <= fabHitRadius * fabHitRadius
                    if (!fabTouchActive) return@setOnTouchListener false
                    gesture.onTouchEvent(event)
                    fabDownX = event.rawX
                    fabDownY = event.rawY
                    fabDraggingUp = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fabTouchActive) return@setOnTouchListener false
                    gesture.onTouchEvent(event)
                    val dy = event.rawY - fabDownY
                    val dx = event.rawX - fabDownX
                    val pull = (-dy / dp(120).toFloat()).coerceIn(0f, 1.35f)

                    // Before activation the button follows the finger, as if the ring
                    // has a little elastic mass attached to it. The farther upward the
                    // finger travels, the more the object stretches toward the gesture.
                    if (!fabDraggingUp) {
                        val visualPull = pull.coerceIn(0f, 1f)
                        v.translationY = (dy * 0.58f).coerceAtLeast(-dp(58).toFloat())
                        v.scaleX = 1f + visualPull * 0.055f
                        v.scaleY = 1f + visualPull * 0.055f
                    }

                    if (!fabDraggingUp && dy < -dp(42) && abs(dy) > abs(dx) * 1.15f) {
                        fabDraggingUp = true
                        if (!manualRecording && !qaActive) startManualRecording()
                        v.animate().translationY(-dp(82).toFloat()).setDuration(180)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                        ringView.animate().translationY(0f).scaleX(1.035f).scaleY(1.035f)
                            .setDuration(180)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    }

                    if (fabDraggingUp) {
                        // After activation the whole hit target moves with the ring.
                        // This makes the visible ring itself the stop button.
                        val ringPull = ((-dy - dp(42)) / dp(140).toFloat()).coerceIn(0f, 1f)
                        v.translationY = (-dp(82) - dp(18) * ringPull).toFloat()
                        ringView.translationY = 0f
                        ringView.scaleX = 1f + 0.035f * ringPull
                        ringView.scaleY = 1f + 0.035f * ringPull
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!fabTouchActive) return@setOnTouchListener false
                    gesture.onTouchEvent(event)
                    fabTouchActive = false
                    if (fabDraggingUp) {
                        // Keep the entire touch target exactly under the visible ring.
                        v.animate().translationY(-dp(82).toFloat()).scaleX(1f).scaleY(1f)
                            .setDuration(180)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                        ringView.animate().translationY(0f).scaleX(1.035f).scaleY(1.035f)
                            .setDuration(180).start()
                    } else {
                        v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(180).start()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun hasInternet(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun startManualRecording() {
        if (manualRecording || remoteRecording || qaActive) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
            Toast.makeText(this, "Разреши доступ к микрофону", Toast.LENGTH_SHORT).show()
            return
        }

        if (isListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
            getPreferences(0).edit().putBoolean("running", false).apply()
            isListening = false
        }

        manualRecording = true
        showManualRing()

        val intent = Intent(this, ManualRecordingService::class.java).apply {
            action = ManualRecordingService.ACTION_START
        }
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun showManualRing(source: String = "phone") {
        fabButton.animate().cancel()
        fabButton.visibility = View.INVISIBLE
        fabButton.alpha = 0f
        ringView.visibility = View.VISIBLE
        ringView.alpha = 1f
        ringView.translationY = 0f
        ringView.scaleX = 1.035f
        ringView.scaleY = 1.035f
        ringView.setMode(EchoRingView.MODE_LISTENING)
        ringView.start()
        fabContainer.bringToFront()
        fabContainer.elevation = dp(40).toFloat()
        if (manualRecording || source == "watch") {
            fabContainer.translationY = -dp(82).toFloat()
        }
        if (!manualUiLocked) setManualUiLocked(true)
        if (source == "watch") {
            ringView.contentDescription = "Остановить запись с часов"
        } else {
            ringView.contentDescription = "Остановить ручную запись"
        }
        try {
            fabContainer.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        } catch (_: Exception) {}
    }

    private fun stopManualRecording() {
        if (!manualRecording && !ManualRecordingService.isRunning) return
        manualRecording = false
        startService(
            Intent(this, ManualRecordingService::class.java).apply {
                action = ManualRecordingService.ACTION_STOP
            }
        )
    }

    private fun restoreFabAfterManual() {
        setManualUiLocked(false)
        ringView.setAudioLevel(0f)
        ringView.setMode(EchoRingView.MODE_CLOSING)
        ringView.stop()
        ringView.animate().alpha(0f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(150)
            .withEndAction {
                ringView.visibility = View.INVISIBLE
                fabButton.visibility = View.VISIBLE
                fabButton.alpha = 0f
                fabButton.scaleX = 0f
                fabButton.scaleY = 0f
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
                fabContainer.animate().translationY(0f).setDuration(120).start()
                applyFabListeningState(animated = false)
            }.start()
    }

    private fun setManualUiLocked(locked: Boolean) {
        manualUiLocked = locked
        val root = rootContainer
        if (locked) {
            if (manualLockOverlay == null) {
                manualLockOverlay = View(this).apply {
                    setBackgroundColor(Color.argb(92, 7, 8, 11))
                    setOnTouchListener { _, _ -> true }
                }
                root.addView(manualLockOverlay, FrameLayout.LayoutParams(-1, -1))
            }
            manualLockOverlay?.visibility = View.VISIBLE
            manualLockOverlay?.alpha = 0f
            manualLockOverlay?.animate()?.alpha(1f)?.setDuration(180)?.start()
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                mainContentView.setRenderEffect(android.graphics.RenderEffect.createBlurEffect(13f, 13f, android.graphics.Shader.TileMode.CLAMP))
            }
            if (manualLockIcon == null) {
                manualLockIcon = ImageView(this).apply {
                    setImageResource(R.drawable.ic_lock_flat)
                    setColorFilter(Color.WHITE)
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                    isClickable = false
                }
                fabContainer.addView(manualLockIcon, FrameLayout.LayoutParams(dp(32), dp(26), Gravity.CENTER).apply {
                    topMargin = dp(88)
                })
            }
            manualLockIcon?.visibility = View.VISIBLE
            fabContainer.bringToFront()
            fabContainer.elevation = dp(40).toFloat()
        } else {
            manualLockOverlay?.visibility = View.GONE
            if (android.os.Build.VERSION.SDK_INT >= 31) mainContentView.setRenderEffect(null)
            manualLockIcon?.visibility = View.GONE
            fabContainer.elevation = dp(24).toFloat()
        }
    }

    private fun uploadOfflineCard(card: SpeechCard, button: View) {
        if (!hasInternet()) {
            Toast.makeText(this, "Интернет пока недоступен", Toast.LENGTH_SHORT).show()
            return
        }
        val path = card.audioPath
        if (path.isNullOrBlank()) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(this, "Файл записи не найден", Toast.LENGTH_SHORT).show()
            return
        }
        button.isEnabled = false
        button.animate().rotationBy(360f).setDuration(650).start()
        lifecycleScope.launch {
            val result = Gemini.transcribeOfflinePcm(file)
            if (result.isSuccess) {
                EchoDb.get(this@MainActivity).cards().updateTranscription(card.id, result.getOrThrow(), false)
                Toast.makeText(this@MainActivity, "Расшифровка готова", Toast.LENGTH_SHORT).show()
                loadCards()
            } else {
                button.isEnabled = true
                Toast.makeText(this@MainActivity, "Не удалось отправить · попробуй позже", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Volatile private var qaActive = false
    @Volatile private var qaRecording = false
    private var qaRecordThread: Thread? = null
    private var qaOverlay: View? = null
    private var qaStatus: TextView? = null
    private var qaAnswer: TextView? = null

    // Live QA model audio playback (Gemini Live returns 24 kHz PCM mono).
    private var qaTrack: AudioTrack? = null
    private val qaTrackLock = Any()

    // Two AudioRecord sessions on the mic at once is unreliable across
    // devices -- pause background listening while a question is being asked,
    // and always resume it (if it was running) once the overlay closes.
    private var qaPausedBackgroundListening = false

    private fun startLiveQA() {
        qaActive = true
        // Haptic tick
        try {
            fabContainer.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        } catch (_: Exception) {}

        qaPausedBackgroundListening = getPreferences(0).getBoolean("running", false)
        if (qaPausedBackgroundListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
        }

        // Dot shrinks away → premium animated ring appears
        fabButton.animate()
            .scaleX(0f).scaleY(0f).alpha(0f)
            .setDuration(180)
            .withEndAction {
                fabButton.visibility = View.INVISIBLE
                ringView.visibility = View.VISIBLE
                ringView.alpha = 0f
                ringView.bringToFront()
                fabContainer.bringToFront()
                ringView.animate().alpha(1f).setDuration(240).start()
                ringView.setMode(EchoRingView.MODE_CONNECTING)
                ringView.start()
            }
            .start()

        showQaPanel()
        ensureQaTrack()

        lifecycleScope.launch {
            val context = LiveQaContext.build(this@MainActivity)
            val ready = LiveQA.start(
                systemContext = context,
                onAnswerChunk = { pcm ->
                    writeQaAudio(pcm)
                    runOnUiThread {
                        ringView.setMode(EchoRingView.MODE_RESPONDING)
                        qaStatus?.text = "Эхо отвечает..."
                    }
                },
                onSubtitleChunk = { text ->
                    runOnUiThread { qaAnswer?.append(text) }
                },
                onTurnComplete = {
                    runOnUiThread {
                        ringView.setMode(EchoRingView.MODE_LISTENING)
                        qaStatus?.text = "Слушаю…"
                    }
                }
            )
            if (!qaActive) return@launch
            if (!ready) {
                runOnUiThread { qaStatus?.text = "Не удалось подключиться" }
                return@launch
            }
            runOnUiThread {
                ringView.setMode(EchoRingView.MODE_LISTENING)
                qaStatus?.text = "Слушаю…"
            }
            beginQaRecording()
        }
    }

    private fun stopLiveQA() {
        qaActive = false
        qaRecording = false
        LiveQA.stop()
        releaseQaTrack()
        closeQaPanel()
        // Animated ring → dot
        ringView.setAudioLevel(0f)
        ringView.setMode(EchoRingView.MODE_CLOSING)
        ringView.stop()
        ringView.animate()
            .alpha(0f)
            .setDuration(180)
            .withEndAction {
                ringView.visibility = View.INVISIBLE
                fabButton.visibility = View.VISIBLE
                fabButton.alpha = 0f
                fabButton.scaleX = 0f
                fabButton.scaleY = 0f
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200).start()
                applyFabListeningState(animated = false)
            }
            .start()
        if (qaPausedBackgroundListening) {
            qaPausedBackgroundListening = false
            startForegroundService(Intent(this, ListeningService::class.java).apply { action = "start" })
        }
    }

    private fun ensureQaTrack() {
        synchronized(qaTrackLock) {
            if (qaTrack != null) return
            // Gemini Live AUDIO modality delivers 24 kHz 16-bit mono PCM.
            val sampleRate = 24000
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4800),
                AudioTrack.MODE_STREAM
            )
            track.play()
            qaTrack = track
        }
    }

    private fun writeQaAudio(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        synchronized(qaTrackLock) {
            val track = qaTrack ?: return
            try {
                track.write(pcm, 0, pcm.size)
            } catch (e: Exception) {
                android.util.Log.e("EchoLiveQA", "writeQaAudio failed", e)
            }
        }
    }

    private fun releaseQaTrack() {
        synchronized(qaTrackLock) {
            try {
                qaTrack?.stop()
            } catch (_: Exception) {}
            try {
                qaTrack?.release()
            } catch (_: Exception) {}
            qaTrack = null
        }
    }

    private fun beginQaRecording() {
        qaRecording = true
        qaRecordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(6400, minBuf)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return@Thread
            }
            ar.startRecording()
            try {
                val buf = ShortArray(320)
                while (qaRecording) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    // Drive the Live QA ring from the real microphone energy.
                    // RMS is normalized to 0..1 and smoothed inside EchoRingView.
                    var sumSquares = 0.0
                    for (k in 0 until n) {
                        val sample = buf[k].toDouble() / 32768.0
                        sumSquares += sample * sample
                    }
                    val rms = sqrt(sumSquares / n.coerceAtLeast(1))
                    val voiceLevel = (rms * 7.5).coerceIn(0.0, 1.0).toFloat()
                    runOnUiThread {
                        ringView.setAudioLevel(if (LiveQA.modelSpeaking) 0f else voiceLevel)
                    }

                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    LiveQA.sendAudio(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }
        qaRecordThread?.start()
    }

    // filterCards: re-renders the cards list filtered by query (case-insensitive substring match).
    // Empty query restores the full list for the current tab.
    private fun filterCards(query: String) {
        if (query.isEmpty()) {
            when (selectedTab) {
                0 -> loadCards()
                1 -> loadAnalysis()
                2 -> loadMemory()
            }
            return
        }
        lifecycleScope.launch {
            val db = EchoDb.get(this@MainActivity)
            val lower = query.lowercase()
            val results = db.cards().all().filter { it.text.lowercase().contains(lower) }
            cards.removeAllViews()
            if (results.isEmpty()) {
                addEmpty("Ничего не найдено по запросу «$query»")
                return@launch
            }
            results.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(18), dp(16), dp(18), dp(16))
                    background = rounded(panelElevated, 20, stroke)
                    elevation = dp(2).toFloat()
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(cardMeta(c), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    setLineSpacing(0f, 1.28f)
                })
                if (c.pendingUpload) {
                    val upload = ImageButton(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_upload_queue)
                        contentDescription = "Отправить запись"
                        background = rounded(Color.TRANSPARENT, 50)
                        setPadding(dp(6), dp(6), dp(6), dp(6))
                        setColorFilter(accent)
                        alpha = if (hasInternet()) 0.72f else 0.30f
                        setOnClickListener { uploadOfflineCard(c, this) }
                    }
                    val actionRow = FrameLayout(this@MainActivity).apply {
                        setPadding(0, dp(6), 0, 0)
                    }
                    actionRow.addView(upload, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.END))
                    card.addView(actionRow)
                }
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    // Bottom Live-QA sheet: edge-to-edge, sits under the 150dp blob.
    private fun showQaPanel() {
        val root = rootContainer

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(16) + navBarInset())
            background = rounded(panelElevated, 24)
            elevation = dp(16).toFloat()
            // Swipe down to close
            var downY = 0f
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = e.rawY - downY
                        if (dy > 0) v.translationY = dy
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (e.rawY - downY > dp(80)) stopLiveQA()
                        else v.animate().translationY(0f).setDuration(160).start()
                        true
                    }
                    else -> false
                }
            }
        }

        val handle = View(this).apply {
            background = rounded(Color.parseColor("#4A5060"), 4)
        }
        panel.addView(handle, LinearLayout.LayoutParams(dp(40), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })

        val status = label("Подключаюсь…", 13f, muted).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        val answer = label("", 16f, primaryText).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(10), 0, dp(8))
            setLineSpacing(0f, 1.35f)
        }
        val scroll = ScrollView(this).apply { addView(answer) }
        panel.addView(status)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Sheet height; blob sits fully above its top edge
        val panelH = (resources.displayMetrics.heightPixels * 0.38f).toInt().coerceAtLeast(dp(240))
        val params = FrameLayout.LayoutParams(-1, panelH, Gravity.BOTTOM)
        panel.translationY = panelH.toFloat()
        root.addView(panel, params)
        panel.bringToFront()
        fabContainer.bringToFront()

        // Lift FAB so the 150dp blob rests just above the sheet (not under it)
        val lift = (panelH - dp(20)).toFloat()
        fabContainer.bringToFront()
        fabContainer.elevation = dp(28).toFloat()
        fabContainer.animate()
            .translationY(-lift)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()

        panel.animate()
            .translationY(0f)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()

        qaPanel = panel
        qaOverlay = panel
        qaStatus = status
        qaAnswer = answer
    }

    private fun closeQaPanel() {
        val panel = qaPanel ?: return
        val h = panel.height.takeIf { it > 0 } ?: dp(300)
        panel.animate()
            .translationY(h.toFloat())
            .setDuration(220)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction { (panel.parent as? ViewGroup)?.removeView(panel) }
            .start()
        // Return FAB to resting position
        fabContainer.animate()
            .translationY(0f)
            .setDuration(220)
            .start()
        qaPanel = null
        qaOverlay = null
        qaStatus = null
        qaAnswer = null
    }

    private object ColorDrawableCompat {
        operator fun invoke(color: Int) = android.graphics.drawable.ColorDrawable(color)
    }
}

/**
 * Lumina Ring — living light source for Live QA & recording.
 *
 * Visual language (intentionally different from previous orbital-filament design):
 *  - soft radial breath waves that expand with voice energy
 *  - multi-layer concentric glow rings with teal → violet morph
 *  - sparse orbiting light motes
 *  - quiet luminous core that brightens while Echo speaks
 *  - continuous morph between listening / responding without view swap
 */
class EchoRingView(context: android.content.Context) : View(context) {
    companion object {
        const val MODE_CONNECTING = 0
        const val MODE_LISTENING = 1
        const val MODE_RESPONDING = 2
        const val MODE_CLOSING = 3
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = android.graphics.BlurMaskFilter(22f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = android.graphics.BlurMaskFilter(6f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val motePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val coreGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = android.graphics.BlurMaskFilter(12f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

    private var phase = 0f
    private var running = false
    private var mode = MODE_CONNECTING
    private var modeBlend = 0f
    private var targetModeBlend = 0f
    @Volatile private var targetAudioLevel = 0f
    private var audioLevel = 0f

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            val modeSpeed = if (mode == MODE_RESPONDING) 0.068f else 0.038f
            phase += modeSpeed + audioLevel * if (mode == MODE_RESPONDING) 0.14f else 0.09f
            audioLevel += (targetAudioLevel - audioLevel) * 0.18f
            modeBlend += (targetModeBlend - modeBlend) * 0.11f
            invalidate()
            postOnAnimation(this)
        }
    }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    fun setAudioLevel(level: Float) {
        targetAudioLevel = level.coerceIn(0f, 1f)
    }

    fun setMode(newMode: Int) {
        mode = newMode
        targetModeBlend = when (newMode) {
            MODE_RESPONDING -> 1f
            MODE_CLOSING -> 0f
            else -> 0f
        }
        invalidate()
    }

    fun start() {
        running = true
        removeCallbacks(frame)
        postOnAnimation(frame)
    }

    fun stop() {
        running = false
        targetAudioLevel = 0f
        audioLevel = 0f
        removeCallbacks(frame)
        invalidate()
    }

    private fun mixColor(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        val ar = Color.red(a); val ag = Color.green(a); val ab = Color.blue(a)
        val br = Color.red(b); val bg = Color.green(b); val bb = Color.blue(b)
        return Color.rgb(
            (ar + (br - ar) * x).toInt(),
            (ag + (bg - ag) * x).toInt(),
            (ab + (bb - ab) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val size = kotlin.math.min(width, height).toFloat()
        if (size <= 0f) return

        val response = modeBlend
        val breath = 0.5f + 0.5f * kotlin.math.sin(phase * if (mode == MODE_RESPONDING) 1.65f else 1.35f)
        val voice = audioLevel * (0.70f + 0.30f * breath)
        val energy = (voice + if (mode == MODE_RESPONDING) 0.18f + 0.10f * breath else 0f).coerceIn(0f, 1f)

        val listenTeal = Color.parseColor("#00E5C3")
        val respondViolet = Color.parseColor("#A78BFA")
        val softWhite = Color.parseColor("#E8F8F6")
        val deepGlow = Color.parseColor("#0A3D38")

        val accent = mixColor(listenTeal, respondViolet, response)
        val accentSoft = mixColor(Color.parseColor("#00C4A8"), Color.parseColor("#8B6CF6"), response)

        val baseR = size * 0.30f
        val r = baseR * (1f + 0.04f * breath + 0.11f * voice + 0.04f * response)

        // Outer soft halo
        haloPaint.color = accent
        haloPaint.strokeWidth = size * (0.10f + 0.07f * energy)
        haloPaint.alpha = (28 + 110 * energy + 16 * breath).toInt().coerceAtMost(190)
        canvas.drawCircle(cx, cy, r * 1.08f, haloPaint)

        // Secondary bloom on response
        if (response > 0.03f) {
            haloPaint.color = respondViolet
            haloPaint.strokeWidth = size * (0.04f + 0.03f * response)
            haloPaint.alpha = (20 + 80 * response).toInt()
            canvas.drawCircle(cx, cy, r * (1.14f + 0.02f * breath), haloPaint)
        }

        // Soft radial waves (3 expanding rings)
        for (i in 0 until 3) {
            val wavePhase = (phase * 0.55f + i * 0.85f) % (Math.PI * 2).toFloat()
            val expand = 0.55f + 0.45f * ((kotlin.math.sin(wavePhase) + 1f) * 0.5f)
            val wr = r * (0.72f + 0.38f * expand + 0.08f * voice)
            wavePaint.color = accent
            wavePaint.strokeWidth = size * (0.006f + 0.005f * energy * (1f - i * 0.2f))
            wavePaint.alpha = ((55 + 70 * energy) * (1f - expand * 0.55f) * (1f - i * 0.18f)).toInt().coerceIn(0, 160)
            canvas.drawCircle(cx, cy, wr, wavePaint)
        }

        // Main solid ring
        ringPaint.color = mixColor(softWhite, accent, 0.35f + 0.45f * response)
        ringPaint.strokeWidth = size * (0.055f + 0.02f * voice)
        ringPaint.alpha = 230
        canvas.drawCircle(cx, cy, r, ringPaint)

        // Inner thin accent ring
        ringPaint.color = accent
        ringPaint.strokeWidth = size * (0.012f + 0.008f * energy)
        ringPaint.alpha = (160 + 70 * energy).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.048f, ringPaint)

        // Orbiting light motes (5)
        motePaint.color = accent
        for (i in 0 until 5) {
            val speed = 0.48f + i * 0.11f + energy * 0.35f
            val a = phase * speed * (if (i % 2 == 0) 1f else -1f) + i * 1.2566f
            val orbit = r * (0.78f + 0.08f * kotlin.math.sin(phase * 1.2f + i) + 0.04f * voice)
            val px = cx + kotlin.math.cos(a.toDouble()).toFloat() * orbit
            val py = cy + kotlin.math.sin(a.toDouble()).toFloat() * orbit
            val moteR = size * (0.011f + 0.009f * energy + 0.004f * breath)
            motePaint.alpha = (90 + 130 * energy).toInt().coerceAtMost(230)
            canvas.drawCircle(px, py, moteR, motePaint)
            // soft mote glow
            motePaint.alpha = (30 + 50 * energy).toInt()
            canvas.drawCircle(px, py, moteR * 2.2f, motePaint)
        }

        // Luminous core
        val pulse = size * (0.048f + 0.055f * voice + 0.022f * response + 0.015f * breath)
        coreGlowPaint.color = accent
        coreGlowPaint.alpha = (60 + 140 * energy).toInt().coerceAtMost(220)
        canvas.drawCircle(cx, cy, pulse * 1.6f, coreGlowPaint)

        corePaint.color = mixColor(softWhite, accent, 0.25f + 0.55f * response)
        corePaint.alpha = (170 + 75 * energy).toInt().coerceAtMost(250)
        canvas.drawCircle(cx, cy, pulse * (0.28f + 0.20f * energy), corePaint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }
}
