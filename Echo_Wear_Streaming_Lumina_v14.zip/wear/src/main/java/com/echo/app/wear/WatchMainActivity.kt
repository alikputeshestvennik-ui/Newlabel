package com.echo.app.wear

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

class WatchMainActivity : Activity() {
    private lateinit var scroll: ScrollView
    private lateinit var recordRing: WatchEchoRingView
    private lateinit var status: TextView
    private lateinit var cardsList: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var recording = false
    @Volatile private var remoteRecording = false
    private var remoteRecordingSource = ""
    private var output: java.io.OutputStream? = null
    private var channel: com.google.android.gms.wearable.ChannelClient.Channel? = null
    private var recordThread: Thread? = null
    private var cards: List<WatchCard> = emptyList()
    private val recordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            when (intent.getStringExtra("state")) {
                "started" -> {
                    recording = true
                    remoteRecording = false
                    recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                    recordRing.start()
                    status.text = "Запись с часов · тап — стоп"
                }
                "level" -> {
                    if (recording) recordRing.setAudioLevel(intent.getFloatExtra("level", 0f))
                }
                "stopped" -> {
                    recording = false
                    remoteRecording = false
                    remoteRecordingSource = ""
                    getSharedPreferences("recording", Context.MODE_PRIVATE).edit().putBoolean("remoteActive", false).apply()
                    recordRing.setAudioLevel(0f)
                    recordRing.setMode(WatchEchoRingView.MODE_CLOSING)
                    handler.postDelayed({ recordRing.stop(); recordRing.setMode(WatchEchoRingView.MODE_CONNECTING) }, 260)
                    status.text = "Передано телефону · готово"
                    loadCards()
                }
                "error" -> {
                    recording = false
                    recordRing.stop()
                    status.text = intent.getStringExtra("message") ?: "Ошибка записи"
                }
            }
        }
    }

    private val remoteRecordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            remoteRecording = intent.getBooleanExtra("active", false)
            remoteRecordingSource = intent.getStringExtra("source") ?: ""
            getSharedPreferences("recording", Context.MODE_PRIVATE).edit()
                .putBoolean("remoteActive", remoteRecording)
                .putString("remoteSource", remoteRecordingSource)
                .apply()
            if (remoteRecording && !WatchRecordingService.isRunning) {
                recording = true
                recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                recordRing.start()
                status.text = if (remoteRecordingSource == "phone") "Запись на телефоне · тап — стоп" else "Идёт запись · тап — стоп"
            } else if (!remoteRecording && !WatchRecordingService.isRunning) {
                recording = false
                recordRing.setAudioLevel(0f)
                recordRing.stop()
                recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
                status.text = "Тап — запись · свайп вверх — карточки"
            }
        }
    }

    data class WatchCard(val id: Long, val text: String, val date: String, val time: String, val favorite: Boolean, val fromWatch: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val flags = if (android.os.Build.VERSION.SDK_INT >= 33) Context.RECEIVER_NOT_EXPORTED else 0
        ContextCompat.registerReceiver(this, recordingReceiver, IntentFilter(WatchRecordingService.ACTION_STATE), flags)
        ContextCompat.registerReceiver(this, remoteRecordingReceiver, IntentFilter(WatchDataService.ACTION_REMOTE_RECORDING), flags)
        syncStateFromPrefs()
        loadCards()
        handler.post(uiTicker)
    }

    override fun onResume() {
        super.onResume()
        syncStateFromPrefs()
        loadCards()
        if (WatchRecordingService.isRunning) {
            recording = true
            remoteRecording = false
            recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
            recordRing.start()
            status.text = "Запись с часов · тап — стоп"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(uiTicker)
        try { unregisterReceiver(recordingReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(remoteRecordingReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private val uiTicker = object : Runnable {
        override fun run() {
            if (isFinishing) return
            syncStateFromPrefs()
            loadCards()
            handler.postDelayed(this, 500L)
        }
    }

    private fun syncStateFromPrefs() {
        val local = WatchRecordingService.isRunning
        val remote = getSharedPreferences("recording", Context.MODE_PRIVATE).getBoolean("remoteActive", false)
        val source = getSharedPreferences("recording", Context.MODE_PRIVATE).getString("remoteSource", "") ?: ""
        if (local) {
            recording = true
            remoteRecording = false
        } else if (remote) {
            val changed = !remoteRecording || remoteRecordingSource != source || !recording
            remoteRecording = true
            remoteRecordingSource = source
            recording = true
            if (changed) {
                recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                recordRing.start()
                status.text = if (source == "phone") "Запись на телефоне · тап — стоп" else "Запись · тап — стоп"
            }
        } else if (remoteRecording && !local) {
            remoteRecording = false
            recording = false
            recordRing.stop()
            recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
            status.text = "Тап — запись · свайп вверх — карточки"
        }
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildUi() {
        scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#05060A"))
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), 0, dp(12f), dp(24f))
        }

        val screenHeightDp = resources.displayMetrics.heightPixels / resources.displayMetrics.density
        val heroHeight = dp(screenHeightDp.coerceAtLeast(300f))
        val hero = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#05060A"))
        }

        val title = TextView(this).apply {
            text = "LUMINA"
            textSize = 10f
            setTextColor(Color.parseColor("#5A6478"))
            gravity = Gravity.CENTER
        }
        hero.addView(title, FrameLayout.LayoutParams(-1, dp(30f), Gravity.TOP))

        recordRing = WatchEchoRingView(this).apply {
            setOnClickListener {
                if (WatchRecordingService.isRunning) stopRecording()
                else if (remoteRecording) WatchDataService.sendRecordingStop(this@WatchMainActivity)
                else startRecording()
            }
            contentDescription = "Запись"
        }
        val ringLp = FrameLayout.LayoutParams(dp(156f), dp(156f), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        hero.addView(recordRing, ringLp)
        hero.post {
            val lp = recordRing.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = ((hero.height - recordRing.height) / 2 - dp(4f)).coerceAtLeast(dp(8f))
            lp.leftMargin = 0
            lp.rightMargin = 0
            recordRing.layoutParams = lp
        }

        status = TextView(this).apply {
            text = "Тап — запись · свайп вверх — карточки"
            textSize = 11f
            setTextColor(Color.parseColor("#7A8499"))
            gravity = Gravity.CENTER
        }
        val statusLp = FrameLayout.LayoutParams(-1, dp(42f), Gravity.BOTTOM)
        statusLp.leftMargin = dp(8f)
        statusLp.rightMargin = dp(8f)
        hero.addView(status, statusLp)

        content.addView(hero, LinearLayout.LayoutParams(-1, heroHeight))

        val cardsTitle = TextView(this).apply {
            text = "ЗАПИСИ"
            textSize = 10f
            setTextColor(Color.parseColor("#5A6478"))
            gravity = Gravity.CENTER
            setPadding(0, dp(2f), 0, dp(10f))
        }
        content.addView(cardsTitle, LinearLayout.LayoutParams(-1, -2))

        cardsList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
        }
        content.addView(cardsList, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)
    }

    private fun loadCards() {
        val json = getSharedPreferences("watch", Context.MODE_PRIVATE).getString("cards", "[]") ?: "[]"
        val parsed = mutableListOf<WatchCard>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                parsed += WatchCard(
                    o.getLong("id"),
                    o.getString("text"),
                    o.optString("date", ""),
                    o.getString("time"),
                    o.getBoolean("favorite"),
                    o.optBoolean("fromWatch", false)
                )
            }
        } catch (_: Exception) { }
        cards = parsed
        if (!::cardsList.isInitialized) return
        cardsList.removeAllViews()
        if (cards.isEmpty()) {
            cardsList.addView(TextView(this).apply {
                text = "Нет карточек"
                textSize = 13f
                setTextColor(Color.parseColor("#5A6478"))
                gravity = Gravity.CENTER
                setPadding(0, dp(18f), 0, dp(36f))
            })
            return
        }

        cards.forEach { card ->
            val cardView = TextView(this).apply {
                val prefix = if (card.favorite) "★ " else ""
                val source = if (card.fromWatch) " · с часов" else ""
                text = "$prefix${card.text}\n${card.date} · ${card.time}$source"
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(20, 20, 23))
                    setStroke(dp(1f), Color.rgb(48, 50, 58))
                    cornerRadius = dp(24f).toFloat()
                }
                isSingleLine = false
                setOnClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "favorite")
                    handler.postDelayed({ loadCards() }, 250)
                }
                setOnLongClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "delete")
                    handler.postDelayed({ loadCards() }, 300)
                    true
                }
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8f)
            lp.leftMargin = dp(8f)
            lp.rightMargin = dp(8f)
            cardsList.addView(cardView, lp)
        }
    }

    private fun startRecording() {
        if (remoteRecording || WatchRecordingService.isRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        if (recording || WatchRecordingService.isRunning || remoteRecording) return
        recording = true
        val intent = android.content.Intent(this, WatchRecordingService::class.java).apply {
            action = WatchRecordingService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
        recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
        recordRing.start()
        status.text = "Подключаюсь к телефону…"
    }

    private fun stopRecording() {
        if (WatchRecordingService.isRunning) {
            recording = false
            startService(android.content.Intent(this, WatchRecordingService::class.java).apply {
                action = WatchRecordingService.ACTION_STOP
            })
        } else if (remoteRecording) {
            WatchDataService.sendRecordingStop(this)
        }
    }

}

private class WatchEchoRingView(context: Context) : View(context) {
    companion object {
        const val MODE_CONNECTING = 0
        const val MODE_LISTENING = 1
        const val MODE_RESPONDING = 2
        const val MODE_CLOSING = 3
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = android.graphics.BlurMaskFilter(14f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val motePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val coreGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = android.graphics.BlurMaskFilter(8f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }

    private var phase = 0f
    private var running = false
    private var mode = MODE_CONNECTING
    @Volatile private var targetAudio = 0f
    private var audio = 0f

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.042f + audio * 0.10f
            audio += (targetAudio - audio) * 0.18f
            invalidate()
            postOnAnimation(this)
        }
    }

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun setAudioLevel(level: Float) { targetAudio = level.coerceIn(0f, 1f) }
    fun setMode(m: Int) { mode = m; invalidate() }
    fun start() { running = true; removeCallbacks(frame); postOnAnimation(frame) }
    fun stop() { running = false; targetAudio = 0f; audio = 0f; removeCallbacks(frame); invalidate() }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * x).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * x).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val size = min(width, height).toFloat()
        if (size <= 0f) return

        val response = if (mode == MODE_RESPONDING) 1f else 0f
        val breath = 0.5f + 0.5f * sin(phase * 1.4f)
        val voice = audio * (0.72f + 0.28f * breath)
        val energy = (voice + response * 0.2f).coerceIn(0f, 1f)

        val teal = Color.parseColor("#00E5C3")
        val violet = Color.parseColor("#A78BFA")
        val accent = mix(teal, violet, response)
        val soft = Color.parseColor("#E8F8F6")

        val baseR = size * 0.30f
        val r = baseR * (1f + 0.04f * breath + 0.10f * voice)

        haloPaint.color = accent
        haloPaint.strokeWidth = size * (0.09f + 0.06f * energy)
        haloPaint.alpha = (30 + 100 * energy).toInt().coerceAtMost(180)
        canvas.drawCircle(cx, cy, r * 1.06f, haloPaint)

        // Soft expanding waves
        for (i in 0 until 2) {
            val wp = (phase * 0.5f + i * 1.0f) % 6.2832f
            val expand = 0.5f + 0.5f * ((sin(wp) + 1f) * 0.5f)
            val wr = r * (0.75f + 0.35f * expand)
            wavePaint.color = accent
            wavePaint.strokeWidth = size * 0.007f
            wavePaint.alpha = ((50 + 60 * energy) * (1f - expand * 0.5f)).toInt().coerceIn(0, 140)
            canvas.drawCircle(cx, cy, wr, wavePaint)
        }

        ringPaint.color = mix(soft, accent, 0.4f)
        ringPaint.strokeWidth = size * (0.05f + 0.018f * voice)
        ringPaint.alpha = 230
        canvas.drawCircle(cx, cy, r, ringPaint)

        ringPaint.color = accent
        ringPaint.strokeWidth = size * (0.01f + 0.006f * energy)
        ringPaint.alpha = (150 + 70 * energy).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.04f, ringPaint)

        // Orbiting motes
        motePaint.color = accent
        for (i in 0 until 4) {
            val a = phase * (0.5f + i * 0.12f) * (if (i % 2 == 0) 1f else -1f) + i * 1.57f
            val orbit = r * (0.80f + 0.06f * sin(phase + i))
            val px = cx + kotlin.math.cos(a.toDouble()).toFloat() * orbit
            val py = cy + kotlin.math.sin(a.toDouble()).toFloat() * orbit
            motePaint.alpha = (100 + 120 * energy).toInt().coerceAtMost(230)
            canvas.drawCircle(px, py, size * (0.012f + 0.008f * energy), motePaint)
        }

        val pulse = size * (0.05f + 0.05f * voice + 0.012f * breath)
        coreGlowPaint.color = accent
        coreGlowPaint.alpha = (55 + 130 * energy).toInt().coerceAtMost(210)
        canvas.drawCircle(cx, cy, pulse * 1.5f, coreGlowPaint)
        corePaint.color = mix(soft, accent, 0.3f + 0.5f * response)
        corePaint.alpha = (160 + 80 * energy).toInt().coerceAtMost(245)
        canvas.drawCircle(cx, cy, pulse * 0.3f, corePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = super.onTouchEvent(event)
}
