package com.echo.app.wear

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

class WatchMainActivity : Activity() {
    private lateinit var scroll: ScrollView
    private lateinit var recordRing: WatchEchoRingView
    private lateinit var status: TextView
    private lateinit var cardsList: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var recording = false
    private var output: java.io.OutputStream? = null
    private var channel: com.google.android.gms.wearable.ChannelClient.Channel? = null
    private var recordThread: Thread? = null
    private var cards: List<WatchCard> = emptyList()

    data class WatchCard(val id: Long, val text: String, val time: String, val favorite: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadCards()
    }

    override fun onResume() {
        super.onResume()
        loadCards()
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildUi() {
        scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), 0, dp(12f), dp(24f))
        }

        val screenHeightDp = resources.displayMetrics.heightPixels / resources.displayMetrics.density
        val heroHeight = dp((screenHeightDp * 0.96f).coerceAtLeast(300f))
        val hero = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        val title = TextView(this).apply {
            text = "ECHO"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        hero.addView(title, FrameLayout.LayoutParams(-1, dp(30f), Gravity.TOP))

        recordRing = WatchEchoRingView(this).apply {
            setOnClickListener { if (recording) stopRecording() else startRecording() }
            contentDescription = "Запись"
        }
        hero.addView(recordRing, FrameLayout.LayoutParams(dp(142f), dp(142f), Gravity.CENTER))

        status = TextView(this).apply {
            text = "Тап — запись · свайп вверх — карточки"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val statusLp = FrameLayout.LayoutParams(-1, dp(42f), Gravity.BOTTOM)
        statusLp.leftMargin = dp(8f)
        statusLp.rightMargin = dp(8f)
        hero.addView(status, statusLp)

        content.addView(hero, LinearLayout.LayoutParams(-1, heroHeight))

        val cardsTitle = TextView(this).apply {
            text = "КАРТОЧКИ"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(2f), 0, dp(10f))
        }
        content.addView(cardsTitle, LinearLayout.LayoutParams(-1, -2))

        cardsList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
        }
        content.addView(cardsList, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)
    }

    private fun loadCards() {
        val json = getSharedPreferences("watch", Context.MODE_PRIVATE).getString("cards", "[]") ?: "[]"
        val parsed = mutableListOf<WatchCard>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                parsed += WatchCard(
                    o.getLong("id"),
                    o.getString("text"),
                    o.getString("time"),
                    o.getBoolean("favorite")
                )
            }
        } catch (_: Exception) { }
        cards = parsed
        if (!::cardsList.isInitialized) return
        cardsList.removeAllViews()
        if (cards.isEmpty()) {
            cardsList.addView(TextView(this).apply {
                text = "Нет карточек"
                textSize = 13f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
                setPadding(0, dp(18f), 0, dp(36f))
            })
            return
        }

        cards.forEach { card ->
            val cardView = TextView(this).apply {
                val prefix = if (card.favorite) "★ " else ""
                text = "$prefix${card.text}\n${card.time}"
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(20, 20, 23))
                    setStroke(dp(1f), Color.rgb(48, 50, 58))
                    cornerRadius = dp(24f).toFloat()
                }
                isSingleLine = false
                setOnClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "favorite")
                    handler.postDelayed({ loadCards() }, 250)
                }
                setOnLongClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "delete")
                    handler.postDelayed({ loadCards() }, 300)
                    true
                }
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8f)
            lp.leftMargin = dp(8f)
            lp.rightMargin = dp(8f)
            cardsList.addView(cardView, lp)
        }
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        if (recording) return
        Thread {
            try {
                runBlocking {
                    val nodes = Wearable.getNodeClient(this@WatchMainActivity).connectedNodes.await()
                    val node = nodes.firstOrNull() ?: throw IllegalStateException("Телефон не подключён")
                    val path = "/echo/manual-audio/" + System.currentTimeMillis()
                    val ch = Wearable.getChannelClient(this@WatchMainActivity).openChannel(node.id, path).await()
                    val out = Wearable.getChannelClient(this@WatchMainActivity).getOutputStream(ch).await()
                    val minBuffer = AudioRecord.getMinBufferSize(
                        16000,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    val buffer = ByteArray(maxOf(minBuffer, 2048))
                    val recorder = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        16000,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        buffer.size * 2
                    )
                    channel = ch
                    output = out
                    recording = true
                    runOnUiThread {
                        recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                        recordRing.start()
                        status.text = "Идёт запись · тап — стоп"
                    }
                    recorder.startRecording()
                    recordThread = Thread {
                        try {
                            while (recording) {
                                val n = recorder.read(buffer, 0, buffer.size)
                                if (n > 0) {
                                    out.write(buffer, 0, n)
                                    var sum = 0.0
                                    var i = 0
                                    while (i + 1 < n) {
                                        val lo = buffer[i].toInt() and 0xff
                                        val hi = buffer[i + 1].toInt()
                                        val sample = (hi shl 8) or lo
                                        val signed = if (sample > 32767) sample - 65536 else sample
                                        val x = signed / 32768.0
                                        sum += x * x
                                        i += 2
                                    }
                                    val rms = if (n > 1) kotlin.math.sqrt(sum / (n / 2)) else 0.0
                                    runOnUiThread { if (recording) recordRing.setAudioLevel((rms * 5.5).coerceIn(0.02, 1.0).toFloat()) }
                                }
                            }
                        } catch (_: Exception) { }
                        try { recorder.stop() } catch (_: Exception) { }
                        recorder.release()
                    }.also { it.start() }
                }
            } catch (_: Exception) {
                runOnUiThread {
                    recording = false
                    recordRing.stop()
                    status.text = "Телефон не подключён"
                }
            }
        }.start()
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        val t = recordThread
        try { t?.join(1200) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        try { output?.flush() } catch (_: Exception) { }
        try { output?.close() } catch (_: Exception) { }
        val ch = channel
        if (ch != null) {
            try { Wearable.getChannelClient(this).close(ch) } catch (_: Exception) { }
        }
        output = null
        channel = null
        recordThread = null
        recordRing.setAudioLevel(0f)
        recordRing.setMode(WatchEchoRingView.MODE_CLOSING)
        handler.postDelayed({ recordRing.stop(); recordRing.setMode(WatchEchoRingView.MODE_CONNECTING) }, 260)
        status.text = "Передано телефону · готово"
        loadCards()
    }
}

private class WatchEchoRingView(context: Context) : View(context) {
    companion object {
        const val MODE_CONNECTING = 0
        const val MODE_LISTENING = 1
        const val MODE_RESPONDING = 2
        const val MODE_CLOSING = 3
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val filamentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var phase = 0f
    private var running = false
    private var mode = MODE_CONNECTING
    @Volatile private var targetAudio = 0f
    private var audio = 0f
    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.045f + audio * 0.11f
            audio += (targetAudio - audio) * 0.16f
            invalidate()
            postOnAnimation(this)
        }
    }

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun setAudioLevel(level: Float) { targetAudio = level.coerceIn(0f, 1f) }
    fun setMode(value: Int) { mode = value; invalidate() }
    fun start() { running = true; removeCallbacks(frame); postOnAnimation(frame) }
    fun stop() { running = false; targetAudio = 0f; audio = 0f; removeCallbacks(frame); invalidate() }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * x).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * x).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val size = min(width, height).toFloat()
        if (size <= 0f) return
        val breath = 0.5f + 0.5f * sin(phase * 1.55f)
        val voice = audio * (0.72f + 0.28f * breath)
        val response = if (mode == MODE_RESPONDING) 1f else 0f
        val energy = (voice + if (mode == MODE_RESPONDING) 0.16f else 0f).coerceIn(0f, 1f)
        val baseR = size * 0.335f
        val r = baseR * (1f + 0.025f * breath + 0.095f * voice)
        val cyan = mix(Color.parseColor("#65D8FF"), Color.parseColor("#B18CFF"), response)
        val glow = mix(Color.parseColor("#55D8FF"), Color.parseColor("#8A6BFF"), response)

        glowPaint.color = glow
        glowPaint.strokeWidth = size * (0.075f + 0.055f * energy)
        glowPaint.alpha = (38 + 132 * energy + 18 * breath).toInt().coerceAtMost(205)
        canvas.drawCircle(cx, cy, r, glowPaint)

        corePaint.color = mix(Color.parseColor("#F7FBFF"), Color.parseColor("#F1ECFF"), response)
        corePaint.strokeWidth = size * (0.068f + 0.016f * voice)
        corePaint.alpha = 246
        canvas.drawCircle(cx, cy, r, corePaint)

        cyanPaint.color = cyan
        cyanPaint.strokeWidth = size * (0.011f + 0.008f * energy)
        cyanPaint.alpha = (175 + 75 * energy).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.055f, cyanPaint)

        val filamentR = r - size * 0.01f
        filamentPaint.color = cyan
        for (i in 0 until 7) {
            val direction = if (i % 2 == 0) 1f else -1f
            val speed = 0.42f + i * 0.065f + energy * (1.15f + i * 0.12f)
            val rotation = Math.toDegrees((phase * direction * speed).toDouble()).toFloat()
            val weave = sin(phase * 1.1f + i)
            val sweep = 105f + 20f * weave + 48f * voice
            val start = rotation + i * 51f + 10f * weave * energy
            filamentPaint.strokeWidth = size * (0.0075f + i * 0.0010f + 0.004f * energy)
            filamentPaint.alpha = (82 + i * 18 + 85 * energy).toInt().coerceAtMost(240)
            canvas.save()
            canvas.rotate(start, cx, cy)
            canvas.drawArc(cx - filamentR, cy - filamentR, cx + filamentR, cy + filamentR, 18f, sweep, false, filamentPaint)
            canvas.restore()
        }

        for (i in 0 until 5) {
            val rr = r - size * (0.040f + i * 0.024f)
            val direction = if (i % 2 == 0) -1f else 1f
            val start = direction * Math.toDegrees((phase * 0.45f).toDouble()).toFloat() + i * 72f
            filamentPaint.strokeWidth = size * (0.0045f + 0.0035f * energy)
            filamentPaint.alpha = (55 + i * 15 + 70 * energy).toInt().coerceAtMost(190)
            canvas.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, start, 45f + 35f * voice + 10f * breath, false, filamentPaint)
        }

        val pulse = size * (0.058f + 0.045f * voice + 0.012f * breath)
        innerGlowPaint.color = cyan
        innerGlowPaint.strokeWidth = size * (0.012f + 0.012f * energy)
        innerGlowPaint.alpha = (75 + 150 * energy).toInt().coerceAtMost(230)
        canvas.drawCircle(cx, cy, pulse, innerGlowPaint)
        centerPaint.color = cyan
        centerPaint.alpha = (150 + 95 * energy).toInt().coerceAtMost(245)
        canvas.drawCircle(cx, cy, pulse * (0.22f + 0.18f * energy), centerPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = super.onTouchEvent(event)
}
