package com.echo.app

import android.content.Context
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// A light, artistic recap of today's speech cards -- shown above the
// long-term memory list. Refreshed at most once an hour during the day;
// the run at/after 22:00 is the day's *final* one and gets locked (isFinal)
// so it stops changing and can be safely fed to Live Q&A as history.
object DaySummary {

    private const val TAG = "EchoDaySummary"
    private val THROTTLE_MS = 60 * 60 * 1000L // 1 hour
    private const val LOCK_HOUR = 22

    data class Result(val text: String, val generatedAt: Long, val isFinal: Boolean)

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

    private fun isPastLockHour(): Boolean =
        Calendar.getInstance().get(Calendar.HOUR_OF_DAY) >= LOCK_HOUR

    private fun startOfTodayMillis(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    // Whatever is already saved for today, without triggering a new call.
    suspend fun cached(context: Context): Result? {
        val e = EchoDb.get(context).daySummaries().forDate(today()) ?: return null
        return Result(e.text, e.generatedAt, e.isFinal)
    }

    // force=false: only calls Gemini if due (an hour passed, or today has no
    // entry yet) and the day isn't already locked. The run at/after 22:00
    // marks isFinal=true, after which nothing further happens today.
    // force=true (manual refresh) always regenerates and does NOT set isFinal
    // early, so the 22:00 lock still behaves as the "real" last word.
    suspend fun runIfDue(context: Context, force: Boolean = false): Result? {
        val dao = EchoDb.get(context).daySummaries()
        val today = today()
        val existing = dao.forDate(today)

        if (!force) {
            if (existing != null && existing.isFinal) {
                return Result(existing.text, existing.generatedAt, true)
            }
            if (existing != null && System.currentTimeMillis() - existing.generatedAt < THROTTLE_MS) {
                return Result(existing.text, existing.generatedAt, existing.isFinal)
            }
        }

        val cards = EchoDb.get(context).cards().since(startOfTodayMillis())
            .filter { it.text.isNotBlank() && it.text != "Расшифровка..." }

        if (cards.isEmpty()) {
            return existing?.let { Result(it.text, it.generatedAt, it.isFinal) }
        }

        val transcript = cards.joinToString("\n") { "- ${it.text}" }
        val response = try {
            Gemini.summarize(buildPrompt(transcript))
        } catch (e: Exception) {
            Log.e(TAG, "Day summary request failed", e)
            null
        }?.trim()

        if (response.isNullOrBlank()) {
            return existing?.let { Result(it.text, it.generatedAt, it.isFinal) }
        }

        val now = System.currentTimeMillis()
        val locksNow = !force && isPastLockHour()
        val entry = DaySummaryEntry(
            date = today,
            text = response,
            generatedAt = now,
            isFinal = locksNow
        )
        dao.upsert(entry)
        return Result(response, now, locksNow)
    }

    // Every day ever recorded, oldest first -- used to give Live Q&A the
    // full history, not just today.
    suspend fun allText(context: Context): String =
        EchoDb.get(context).daySummaries().all()
            .joinToString("\n\n") { "${it.date}: ${it.text}" }

    private fun buildPrompt(transcript: String): String = """
        Ты — тёплый, наблюдательный рассказчик. Ниже реплики, которые человек
        произносил вслух сегодня (это его собственная речь, расшифрованная
        голосовым дневником, а не диалог с ассистентом), в хронологическом порядке.

        Напиши короткую (3-6 предложений) художественную выжимку дня: связный,
        живой пересказ в прозе, как тёплая дневниковая запись от третьего лица.
        Без списков, заголовков и дословного цитирования реплик -- только
        цельный текст, передающий настроение и суть дня.

        Если реплик слишком мало или это явно технические проверки (тесты
        микрофона, "работает ли" и т.п.), а не содержательный день -- напиши
        об этом коротко и по-доброму, не выдумывая события, которых не было.

        Реплики за сегодня:
        $transcript
    """.trimIndent()
}
