package com.echo.app

import android.content.Context
import android.util.Log
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Turns the day's raw speech cards into a short list of durable facts,
// stored separately in long_term_memory so the "Память" tab isn't just a
// growing wall of every sentence ever said.
object MemoryExtraction {

    private const val TAG = "EchoMemory"
    private const val PREFS = "echo_memory"
    private const val KEY_LAST_RUN = "last_extracted_at"
    private val DAY_MS = 24 * 60 * 60 * 1000L

    // Called once on app open; only actually does work if a day has passed
    // since the last extraction.
    suspend fun runIfDue(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val last = prefs.getLong(KEY_LAST_RUN, 0L)
        if (System.currentTimeMillis() - last >= DAY_MS) {
            runNow(context)
        }
    }

    // Runs immediately regardless of when it last ran (used by the manual
    // "Обновить" button). Returns how many new facts were saved.
    suspend fun runNow(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val since = prefs.getLong(KEY_LAST_RUN, 0L)
        val db = EchoDb.get(context)

        val cards = db.cards().since(since)
            .filter { it.text.isNotBlank() && it.text != "Расшифровка..." }

        // Always move the watermark forward, even with nothing to extract --
        // otherwise an empty day would keep re-scanning from the same point.
        prefs.edit().putLong(KEY_LAST_RUN, System.currentTimeMillis()).apply()

        if (cards.isEmpty()) return 0

        val transcript = cards.joinToString("\n") { "- ${it.text}" }
        val response = try {
            Gemini.extract(buildPrompt(transcript))
        } catch (e: Exception) {
            Log.e(TAG, "Extraction request failed", e)
            return 0
        }

        if (response.isBlank()) return 0

        val facts = parseFacts(response)
        if (facts.isNotEmpty()) {
            db.memory().insertAll(facts)
            Log.d(TAG, "Extracted ${facts.size} fact(s) from ${cards.size} card(s)")
        }
        return facts.size
    }

    private fun buildPrompt(transcript: String): String = """
        Ты — модуль долговременной памяти голосового ассистента "Эхо".
        Ниже — расшифровки того, что пользователь говорил вслух за день (это его
        собственная речь, не диалог с ассистентом).

        Извлеки только УСТОЙЧИВЫЕ факты о пользователе: то, что останется правдой
        надолго — работа, привычки, отношения, интересы, планы, предпочтения.
        НЕ включай разовые события без долгосрочной ценности, тестовые фразы
        ("проверка", "работает ли"), случайные обрывки и бессмыслицу.
        Если устойчивых фактов нет, верни пустой массив.

        Ответ — строго JSON-массив объектов, без markdown и пояснений:
        [{"category": "...", "subject": "...", "fact": "..."}]

        category — одно из: "работа", "отношения", "здоровье", "интересы", "планы", "привычки", "прочее"
        subject — короткая тема, 2-4 слова
        fact — сам факт одним предложением от третьего лица, на русском

        Расшифровки за день:
        $transcript
    """.trimIndent()

    private fun parseFacts(response: String): List<MemoryFact> {
        return try {
            val cleaned = response.trim()
                .removePrefix("```json").removePrefix("```")
                .removeSuffix("```").trim()
            val arr = JSONArray(cleaned)
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val category = obj.optString("category").trim()
                val subject = obj.optString("subject").trim()
                val fact = obj.optString("fact").trim()
                if (category.isBlank() || subject.isBlank() || fact.isBlank()) null
                else MemoryFact(category = category, subject = subject, fact = fact, sourceDate = today)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Could not parse extraction response: $response", e)
            emptyList()
        }
    }
}
