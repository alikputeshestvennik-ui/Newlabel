# Echo + Galaxy Watch

This archive is intended to be uploaded to GitHub as a ZIP without unpacking it.

The repository workflow must be stored separately at `.github/workflows/build-echo-zip.yml` because GitHub Actions does not execute workflows nested inside an uploaded ZIP.

The workflow extracts this ZIP on the runner, restores the signing keystore from the existing secrets, and builds:
- Echo phone release APK
- Echo Galaxy Watch release APK

Required existing secrets:
- `ECHO_KEYSTORE_BASE64`
- `ECHO_STORE_PASSWORD`
- `ECHO_KEY_PASSWORD`
- `GEMINI`
