# Эхо — MVP

Рабочая основа для тестирования: микрофон → Noise Suppressor → AGC → VAD → Gemini 3.5 Transcribe Live → карточка и PCM-аудио; локальная Room БД.

Secrets: `ECHO`, `GEMINI`.

Workflow is supplied separately; upload it to `.github/workflows/build.yml`.

Примечание: этот MVP специально оставляет Live-диалог и ежедневную экстракцию памяти отдельным следующим этапом, чтобы не выдавать незавершённую интеграцию за готовую.


### Premium ring animation
The Live QA button uses a custom animated Echo ring instead of the previous organic blob. It combines a breathing luminous core, rotating orbital filaments, and a subtle center pulse.


## Офлайн-запись

Если потоковая транскрибация недоступна, слегка потяни основное кольцо вверх: начинается ручная запись без VAD и без автоматических отсечек. Нажми кольцо повторно для остановки. Запись сохраняется локально как карточка «Ожидает отправки». Когда интернет появится, на карточке доступна маленькая кнопка отправки; она передаёт WAV в Gemini 3.5 Transcribe и заменяет статус готовой расшифровкой.

## Offline transcription with speakers

An offline/manual recording can be sent later from its small upload button. Echo now opens a speaker selection sheet with **Auto / 1 / 2 / 3 / 4 speakers**. Gemini 3.5 Transcribe performs speaker diarization for multi-speaker modes and Echo formats the returned speaker turns as `Спикер 1`, `Спикер 2`, etc. The selected count is used as a hint; Gemini's API currently exposes diarization as an on/off capability rather than a hard speaker-count parameter. Speaker attribution for 3+ speakers is experimental and diarized files are limited to 30 minutes by the API.

### Офлайн-запись
- Ручная запись без VAD продолжается до повторного нажатия на кольцо.
- Один сегмент автоматически ограничен 29 минутами; после 29 минут следующий сегмент начинается автоматически без остановки записи.
- Каждый сегмент сохраняется как отдельная карточка.
- Аудиофайл не удаляется после отправки и расшифровки; он удаляется только вместе с карточкой вручную.
- При отправке включается автоматическое разделение по спикерам Gemini.
- Кнопка отправки — малозаметная векторная иконка.
- Горизонтальный свайп между разделами следует за пальцем 1:1.


Gesture fix v11: card touches are now owned by the card/ScrollView so vertical scrolling and horizontal favorite/delete swipes can coexist without the page pager stealing the gesture.
