package com.echo.app

import android.content.Context
import com.google.android.gms.wearable.ChannelClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class WearDataService : WearableListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onMessageReceived(event: MessageEvent) {
        when (event.path) {
            WearBridge.ACTION_PATH -> handleCardAction(event)
            WearBridge.RECORDING_STATE_PATH -> handleRecordingState(event)
            WearBridge.RECORDING_CONTROL_PATH -> handleRecordingControl(event)
        }
    }

    private fun handleCardAction(event: MessageEvent) {
        scope.launch {
            try {
                val o = JSONObject(String(event.data, Charsets.UTF_8))
                val id = o.getLong("id")
                when (o.getString("action")) {
                    "favorite" -> {
                        val db = EchoDb.get(this@WearDataService)
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().setFavorite(id, !card.favorite)
                    }
                    "delete" -> {
                        val db = EchoDb.get(this@WearDataService)
                        val card = db.cards().byId(id) ?: return@launch
                        db.cards().delete(id)
                        card.audioPath?.let { try { File(it).delete() } catch (_: Exception) {} }
                    }
                }
                WearBridge.syncCards(this@WearDataService, EchoDb.get(this@WearDataService).cards().all())
            } catch (_: Exception) { }
        }
    }

    private fun handleRecordingState(event: MessageEvent) {
        try {
            val o = JSONObject(String(event.data, Charsets.UTF_8))
            val active = o.optBoolean("active", false)
            val source = o.optString("source", "watch")
            getSharedPreferences("recording", Context.MODE_PRIVATE).edit()
                .putBoolean("remoteActive", active)
                .putString("remoteSource", source)
                .apply()
            sendBroadcast(
                android.content.Intent(ACTION_REMOTE_RECORDING)
                    .setPackage(packageName)
                    .putExtra("active", active)
                    .putExtra("source", source)
            )
        } catch (_: Exception) { }
    }

    private fun handleRecordingControl(event: MessageEvent) {
        try {
            val o = JSONObject(String(event.data, Charsets.UTF_8))
            if (o.optString("action") == "stop") {
                stopService(
                    android.content.Intent(this, ManualRecordingService::class.java)
                )
            }
        } catch (_: Exception) { }
    }

    override fun onChannelOpened(channel: ChannelClient.Channel) {
        if (!channel.path.startsWith(WearBridge.AUDIO_PATH_PREFIX)) return
        val createdAt = channel.path.substringAfterLast('/').toLongOrNull() ?: System.currentTimeMillis()
        val pcm = File(filesDir, "watch_${createdAt}.pcm")
        Wearable.getChannelClient(this).getInputStream(channel)
            .addOnSuccessListener { input ->
                Thread {
                    try {
                        val buffer = ByteArray(16 * 1024)
                        var segmentStart = createdAt
                        var segmentFile = pcm
                        var out = FileOutputStream(segmentFile)
                        var ok = false
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            out.write(buffer, 0, n)
                            ok = true
                            if (System.currentTimeMillis() - segmentStart >= MAX_SEGMENT_MS) {
                                out.flush()
                                out.close()
                                saveWatchCard(segmentStart, segmentFile)
                                segmentStart = System.currentTimeMillis()
                                segmentFile = File(filesDir, "watch_${segmentStart}.pcm")
                                out = FileOutputStream(segmentFile)
                            }
                        }
                        out.flush()
                        out.close()
                        if (ok && segmentFile.length() > 0) {
                            saveWatchCard(segmentStart, segmentFile)
                        } else {
                            segmentFile.delete()
                        }
                    } catch (_: Exception) {
                        try { pcm.delete() } catch (_: Exception) {}
                    } finally {
                        try { input.close() } catch (_: Exception) { }
                        Wearable.getChannelClient(this).close(channel)
                    }
                }.start()
            }
    }
    private fun saveWatchCard(createdAt: Long, file: File) {
        scope.launch {
            try {
                val db = EchoDb.get(this@WearDataService)
                db.cards().insert(
                    SpeechCard(
                        createdAt = createdAt,
                        text = "Ожидает отправки",
                        audioPath = file.absolutePath,
                        pendingUpload = true
                    )
                )
                val all = db.cards().all()
                WearBridge.syncCards(this@WearDataService, all)
            } catch (_: Exception) { }
        }
    }

    companion object {
        const val ACTION_REMOTE_RECORDING = "com.echo.app.REMOTE_RECORDING_STATE"
        private const val MAX_SEGMENT_MS = 29L * 60L * 1000L
    }
}
