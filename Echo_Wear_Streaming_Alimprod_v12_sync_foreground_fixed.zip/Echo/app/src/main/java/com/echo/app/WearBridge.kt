package com.echo.app

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WearBridge {
    const val CARDS_PATH = "/echo/cards"
    const val ACTION_PATH = "/echo/card/action"
    const val AUDIO_PATH_PREFIX = "/echo/manual-audio/"
    const val RECORDING_STATE_PATH = "/echo/recording/state"
    const val RECORDING_CONTROL_PATH = "/echo/recording/control"

    /**
     * Deliberately uses Google Tasks instead of kotlinx-coroutines await here.
     * The phone module does not include the coroutine Tasks extension, and this
     * keeps WearBridge compatible with the known-good v9 transport code.
     */
    fun sendRecordingState(context: Context, active: Boolean, source: String) {
        Thread {
            try {
                val app = context.applicationContext
                val nodes = Tasks.await(Wearable.getNodeClient(app).connectedNodes)
                val node = nodes.firstOrNull() ?: return@Thread
                val payload = JSONObject().apply {
                    put("active", active)
                    put("source", source)
                    put("at", System.currentTimeMillis())
                }.toString().toByteArray(Charsets.UTF_8)
                Tasks.await(
                    Wearable.getMessageClient(app)
                        .sendMessage(node.id, RECORDING_STATE_PATH, payload)
                )
            } catch (_: Exception) {
                // Wear OS may be temporarily unavailable; recording itself must not fail.
            }
        }.start()
    }

    fun sendRecordingStop(context: Context) {
        Thread {
            try {
                val app = context.applicationContext
                val nodes = Tasks.await(Wearable.getNodeClient(app).connectedNodes)
                val node = nodes.firstOrNull() ?: return@Thread
                val payload = JSONObject().put("action", "stop")
                    .toString().toByteArray(Charsets.UTF_8)
                Tasks.await(
                    Wearable.getMessageClient(app)
                        .sendMessage(node.id, RECORDING_CONTROL_PATH, payload)
                )
            } catch (_: Exception) {
                // Ignore transient transport errors.
            }
        }.start()
    }

    fun syncCards(context: Context, cards: List<SpeechCard>) {
        Thread {
            try {
                val app = context.applicationContext
                val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
                val arr = JSONArray()
                cards.take(50).forEach { c ->
                    arr.put(JSONObject().apply {
                        put("id", c.id)
                        put("text", c.text)
                        put("date", dateFmt.format(Date(c.createdAt)))
                        put("time", timeFmt.format(Date(c.createdAt)))
                        put(
                            "fromWatch",
                            c.audioPath?.substringAfterLast('/')?.startsWith("watch_") == true
                        )
                        put("favorite", c.favorite)
                    })
                }
                val request = PutDataMapRequest.create(CARDS_PATH).apply {
                    dataMap.putString("json", arr.toString())
                    dataMap.putLong("updatedAt", System.currentTimeMillis())
                }.asPutDataRequest().setUrgent()
                Tasks.await(Wearable.getDataClient(app).putDataItem(request))
            } catch (_: Exception) {
                // Card sync is best-effort and will retry on the next refresh.
            }
        }.start()
    }
}
