plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.echo.app.wear"
    compileSdk = 35

    signingConfigs {
        create("release") {
            val ksFile = layout.buildDirectory.file("generated/echo-release.jks").get().asFile
            storeFile = ksFile
            storePassword = System.getenv("ECHO") ?: ""
            keyAlias = "Alimprod"
            keyPassword = System.getenv("ECHO_KEY_PASSWORD") ?: System.getenv("ECHO") ?: ""
        }
    }

    defaultConfig {
        applicationId = "com.echo.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        getByName("release") { signingConfig = signingConfigs.getByName("release") }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-wearable:20.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
}

kotlin { jvmToolchain(17) }
