package com.echo.app.wear

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

class WatchMainActivity : Activity() {
    private lateinit var scroll: ScrollView
    private lateinit var recordRing: WatchEchoRingView
    private lateinit var status: TextView
    private lateinit var cardsList: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    @Volatile private var recording = false
    @Volatile private var remoteRecording = false
    private var remoteRecordingSource = ""
    private var output: java.io.OutputStream? = null
    private var channel: com.google.android.gms.wearable.ChannelClient.Channel? = null
    private var recordThread: Thread? = null
    private var cards: List<WatchCard> = emptyList()
    private val recordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            when (intent.getStringExtra("state")) {
                "started" -> {
                    recording = true
                    remoteRecording = false
                    recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                    recordRing.start()
                    status.text = "Запись с часов · тап — стоп"
                }
                "level" -> {
                    if (recording) recordRing.setAudioLevel(intent.getFloatExtra("level", 0f))
                }
                "stopped" -> {
                    recording = false
                    remoteRecording = false
                    remoteRecordingSource = ""
                    getSharedPreferences("recording", Context.MODE_PRIVATE).edit().putBoolean("remoteActive", false).apply()
                    recordRing.setAudioLevel(0f)
                    recordRing.setMode(WatchEchoRingView.MODE_CLOSING)
                    handler.postDelayed({ recordRing.stop(); recordRing.setMode(WatchEchoRingView.MODE_CONNECTING) }, 260)
                    status.text = "Передано телефону · готово"
                    loadCards()
                }
                "error" -> {
                    recording = false
                    recordRing.stop()
                    status.text = intent.getStringExtra("message") ?: "Ошибка записи"
                }
            }
        }
    }

    private val remoteRecordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            remoteRecording = intent.getBooleanExtra("active", false)
            remoteRecordingSource = intent.getStringExtra("source") ?: ""
            getSharedPreferences("recording", Context.MODE_PRIVATE).edit()
                .putBoolean("remoteActive", remoteRecording)
                .putString("remoteSource", remoteRecordingSource)
                .apply()
            if (remoteRecording && !WatchRecordingService.isRunning) {
                recording = true
                recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                recordRing.start()
                status.text = if (remoteRecordingSource == "phone") "Запись на телефоне · тап — стоп" else "Идёт запись · тап — стоп"
            } else if (!remoteRecording && !WatchRecordingService.isRunning) {
                recording = false
                recordRing.setAudioLevel(0f)
                recordRing.stop()
                recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
                status.text = "Тап — запись · свайп вверх — карточки"
            }
        }
    }

    data class WatchCard(val id: Long, val text: String, val date: String, val time: String, val favorite: Boolean, val fromWatch: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val flags = if (android.os.Build.VERSION.SDK_INT >= 33) Context.RECEIVER_NOT_EXPORTED else 0
        ContextCompat.registerReceiver(this, recordingReceiver, IntentFilter(WatchRecordingService.ACTION_STATE), flags)
        ContextCompat.registerReceiver(this, remoteRecordingReceiver, IntentFilter(WatchDataService.ACTION_REMOTE_RECORDING), flags)
        syncStateFromPrefs()
        loadCards()
        handler.post(uiTicker)
    }

    override fun onResume() {
        super.onResume()
        syncStateFromPrefs()
        loadCards()
        if (WatchRecordingService.isRunning) {
            recording = true
            remoteRecording = false
            recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
            recordRing.start()
            status.text = "Запись с часов · тап — стоп"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(uiTicker)
        try { unregisterReceiver(recordingReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(remoteRecordingReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private val uiTicker = object : Runnable {
        override fun run() {
            if (isFinishing) return
            syncStateFromPrefs()
            loadCards()
            handler.postDelayed(this, 500L)
        }
    }

    private fun syncStateFromPrefs() {
        val local = WatchRecordingService.isRunning
        val remote = getSharedPreferences("recording", Context.MODE_PRIVATE).getBoolean("remoteActive", false)
        val source = getSharedPreferences("recording", Context.MODE_PRIVATE).getString("remoteSource", "") ?: ""
        if (local) {
            recording = true
            remoteRecording = false
        } else if (remote) {
            val changed = !remoteRecording || remoteRecordingSource != source || !recording
            remoteRecording = true
            remoteRecordingSource = source
            recording = true
            if (changed) {
                recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
                recordRing.start()
                status.text = if (source == "phone") "Запись на телефоне · тап — стоп" else "Запись · тап — стоп"
            }
        } else if (remoteRecording && !local) {
            remoteRecording = false
            recording = false
            recordRing.stop()
            recordRing.setMode(WatchEchoRingView.MODE_CONNECTING)
            status.text = "Тап — запись · свайп вверх — карточки"
        }
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun buildUi() {
        scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), 0, dp(12f), dp(24f))
        }

        val screenHeightDp = resources.displayMetrics.heightPixels / resources.displayMetrics.density
        val heroHeight = dp(screenHeightDp.coerceAtLeast(300f))
        val hero = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        val title = TextView(this).apply {
            text = "ECHO"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        hero.addView(title, FrameLayout.LayoutParams(-1, dp(30f), Gravity.TOP))

        recordRing = WatchEchoRingView(this).apply {
            setOnClickListener {
                if (WatchRecordingService.isRunning) stopRecording()
                else if (remoteRecording) WatchDataService.sendRecordingStop(this@WatchMainActivity)
                else startRecording()
            }
            contentDescription = "Запись"
        }
        val ringLp = FrameLayout.LayoutParams(dp(156f), dp(156f), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        hero.addView(recordRing, ringLp)
        hero.post {
            val lp = recordRing.layoutParams as FrameLayout.LayoutParams
            lp.topMargin = ((hero.height - recordRing.height) / 2 - dp(4f)).coerceAtLeast(dp(8f))
            lp.leftMargin = 0
            lp.rightMargin = 0
            recordRing.layoutParams = lp
        }

        status = TextView(this).apply {
            text = "Тап — запись · свайп вверх — карточки"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        val statusLp = FrameLayout.LayoutParams(-1, dp(42f), Gravity.BOTTOM)
        statusLp.leftMargin = dp(8f)
        statusLp.rightMargin = dp(8f)
        hero.addView(status, statusLp)

        content.addView(hero, LinearLayout.LayoutParams(-1, heroHeight))

        val cardsTitle = TextView(this).apply {
            text = "КАРТОЧКИ"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(2f), 0, dp(10f))
        }
        content.addView(cardsTitle, LinearLayout.LayoutParams(-1, -2))

        cardsList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
        }
        content.addView(cardsList, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)
    }

    private fun loadCards() {
        val json = getSharedPreferences("watch", Context.MODE_PRIVATE).getString("cards", "[]") ?: "[]"
        val parsed = mutableListOf<WatchCard>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                parsed += WatchCard(
                    o.getLong("id"),
                    o.getString("text"),
                    o.optString("date", ""),
                    o.getString("time"),
                    o.getBoolean("favorite"),
                    o.optBoolean("fromWatch", false)
                )
            }
        } catch (_: Exception) { }
        cards = parsed
        if (!::cardsList.isInitialized) return
        cardsList.removeAllViews()
        if (cards.isEmpty()) {
            cardsList.addView(TextView(this).apply {
                text = "Нет карточек"
                textSize = 13f
                setTextColor(Color.GRAY)
                gravity = Gravity.CENTER
                setPadding(0, dp(18f), 0, dp(36f))
            })
            return
        }

        cards.forEach { card ->
            val cardView = TextView(this).apply {
                val prefix = if (card.favorite) "★ " else ""
                val source = if (card.fromWatch) " · с часов" else ""
                text = "$prefix${card.text}\n${card.date} · ${card.time}$source"
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(20, 20, 23))
                    setStroke(dp(1f), Color.rgb(48, 50, 58))
                    cornerRadius = dp(24f).toFloat()
                }
                isSingleLine = false
                setOnClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "favorite")
                    handler.postDelayed({ loadCards() }, 250)
                }
                setOnLongClickListener {
                    WatchDataService.sendAction(this@WatchMainActivity, card.id, "delete")
                    handler.postDelayed({ loadCards() }, 300)
                    true
                }
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8f)
            lp.leftMargin = dp(8f)
            lp.rightMargin = dp(8f)
            cardsList.addView(cardView, lp)
        }
    }

    private fun startRecording() {
        if (remoteRecording || WatchRecordingService.isRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        if (recording || WatchRecordingService.isRunning || remoteRecording) return
        recording = true
        val intent = android.content.Intent(this, WatchRecordingService::class.java).apply {
            action = WatchRecordingService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
        recordRing.setMode(WatchEchoRingView.MODE_LISTENING)
        recordRing.start()
        status.text = "Подключаюсь к телефону…"
    }

    private fun stopRecording() {
        if (WatchRecordingService.isRunning) {
            recording = false
            startService(android.content.Intent(this, WatchRecordingService::class.java).apply {
                action = WatchRecordingService.ACTION_STOP
            })
        } else if (remoteRecording) {
            WatchDataService.sendRecordingStop(this)
        }
    }

}

private class WatchEchoRingView(context: Context) : View(context) {
    companion object {
        const val MODE_CONNECTING = 0
        const val MODE_LISTENING = 1
        const val MODE_RESPONDING = 2
        const val MODE_CLOSING = 3
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val filamentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var phase = 0f
    private var running = false
    private var mode = MODE_CONNECTING
    @Volatile private var targetAudio = 0f
    private var audio = 0f
    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            phase += 0.045f + audio * 0.11f
            audio += (targetAudio - audio) * 0.16f
            invalidate()
            postOnAnimation(this)
        }
    }

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    fun setAudioLevel(level: Float) { targetAudio = level.coerceIn(0f, 1f) }
    fun setMode(value: Int) { mode = value; invalidate() }
    fun start() { running = true; removeCallbacks(frame); postOnAnimation(frame) }
    fun stop() { running = false; targetAudio = 0f; audio = 0f; removeCallbacks(frame); invalidate() }

    private fun mix(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * x).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * x).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val size = min(width, height).toFloat()
        if (size <= 0f) return
        val breath = 0.5f + 0.5f * sin(phase * 1.55f)
        val voice = audio * (0.72f + 0.28f * breath)
        val response = if (mode == MODE_RESPONDING) 1f else 0f
        val energy = (voice + if (mode == MODE_RESPONDING) 0.16f else 0f).coerceIn(0f, 1f)
        val baseR = size * 0.335f
        val r = baseR * (1f + 0.025f * breath + 0.095f * voice)
        val cyan = mix(Color.parseColor("#65D8FF"), Color.parseColor("#B18CFF"), response)
        val glow = mix(Color.parseColor("#55D8FF"), Color.parseColor("#8A6BFF"), response)

        glowPaint.color = glow
        glowPaint.strokeWidth = size * (0.075f + 0.055f * energy)
        glowPaint.alpha = (38 + 132 * energy + 18 * breath).toInt().coerceAtMost(205)
        canvas.drawCircle(cx, cy, r, glowPaint)

        corePaint.color = mix(Color.parseColor("#F7FBFF"), Color.parseColor("#F1ECFF"), response)
        corePaint.strokeWidth = size * (0.068f + 0.016f * voice)
        corePaint.alpha = 246
        canvas.drawCircle(cx, cy, r, corePaint)

        cyanPaint.color = cyan
        cyanPaint.strokeWidth = size * (0.011f + 0.008f * energy)
        cyanPaint.alpha = (175 + 75 * energy).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.055f, cyanPaint)

        // Three slow breathing arcs give the watch a stronger identity without adding icons.
        for (i in 0 until 3) {
            val rr = r * (1.08f + i * 0.045f)
            val start = Math.toDegrees((phase * (0.16f + i * 0.035f)).toDouble()).toFloat() + i * 120f
            filamentPaint.color = cyan
            filamentPaint.strokeWidth = size * (0.006f + 0.002f * energy)
            filamentPaint.alpha = (55 + 35 * energy).toInt()
            canvas.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, start, 48f + 18f * energy, false, filamentPaint)
        }

        val filamentR = r - size * 0.01f
        filamentPaint.color = cyan
        for (i in 0 until 7) {
            val direction = if (i % 2 == 0) 1f else -1f
            val speed = 0.42f + i * 0.065f + energy * (1.15f + i * 0.12f)
            val rotation = Math.toDegrees((phase * direction * speed).toDouble()).toFloat()
            val weave = sin(phase * 1.1f + i)
            val sweep = 105f + 20f * weave + 48f * voice
            val start = rotation + i * 51f + 10f * weave * energy
            filamentPaint.strokeWidth = size * (0.0075f + i * 0.0010f + 0.004f * energy)
            filamentPaint.alpha = (82 + i * 18 + 85 * energy).toInt().coerceAtMost(240)
            canvas.save()
            canvas.rotate(start, cx, cy)
            canvas.drawArc(cx - filamentR, cy - filamentR, cx + filamentR, cy + filamentR, 18f, sweep, false, filamentPaint)
            canvas.restore()
        }

        for (i in 0 until 5) {
            val rr = r - size * (0.040f + i * 0.024f)
            val direction = if (i % 2 == 0) -1f else 1f
            val start = direction * Math.toDegrees((phase * 0.45f).toDouble()).toFloat() + i * 72f
            filamentPaint.strokeWidth = size * (0.0045f + 0.0035f * energy)
            filamentPaint.alpha = (55 + i * 15 + 70 * energy).toInt().coerceAtMost(190)
            canvas.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, start, 45f + 35f * voice + 10f * breath, false, filamentPaint)
        }

        // Three small orbiting sparks make the watch ring feel alive even at low audio levels.
        centerPaint.color = cyan
        centerPaint.alpha = (90 + 130 * energy).toInt().coerceAtMost(220)
        for (i in 0 until 3) {
            val a = phase * (0.55f + i * 0.17f) + i * 2.094f
            val orbit = r * (0.82f + 0.045f * sin(phase * 1.3f + i))
            val px = cx + kotlin.math.cos(a.toDouble()).toFloat() * orbit
            val py = cy + kotlin.math.sin(a.toDouble()).toFloat() * orbit
            canvas.drawCircle(px, py, size * (0.009f + 0.006f * energy), centerPaint)
        }

        val pulse = size * (0.058f + 0.045f * voice + 0.012f * breath)
        innerGlowPaint.color = cyan
        innerGlowPaint.strokeWidth = size * (0.012f + 0.012f * energy)
        innerGlowPaint.alpha = (75 + 150 * energy).toInt().coerceAtMost(230)
        canvas.drawCircle(cx, cy, pulse, innerGlowPaint)
        centerPaint.color = cyan
        centerPaint.alpha = (150 + 95 * energy).toInt().coerceAtMost(245)
        canvas.drawCircle(cx, cy, pulse * (0.22f + 0.18f * energy), centerPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = super.onTouchEvent(event)
}
