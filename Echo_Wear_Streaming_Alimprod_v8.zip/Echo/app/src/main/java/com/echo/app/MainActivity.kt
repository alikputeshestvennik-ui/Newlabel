package com.echo.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewConfiguration
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

private const val MAX_MANUAL_SEGMENT_MS = 29L * 60L * 1000L

private class SwipePageContainer(context: android.content.Context) : FrameLayout(context) {
    var swipeInterceptListener: ((MotionEvent) -> Boolean)? = null
    var swipeTouchListener: ((MotionEvent) -> Boolean)? = null
    // When a card owns the gesture, let the card/ScrollView receive the stream.
    // This keeps vertical scrolling alive while still allowing horizontal card swipes.
    var cardGestureActive: Boolean = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (cardGestureActive) return false
        return swipeInterceptListener?.invoke(ev) ?: super.onInterceptTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return swipeTouchListener?.invoke(event) ?: super.onTouchEvent(event)
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var cards: LinearLayout
    private lateinit var contentHost: FrameLayout
    private lateinit var brandLogo: ImageView
    private lateinit var searchField: EditText
    private lateinit var fabButton: ImageView
    private lateinit var ringView: EchoRingView
    private lateinit var fabContainer: FrameLayout
    private lateinit var pageContainer: SwipePageContainer
    private lateinit var rootContainer: FrameLayout
    private var selectedTab = 0
    private var currentSearchQuery = ""
    private val navIcons = mutableListOf<ImageView>()
    private var qaPanel: View? = null
    private var isListening = false
    @Volatile private var manualRecording = false
    private var manualRecordThread: Thread? = null
    private var manualAudioFile: File? = null
    private var manualAudioOut: java.io.FileOutputStream? = null
    @Volatile private var manualStartedAt = 0L
    private var fabDownX = 0f
    private var fabDownY = 0f
    private var fabDraggingUp = false
    private val manualFileLock = Any()
    // Quiet dark palette
    private val bg = Color.parseColor("#07080B")
    private val panel = Color.parseColor("#12141A")
    private val panelElevated = Color.parseColor("#1A1D26")
    private val stroke = Color.parseColor("#2A2E3A")
    private val primaryText = Color.parseColor("#F2F4F8")
    private val muted = Color.parseColor("#8B91A0")
    private val accent = Color.parseColor("#6EA8FF")
    private val accentSoft = Color.parseColor("#1A2A44")
    private val danger = Color.parseColor("#FF3B4A")
    private val success = Color.parseColor("#5CDBA0")
    private val navBarColor = Color.argb(180, 22, 24, 30)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
        }

        isListening = getPreferences(0).getBoolean("running", false)
        buildUi()
        refreshLoop()
        DigestAlarmReceiver.schedule(this)

        lifecycleScope.launch {
            WearBridge.syncCards(this@MainActivity, EchoDb.get(this@MainActivity).cards().all())
            MemoryExtraction.runIfDue(this@MainActivity)
            if (selectedTab == 2) loadMemory()
            else if (selectedTab == 1) loadAnalysis()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(
        color: Int,
        radius: Int = 18,
        strokeColor: Int? = null,
        strokeWidthDp: Int = 1
    ): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (strokeColor != null) {
                setStroke(dp(strokeWidthDp), strokeColor)
            }
        }

    private fun label(value: String, size: Float, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            includeFontPadding = false
            letterSpacing = 0.01f
        }

    private fun sectionTitle(value: String): TextView =
        label(value.uppercase(Locale.getDefault()), 11f, accent).apply {
            letterSpacing = 0.12f
            setPadding(dp(4), dp(4), dp(4), dp(8))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }

    private fun primaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            letterSpacing = 0.04f
            background = rounded(accent, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun secondaryButton(title: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(primaryText)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            background = rounded(panelElevated, 14, stroke)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(bg)
        }
        rootContainer = root

        // Main vertical stack
        val stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Top inset so logo clears status bar / clock
            val topInset = statusBarInset()
            setPadding(dp(20), topInset + dp(8), dp(20), 0)
        }

        // —— Premium header: transparent logo + compact search action ——
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        brandLogo = ImageView(this).apply {
            setImageResource(R.drawable.echo_logo_premium)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Эхо"
        }
        header.addView(brandLogo, LinearLayout.LayoutParams(dp(112), dp(52)))

        val headerSpacer = Space(this)
        header.addView(headerSpacer, LinearLayout.LayoutParams(0, dp(52), 1f))

        val searchButton = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            contentDescription = "Поиск"
            background = rounded(Color.TRANSPARENT, 50)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(primaryText)
            setOnClickListener {
                if (searchField.visibility == View.VISIBLE) {
                    searchField.text?.clear()
                    searchField.visibility = View.GONE
                    currentSearchQuery = ""
                    loadCards()
                } else {
                    searchField.visibility = View.VISIBLE
                    searchField.requestFocus()
                    val imm = getSystemService(android.view.inputmethod.InputMethodManager::class.java)
                    imm?.showSoftInput(searchField, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                }
            }
        }
        header.addView(searchButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply {
            marginEnd = dp(2)
        })

        stack.addView(header, LinearLayout.LayoutParams(-1, dp(56)).apply {
            bottomMargin = dp(2)
        })

        searchField = EditText(this).apply {
            hint = ""
            setHintTextColor(Color.TRANSPARENT)
            setTextColor(primaryText)
            textSize = 15f
            setSingleLine(true)
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.argb(150, 18, 24, 34), 18, Color.argb(100, 110, 168, 255))
            visibility = View.GONE
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val query = s?.toString()?.trim() ?: ""
                    currentSearchQuery = query
                    filterCards(query)
                }
            })
        }
        stack.addView(searchField, LinearLayout.LayoutParams(-1, dp(46)).apply {
            bottomMargin = dp(4)
        })

        // —— Swipeable page host ——
        pageContainer = SwipePageContainer(this)
        contentHost = FrameLayout(this)
        cards = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(180))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(cards)
        }
        contentHost.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        pageContainer.addView(contentHost, FrameLayout.LayoutParams(-1, -1))
        attachPageSwipe(pageContainer)
        stack.addView(pageContainer, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(stack, FrameLayout.LayoutParams(-1, -1))

        // —— Airy premium recorder button: transparent artwork changes with state ——
        (root as? ViewGroup)?.clipChildren = false
        fabContainer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        ringView = EchoRingView(this).apply {
            visibility = View.INVISIBLE
            alpha = 0f
        }
        fabButton = ImageView(this).apply {
            setImageResource(R.drawable.echo_idle)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Начать запись"
            elevation = dp(10).toFloat()
        }
        fabContainer.addView(ringView, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        fabContainer.addView(fabButton, FrameLayout.LayoutParams(dp(148), dp(148), Gravity.CENTER))
        attachFabGesture(fabContainer)
        val fabParams = FrameLayout.LayoutParams(dp(160), dp(160), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        fabParams.bottomMargin = dp(56) + navBarInset()
        root.addView(fabContainer, fabParams)
        fabContainer.elevation = dp(24).toFloat()

        // —— Thin translucent nav bar ——
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10) + navBarInset())
            // Frosted bar: translucent gray (true backdrop-blur needs API 31
            // window blur which is device-dependent; alpha keeps content readable).
            setBackgroundColor(navBarColor)
            elevation = dp(8).toFloat()
        }

        navIcons.clear()
        listOf(
            R.drawable.ic_nav_feed to 0,
            R.drawable.ic_nav_analysis to 1,
            R.drawable.ic_nav_memory to 2
        ).forEach { (iconRes, tab) ->
            val iv = ImageView(this).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setColorFilter(muted)
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { selectTab(tab, animate = true) }
            }
            navIcons.add(iv)
            nav.addView(iv, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        root.addView(nav, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root)
        applyFabListeningState(animated = false)
        selectTab(0, animate = false)
    }

    private fun statusBarInset(): Int {
        val resId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(28)
    }

    private fun navBarInset(): Int {
        val resId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resId > 0) resources.getDimensionPixelSize(resId) else dp(8)
    }

    private fun attachPageSwipe(target: SwipePageContainer) {
        var downX = 0f
        var downY = 0f
        var dragging = false

        fun handle(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    contentHost.animate().cancel()
                    return false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    if (!dragging) return false
                    // Once the parent has intercepted a horizontal gesture,
                    // keep the page exactly under the finger.
                    contentHost.translationX = dx
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!dragging) return false
                    val dx = event.rawX - downX
                    val width = target.width.coerceAtLeast(1)
                    val threshold = width * 0.22f
                    val next = when {
                        dx < -threshold && selectedTab < 2 -> selectedTab + 1
                        dx > threshold && selectedTab > 0 -> selectedTab - 1
                        else -> -1
                    }
                    if (next >= 0) {
                        val direction = if (next > selectedTab) 1 else -1
                        contentHost.animate()
                            .translationX(if (direction > 0) -width.toFloat() else width.toFloat())
                            .setDuration(170)
                            .withEndAction {
                                loadTabContent(next)
                                selectedTab = next
                                updateNavSelection()
                                contentHost.translationX = if (direction > 0) width.toFloat() else -width.toFloat()
                                contentHost.animate().translationX(0f).setDuration(170).start()
                            }.start()
                    } else {
                        contentHost.animate().translationX(0f).setDuration(180).start()
                    }
                    dragging = false
                    return true
                }
            }
            return false
        }

        target.swipeInterceptListener = { event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                downX = event.rawX
                downY = event.rawY
                dragging = false
                contentHost.animate().cancel()
                false
            } else if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (!dragging && abs(dx) > dp(10) && abs(dx) > abs(dy) * 1.20f) {
                    dragging = true
                    true
                } else dragging
            } else dragging
        }
        target.swipeTouchListener = { event -> handle(event) }
    }

    private fun updateNavSelection() {
        navIcons.forEachIndexed { index, iv ->
            val active = index == selectedTab
            iv.setColorFilter(if (active) accent else muted)
            iv.animate().scaleX(if (active) 1.12f else 1f).scaleY(if (active) 1.12f else 1f)
                .setDuration(160).start()
        }
    }

    private fun selectTab(tab: Int, animate: Boolean = true) {
        if (tab == selectedTab && animate) {
            loadTabContent(tab)
            updateNavSelection()
            return
        }
        val direction = if (tab > selectedTab) 1 else -1
        selectedTab = tab
        updateNavSelection()
        if (tab != 0) searchField.visibility = View.GONE

        if (!animate) {
            loadTabContent(tab)
            contentHost.translationX = 0f
            contentHost.alpha = 1f
            return
        }

        contentHost.animate()
            .translationX(-direction * dp(40).toFloat())
            .alpha(0f)
            .setDuration(140)
            .withEndAction {
                loadTabContent(tab)
                contentHost.translationX = direction * dp(40).toFloat()
                contentHost.animate()
                    .translationX(0f)
                    .alpha(1f)
                    .setDuration(180)
                    .start()
            }
            .start()
    }

    private fun loadTabContent(tab: Int) {
        when (tab) {
            0 -> if (currentSearchQuery.isBlank()) loadCards() else filterCards(currentSearchQuery)
            1 -> loadAnalysis()
            2 -> loadMemory()
        }
    }

    private fun addEmpty(message: String) {
        cards.addView(label(message, 15f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(48), dp(12), dp(48))
            setLineSpacing(0f, 1.25f)
        })
    }

    private fun loadCards() {
        lifecycleScope.launch {
            val list = EchoDb.get(this@MainActivity).cards().all()
            WearBridge.syncCards(this@MainActivity, list)
            cards.removeAllViews()
            if (list.isEmpty()) {
                addEmpty("Пока нет записей.\nНажми точку и начни говорить.")
                return@launch
            }
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            list.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(15))
                    background = rounded(panel, 16, stroke)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    setLineSpacing(0f, 1.28f)
                })
                if (c.pendingUpload) {
                    val upload = ImageButton(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_upload_queue)
                        contentDescription = "Отправить запись"
                        background = rounded(Color.TRANSPARENT, 50)
                        setPadding(dp(6), dp(6), dp(6), dp(6))
                        setColorFilter(accent)
                        alpha = if (hasInternet()) 0.72f else 0.30f
                        setOnClickListener { uploadOfflineCard(c, this) }
                    }
                    val actionRow = FrameLayout(this@MainActivity).apply {
                        setPadding(0, dp(6), 0, 0)
                    }
                    actionRow.addView(upload, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.END))
                    card.addView(actionRow)
                }
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    private fun loadAnalysis() {
        cards.removeAllViews()
        addDaySummarySection()
    }

    private fun loadMemory() {
        cards.removeAllViews()
        addMemoryRefreshButton()

        lifecycleScope.launch {
            val facts = EchoDb.get(this@MainActivity).memory().all()
            if (facts.isEmpty()) {
                addEmpty("Здесь появятся устойчивые факты, которые Эхо запомнило.")
                return@launch
            }

            var lastCategory = ""
            facts.forEach { f ->
                if (f.category != lastCategory) {
                    lastCategory = f.category
                    cards.addView(sectionTitle(f.category.replaceFirstChar { it.uppercase() }))
                }
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(14))
                    background = rounded(panel, 16, stroke)
                }
                row.addView(label(f.subject, 12f, muted).apply {
                    typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                })
                row.addView(label(f.fact, 15f, primaryText).apply {
                    setPadding(0, dp(6), 0, 0)
                    setLineSpacing(0f, 1.25f)
                })
                cards.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
            }
        }
    }

    // "Анализ дня" -- an artistic recap of today's cards, sitting above the
    // long-term memory list. Shows the cached digest instantly (if any) while
    // a fresh one is fetched in the background, throttled to once an hour.
    private fun addDaySummarySection() {
        cards.addView(sectionTitle("Анализ дня"))

        val body = label("Собираю впечатления за сегодня...", 15f, primaryText).apply {
            setLineSpacing(0f, 1.3f)
        }
        val caption = label("", 11f, muted).apply { setPadding(0, dp(10), 0, 0) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 16, stroke)
        }
        card.addView(body)
        card.addView(caption)
        cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(20)
        })

        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        fun show(result: DaySummary.Result) {
            body.text = result.text
            caption.text = "Обновлено в ${timeFmt.format(Date(result.generatedAt))}" +
                if (result.isFinal) " · итог дня зафиксирован" else ""
        }

        lifecycleScope.launch {
            // Avoid a "Собираю..." flash on every reopen if we already have something.
            val cachedResult = DaySummary.cached(this@MainActivity)
            cachedResult?.let { show(it) }

            val result = DaySummary.runIfDue(this@MainActivity)
            if (result != null) {
                show(result)
            } else if (cachedResult == null) {
                body.text = "Пока рановато подводить итоги — скажи что-нибудь вслух."
                caption.text = ""
            }
        }
    }

    private fun addMemoryRefreshButton() {
        val row = FrameLayout(this).apply {
            minimumHeight = dp(42)
        }
        val refresh = ImageButton(this).apply {
            setImageResource(R.drawable.ic_refresh)
            contentDescription = "Обновить память"
            background = rounded(Color.TRANSPARENT, 50)
            setPadding(dp(9), dp(9), dp(9), dp(9))
            setColorFilter(muted)
            elevation = dp(2).toFloat()
        }
        refresh.setOnClickListener {
            refresh.isEnabled = false
            refresh.animate().rotationBy(360f).setDuration(420).start()
            lifecycleScope.launch {
                val added = MemoryExtraction.runNow(this@MainActivity)
                Toast.makeText(
                    this@MainActivity,
                    if (added > 0) "Новых фактов: $added" else "Новых фактов не найдено",
                    Toast.LENGTH_SHORT
                ).show()
                refresh.isEnabled = true
                if (selectedTab == 2) loadMemory()
            }
        }
        row.addView(refresh, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.TOP))
        cards.addView(row, LinearLayout.LayoutParams(-1, dp(44)).apply {
            bottomMargin = dp(2)
        })
    }

    // Tap = play back the recording (tap again while it's playing = stop it),
    // long-press = copy the text, swipe left = delete the card + its audio,
    // swipe right = toggle favorite (snaps back, doesn't remove the card).
    private fun attachCardGestures(view: View, card: SpeechCard, star: TextView) {
        var isFavorite = card.favorite

        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (playingCardId == card.id && isPlaying) {
                    stopPlayback()
                } else {
                    playCard(card)
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Эхо", card.text))
                Toast.makeText(this@MainActivity, "Текст скопирован", Toast.LENGTH_SHORT).show()
            }
        })

        var downX = 0f
        var downY = 0f
        var dragging = false
        var touchMode = false
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        view.setOnTouchListener { v, event ->
            gesture.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    dragging = false
                    touchMode = true
                    pageContainer.cardGestureActive = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!touchMode) return@setOnTouchListener false
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    val ax = abs(dx)
                    val ay = abs(dy)
                    // Give vertical gestures to ScrollView. We only capture a swipe
                    // after a clear horizontal intent, with a generous dead zone.
                    if (!dragging && maxOf(ax, ay) > touchSlop + dp(10)) {
                        if (ax > dp(18) && ax > ay * 1.30f) {
                            dragging = true
                            v.parent.requestDisallowInterceptTouchEvent(true)
                        } else if (ay > ax * 1.35f) {
                            touchMode = false
                            v.parent.requestDisallowInterceptTouchEvent(false)
                            return@setOnTouchListener false
                        }
                    }
                    if (dragging) {
                        v.translationX = dx
                        // Fade only previews the delete (left) direction.
                        v.alpha = if (dx < 0) {
                            1f - (-dx / v.width.coerceAtLeast(1)).coerceIn(0f, 0.8f)
                        } else 1f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!touchMode) {
                        pageContainer.cardGestureActive = false
                        return@setOnTouchListener false
                    }
                    if (dragging) {
                        val dx = event.rawX - downX
                        when {
                            dx < -v.width * 0.40f -> {
                                v.animate().translationX(-v.width.toFloat()).alpha(0f)
                                    .setDuration(180)
                                    .withEndAction { deleteCard(card, v) }
                                    .start()
                            }
                            dx > v.width * 0.30f -> {
                                isFavorite = !isFavorite
                                star.text = if (isFavorite) "★" else ""
                                lifecycleScope.launch {
                                    EchoDb.get(this@MainActivity).cards().setFavorite(card.id, isFavorite)
                                }
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                            else -> {
                                v.animate().translationX(0f).alpha(1f).setDuration(150).start()
                            }
                        }
                    }
                    dragging = false
                    touchMode = false
                    pageContainer.cardGestureActive = false
                    v.parent.requestDisallowInterceptTouchEvent(false)
                    true
                }
                else -> touchMode
            }
        }
    }

    private fun deleteCard(card: SpeechCard, view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
        stopPlayback()
        lifecycleScope.launch {
            EchoDb.get(this@MainActivity).cards().delete(card.id)
            card.audioPath?.let { path -> try { File(path).delete() } catch (_: Exception) {} }
        }
    }

    // Raw 16 kHz / mono / 16-bit PCM playback of a card's saved recording.
    private var playThread: Thread? = null
    @Volatile private var isPlaying = false
    @Volatile private var playingCardId: Long? = null

    private fun playCard(card: SpeechCard) {
        val path = card.audioPath
        if (path == null) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists() || file.length() == 0L) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }

        stopPlayback()
        isPlaying = true
        playingCardId = card.id
        playThread = Thread {
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack(
                    AudioManager.STREAM_MUSIC,
                    16000,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, 4096),
                    AudioTrack.MODE_STREAM
                )
                track.play()
                file.inputStream().use { input ->
                    val buf = ByteArray(3200)
                    while (isPlaying) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        track.write(buf, 0, n)
                    }
                }
                track.stop()
                track.release()
            } catch (e: Exception) {
                android.util.Log.e("EchoPlayback", "Playback failed", e)
            } finally {
                isPlaying = false
                if (playingCardId == card.id) playingCardId = null
            }
        }
        playThread?.start()
    }

    private fun stopPlayback() {
        isPlaying = false
        try { playThread?.join(200) } catch (_: Exception) {}
        playThread = null
        playingCardId = null
    }

    override fun onStop() {
        stopPlayback()
        if (qaActive) stopLiveQA()
        super.onStop()
    }

    private fun refreshLoop() {
        lifecycleScope.launch {
            while (!isFinishing) {
                if (selectedTab == 0) {
                    if (currentSearchQuery.isBlank()) loadCards()
                    else filterCards(currentSearchQuery)
                }
                delay(2500)
            }
        }
    }

    private fun toggle() {
        val running = getPreferences(0).getBoolean("running", false)
        val intent = Intent(this, ListeningService::class.java).apply {
            action = if (running) "stop" else "start"
        }
        if (running) stopService(intent) else startForegroundService(intent)
        getPreferences(0).edit().putBoolean("running", !running).apply()
        isListening = !running
        applyFabListeningState(animated = true)
    }

    private fun applyFabListeningState(animated: Boolean) {
        val res = if (isListening) R.drawable.echo_recording else R.drawable.echo_idle
        fabButton.contentDescription = if (isListening) "Остановить запись" else "Начать запись"
        if (!animated) {
            fabButton.setImageResource(res)
            return
        }
        fabButton.animate()
            .scaleX(0.82f).scaleY(0.82f).alpha(0.55f)
            .setDuration(90)
            .withEndAction {
                fabButton.setImageResource(res)
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(170).start()
            }
            .start()
    }

    private fun attachFabGesture(fab: View) {
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (fabDraggingUp) return true
                if (manualRecording) stopManualRecording()
                else if (qaActive) stopLiveQA() else toggle()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!manualRecording && !qaActive) startLiveQA()
            }
        })
        var fabTouchActive = false
        val fabHitRadius = dp(76).toFloat()

        fab.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // The visual container is intentionally larger than the actual
                    // touch target. Ignore taps in the surrounding empty area so the
                    // tab bar and the ScrollView keep receiving their own gestures.
                    val cx = v.width / 2f
                    val cy = v.height / 2f
                    val x = event.x - cx
                    val y = event.y - cy
                    fabTouchActive = x * x + y * y <= fabHitRadius * fabHitRadius
                    if (!fabTouchActive) return@setOnTouchListener false
                    gesture.onTouchEvent(event)
                    fabDownX = event.rawX
                    fabDownY = event.rawY
                    fabDraggingUp = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fabTouchActive) return@setOnTouchListener false
                    gesture.onTouchEvent(event)
                    val dy = event.rawY - fabDownY
                    val dx = event.rawX - fabDownX
                    val pull = (-dy / dp(120).toFloat()).coerceIn(0f, 1.35f)

                    // Before activation the button follows the finger, as if the ring
                    // has a little elastic mass attached to it. The farther upward the
                    // finger travels, the more the object stretches toward the gesture.
                    if (!fabDraggingUp) {
                        val visualPull = pull.coerceIn(0f, 1f)
                        v.translationY = (dy * 0.58f).coerceAtLeast(-dp(58).toFloat())
                        v.scaleX = 1f + visualPull * 0.055f
                        v.scaleY = 1f + visualPull * 0.055f
                    }

                    if (!fabDraggingUp && dy < -dp(42) && abs(dy) > abs(dx) * 1.15f) {
                        fabDraggingUp = true
                        if (!manualRecording && !qaActive) startManualRecording()
                    }

                    if (fabDraggingUp) {
                        // Once the threshold is crossed, the ring takes the finger
                        // over instead of snapping away. It follows with a damped
                        // offset and grows slightly, giving the impression of a
                        // soft magnetic/elastic connection.
                        val ringPull = ((-dy - dp(42)) / dp(140).toFloat()).coerceIn(0f, 1f)
                        ringView.translationY = (-dp(10) - dp(48) * ringPull).toFloat()
                        ringView.scaleX = 1f + 0.075f * ringPull
                        ringView.scaleY = 1f + 0.075f * ringPull
                        v.translationY = (-dp(58)).toFloat()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!fabTouchActive) return@setOnTouchListener false
                    gesture.onTouchEvent(event)
                    fabTouchActive = false
                    if (fabDraggingUp) {
                        ringView.animate().translationY(0f).scaleX(1f).scaleY(1f)
                            .setDuration(260)
                            .setInterpolator(android.view.animation.OvershootInterpolator(1.15f))
                            .start()
                        v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(220).start()
                    } else {
                        v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(180).start()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun hasInternet(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun startManualRecording() {
        if (manualRecording || qaActive) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 5)
            Toast.makeText(this, "Разреши доступ к микрофону", Toast.LENGTH_SHORT).show()
            return
        }

        if (isListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
            getPreferences(0).edit().putBoolean("running", false).apply()
            isListening = false
        }

        manualRecording = true
        manualStartedAt = System.currentTimeMillis()
        manualAudioFile = File(filesDir, "offline_${manualStartedAt}.pcm")
        manualAudioOut = java.io.FileOutputStream(manualAudioFile)

        fabButton.animate().scaleX(0f).scaleY(0f).alpha(0f).setDuration(120).withEndAction {
            fabButton.visibility = View.INVISIBLE
            ringView.visibility = View.VISIBLE
            ringView.alpha = 0f
            ringView.translationY = -dp(10).toFloat()
            ringView.scaleX = 1.035f
            ringView.scaleY = 1.035f
            ringView.setMode(EchoRingView.MODE_LISTENING)
            ringView.start()
            ringView.animate().alpha(1f).setDuration(150).start()
        }.start()

        try { fabContainer.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) } catch (_: Exception) {}

        manualRecordThread = Thread {
            val minBuffer = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(6400, minBuffer))
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                runOnUiThread { Toast.makeText(this, "Не удалось открыть микрофон", Toast.LENGTH_SHORT).show(); stopManualRecording() }
                return@Thread
            }
            ar.startRecording()
            val buf = ShortArray(320)
            try {
                while (manualRecording) {
                    val n = ar.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                    if (n <= 0) continue
                    val bytes = ByteArray(n * 2)
                    var sum = 0.0
                    for (i in 0 until n) {
                        val sample = buf[i].toInt()
                        bytes[i * 2] = (sample and 255).toByte()
                        bytes[i * 2 + 1] = (sample shr 8).toByte()
                        val x = sample / 32768.0
                        sum += x * x
                    }
                    synchronized(manualFileLock) {
                        manualAudioOut?.write(bytes)
                    }
                    val level = (sqrt(sum / n) * 5.5).coerceIn(0.02, 1.0).toFloat()
                    runOnUiThread { if (manualRecording) ringView.setAudioLevel(level) }

                    if (System.currentTimeMillis() - manualStartedAt >= MAX_MANUAL_SEGMENT_MS) {
                        rotateManualSegment()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("EchoOffline", "Manual recording failed", e)
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }.also { it.start() }
    }

    private fun rotateManualSegment() {
        if (!manualRecording) return
        val finishedFile: File
        val finishedStartedAt: Long
        synchronized(manualFileLock) {
            finishedFile = manualAudioFile ?: return
            finishedStartedAt = manualStartedAt
            try { manualAudioOut?.flush() } catch (_: Exception) {}
            try { manualAudioOut?.close() } catch (_: Exception) {}

            val nextStartedAt = System.currentTimeMillis()
            manualStartedAt = nextStartedAt
            manualAudioFile = File(filesDir, "offline_${nextStartedAt}.pcm")
            manualAudioOut = java.io.FileOutputStream(manualAudioFile)
        }

        lifecycleScope.launch {
            if (finishedFile.exists() && finishedFile.length() > 0L) {
                EchoDb.get(this@MainActivity).cards().insert(
                    SpeechCard(
                        createdAt = finishedStartedAt,
                        text = "Ожидает отправки",
                        audioPath = finishedFile.absolutePath,
                        pendingUpload = true
                    )
                )
                loadCards()
                Toast.makeText(this@MainActivity, "29 минут · начата следующая запись", Toast.LENGTH_SHORT).show()
            } else {
                try { finishedFile.delete() } catch (_: Exception) {}
            }
        }
    }

    private fun stopManualRecording() {
        if (!manualRecording) return
        manualRecording = false
        try { manualRecordThread?.join(350) } catch (_: Exception) {}
        manualRecordThread = null
        synchronized(manualFileLock) {
            try { manualAudioOut?.flush() } catch (_: Exception) {}
            try { manualAudioOut?.close() } catch (_: Exception) {}
            manualAudioOut = null
        }
        ringView.setAudioLevel(0f)
        val file = manualAudioFile
        manualAudioFile = null
        if (file == null || !file.exists() || file.length() == 0L) {
            file?.delete()
            restoreFabAfterManual()
            return
        }
        lifecycleScope.launch {
            val id = EchoDb.get(this@MainActivity).cards().insert(
                SpeechCard(
                    createdAt = manualStartedAt,
                    text = "Ожидает отправки",
                    audioPath = file.absolutePath,
                    pendingUpload = true
                )
            )
            restoreFabAfterManual()
            if (hasInternet()) {
                Toast.makeText(this@MainActivity, "Запись сохранена · можно отправить на расшифровку", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@MainActivity, "Запись сохранена офлайн", Toast.LENGTH_SHORT).show()
            }
            loadCards()
        }
    }

    private fun restoreFabAfterManual() {
        ringView.setMode(EchoRingView.MODE_CLOSING)
        ringView.stop()
        ringView.animate().alpha(0f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(150).withEndAction {
            ringView.visibility = View.INVISIBLE
            fabButton.visibility = View.VISIBLE
            fabButton.alpha = 0f
            fabButton.scaleX = 0f
            fabButton.scaleY = 0f
            fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
            applyFabListeningState(animated = false)
        }.start()
    }

    private fun uploadOfflineCard(card: SpeechCard, button: View) {
        if (!hasInternet()) {
            Toast.makeText(this, "Интернет пока недоступен", Toast.LENGTH_SHORT).show()
            return
        }
        val path = card.audioPath
        if (path.isNullOrBlank()) {
            Toast.makeText(this, "Аудио недоступно", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(this, "Файл записи не найден", Toast.LENGTH_SHORT).show()
            return
        }
        button.isEnabled = false
        button.animate().rotationBy(360f).setDuration(650).start()
        lifecycleScope.launch {
            val result = Gemini.transcribeOfflinePcm(file)
            if (result.isSuccess) {
                EchoDb.get(this@MainActivity).cards().updateTranscription(card.id, result.getOrThrow(), false)
                Toast.makeText(this@MainActivity, "Расшифровка готова", Toast.LENGTH_SHORT).show()
                loadCards()
            } else {
                button.isEnabled = true
                Toast.makeText(this@MainActivity, "Не удалось отправить · попробуй позже", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Volatile private var qaActive = false
    @Volatile private var qaRecording = false
    private var qaRecordThread: Thread? = null
    private var qaOverlay: View? = null
    private var qaStatus: TextView? = null
    private var qaAnswer: TextView? = null

    // Live QA model audio playback (Gemini Live returns 24 kHz PCM mono).
    private var qaTrack: AudioTrack? = null
    private val qaTrackLock = Any()

    // Two AudioRecord sessions on the mic at once is unreliable across
    // devices -- pause background listening while a question is being asked,
    // and always resume it (if it was running) once the overlay closes.
    private var qaPausedBackgroundListening = false

    private fun startLiveQA() {
        qaActive = true
        // Haptic tick
        try {
            fabContainer.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        } catch (_: Exception) {}

        qaPausedBackgroundListening = getPreferences(0).getBoolean("running", false)
        if (qaPausedBackgroundListening) {
            stopService(Intent(this, ListeningService::class.java).apply { action = "stop" })
        }

        // Dot shrinks away → premium animated ring appears
        fabButton.animate()
            .scaleX(0f).scaleY(0f).alpha(0f)
            .setDuration(180)
            .withEndAction {
                fabButton.visibility = View.INVISIBLE
                ringView.visibility = View.VISIBLE
                ringView.alpha = 0f
                ringView.animate().alpha(1f).setDuration(220).start()
                ringView.setMode(EchoRingView.MODE_CONNECTING)
                ringView.start()
            }
            .start()

        showQaPanel()
        ensureQaTrack()

        lifecycleScope.launch {
            val context = LiveQaContext.build(this@MainActivity)
            val ready = LiveQA.start(
                systemContext = context,
                onAnswerChunk = { pcm ->
                    writeQaAudio(pcm)
                    runOnUiThread {
                        ringView.setMode(EchoRingView.MODE_RESPONDING)
                        qaStatus?.text = "Эхо отвечает..."
                    }
                },
                onSubtitleChunk = { text ->
                    runOnUiThread { qaAnswer?.append(text) }
                },
                onTurnComplete = {
                    runOnUiThread {
                        ringView.setMode(EchoRingView.MODE_LISTENING)
                        qaStatus?.text = "Слушаю…"
                    }
                }
            )
            if (!qaActive) return@launch
            if (!ready) {
                runOnUiThread { qaStatus?.text = "Не удалось подключиться" }
                return@launch
            }
            runOnUiThread {
                ringView.setMode(EchoRingView.MODE_LISTENING)
                qaStatus?.text = "Слушаю…"
            }
            beginQaRecording()
        }
    }

    private fun stopLiveQA() {
        qaActive = false
        qaRecording = false
        LiveQA.stop()
        releaseQaTrack()
        closeQaPanel()
        // Animated ring → dot
        ringView.setAudioLevel(0f)
        ringView.setMode(EchoRingView.MODE_CLOSING)
        ringView.stop()
        ringView.animate()
            .alpha(0f)
            .setDuration(180)
            .withEndAction {
                ringView.visibility = View.INVISIBLE
                fabButton.visibility = View.VISIBLE
                fabButton.alpha = 0f
                fabButton.scaleX = 0f
                fabButton.scaleY = 0f
                fabButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(200).start()
                applyFabListeningState(animated = false)
            }
            .start()
        if (qaPausedBackgroundListening) {
            qaPausedBackgroundListening = false
            startForegroundService(Intent(this, ListeningService::class.java).apply { action = "start" })
        }
    }

    private fun ensureQaTrack() {
        synchronized(qaTrackLock) {
            if (qaTrack != null) return
            // Gemini Live AUDIO modality delivers 24 kHz 16-bit mono PCM.
            val sampleRate = 24000
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack(
                AudioManager.STREAM_MUSIC,
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4800),
                AudioTrack.MODE_STREAM
            )
            track.play()
            qaTrack = track
        }
    }

    private fun writeQaAudio(pcm: ByteArray) {
        if (pcm.isEmpty()) return
        synchronized(qaTrackLock) {
            val track = qaTrack ?: return
            try {
                track.write(pcm, 0, pcm.size)
            } catch (e: Exception) {
                android.util.Log.e("EchoLiveQA", "writeQaAudio failed", e)
            }
        }
    }

    private fun releaseQaTrack() {
        synchronized(qaTrackLock) {
            try {
                qaTrack?.stop()
            } catch (_: Exception) {}
            try {
                qaTrack?.release()
            } catch (_: Exception) {}
            qaTrack = null
        }
    }

    private fun beginQaRecording() {
        qaRecording = true
        qaRecordThread = Thread {
            val minBuf = AudioRecord.getMinBufferSize(
                16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(6400, minBuf)
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                return@Thread
            }
            ar.startRecording()
            try {
                val buf = ShortArray(320)
                while (qaRecording) {
                    val n = ar.read(buf, 0, buf.size)
                    if (n <= 0) continue
                    // Drive the Live QA ring from the real microphone energy.
                    // RMS is normalized to 0..1 and smoothed inside EchoRingView.
                    var sumSquares = 0.0
                    for (k in 0 until n) {
                        val sample = buf[k].toDouble() / 32768.0
                        sumSquares += sample * sample
                    }
                    val rms = sqrt(sumSquares / n.coerceAtLeast(1))
                    val voiceLevel = (rms * 7.5).coerceIn(0.0, 1.0).toFloat()
                    runOnUiThread {
                        ringView.setAudioLevel(if (LiveQA.modelSpeaking) 0f else voiceLevel)
                    }

                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val s = buf[k].toInt()
                        bytes[k * 2] = (s and 0xff).toByte()
                        bytes[k * 2 + 1] = (s shr 8).toByte()
                    }
                    LiveQA.sendAudio(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
            }
        }
        qaRecordThread?.start()
    }

    // filterCards: re-renders the cards list filtered by query (case-insensitive substring match).
    // Empty query restores the full list for the current tab.
    private fun filterCards(query: String) {
        if (query.isEmpty()) {
            when (selectedTab) {
                0 -> loadCards()
                1 -> loadAnalysis()
                2 -> loadMemory()
            }
            return
        }
        lifecycleScope.launch {
            val db = EchoDb.get(this@MainActivity)
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            val lower = query.lowercase()
            val results = db.cards().all().filter { it.text.lowercase().contains(lower) }
            cards.removeAllViews()
            if (results.isEmpty()) {
                addEmpty("Ничего не найдено по запросу «$query»")
                return@launch
            }
            results.forEach { c ->
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(14), dp(16), dp(15))
                    background = rounded(panel, 16, stroke)
                }
                val headerRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val star = label(if (c.favorite) "★" else "", 14f, accent)
                headerRow.addView(
                    label(fmt.format(Date(c.createdAt)), 11f, muted).apply {
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        letterSpacing = 0.04f
                    },
                    LinearLayout.LayoutParams(0, -2, 1f)
                )
                headerRow.addView(star)
                card.addView(headerRow)
                card.addView(label(c.text, 15f, primaryText).apply {
                    setPadding(0, dp(8), 0, 0)
                    setLineSpacing(0f, 1.28f)
                })
                if (c.pendingUpload) {
                    val upload = ImageButton(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_upload_queue)
                        contentDescription = "Отправить запись"
                        background = rounded(Color.TRANSPARENT, 50)
                        setPadding(dp(6), dp(6), dp(6), dp(6))
                        setColorFilter(accent)
                        alpha = if (hasInternet()) 0.72f else 0.30f
                        setOnClickListener { uploadOfflineCard(c, this) }
                    }
                    val actionRow = FrameLayout(this@MainActivity).apply {
                        setPadding(0, dp(6), 0, 0)
                    }
                    actionRow.addView(upload, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.END))
                    card.addView(actionRow)
                }
                cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(10)
                })
                attachCardGestures(card, c, star)
            }
        }
    }

    // Bottom Live-QA sheet: edge-to-edge, sits under the 150dp blob.
    private fun showQaPanel() {
        val root = rootContainer

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(16) + navBarInset())
            background = rounded(panelElevated, 24)
            elevation = dp(16).toFloat()
            // Swipe down to close
            var downY = 0f
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downY = e.rawY; true }
                    MotionEvent.ACTION_MOVE -> {
                        val dy = e.rawY - downY
                        if (dy > 0) v.translationY = dy
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (e.rawY - downY > dp(80)) stopLiveQA()
                        else v.animate().translationY(0f).setDuration(160).start()
                        true
                    }
                    else -> false
                }
            }
        }

        val handle = View(this).apply {
            background = rounded(Color.parseColor("#4A5060"), 4)
        }
        panel.addView(handle, LinearLayout.LayoutParams(dp(40), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(12)
        })

        val status = label("Подключаюсь…", 13f, muted).apply {
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }
        val answer = label("", 16f, primaryText).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(10), 0, dp(8))
            setLineSpacing(0f, 1.35f)
        }
        val scroll = ScrollView(this).apply { addView(answer) }
        panel.addView(status)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Sheet height; blob sits fully above its top edge
        val panelH = (resources.displayMetrics.heightPixels * 0.38f).toInt().coerceAtLeast(dp(240))
        val params = FrameLayout.LayoutParams(-1, panelH, Gravity.BOTTOM)
        panel.translationY = panelH.toFloat()
        root.addView(panel, params)
        panel.bringToFront()
        fabContainer.bringToFront()

        // Lift FAB so the 150dp blob rests just above the sheet (not under it)
        val lift = (panelH - dp(20)).toFloat()
        fabContainer.bringToFront()
        fabContainer.elevation = dp(28).toFloat()
        fabContainer.animate()
            .translationY(-lift)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()

        panel.animate()
            .translationY(0f)
            .setDuration(280)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()

        qaPanel = panel
        qaOverlay = panel
        qaStatus = status
        qaAnswer = answer
    }

    private fun closeQaPanel() {
        val panel = qaPanel ?: return
        val h = panel.height.takeIf { it > 0 } ?: dp(300)
        panel.animate()
            .translationY(h.toFloat())
            .setDuration(220)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction { (panel.parent as? ViewGroup)?.removeView(panel) }
            .start()
        // Return FAB to resting position
        fabContainer.animate()
            .translationY(0f)
            .setDuration(220)
            .start()
        qaPanel = null
        qaOverlay = null
        qaStatus = null
        qaAnswer = null
    }

    private object ColorDrawableCompat {
        operator fun invoke(color: Int) = android.graphics.drawable.ColorDrawable(color)
    }
}

/**
 * Premium animated Echo ring used for Live QA.
 *
 * The old organic blob is intentionally removed. The ring combines:
 *  - a soft luminous halo,
 *  - a clean white/cyan core ring,
 *  - counter-rotating orbital filaments,
 *  - a breathing center pulse,
 *  - subtle circumference modulation that reacts to animation time.
 */
class EchoRingView(context: android.content.Context) : View(context) {
    companion object {
        const val MODE_CONNECTING = 0
        const val MODE_LISTENING = 1
        const val MODE_RESPONDING = 2
        const val MODE_CLOSING = 3
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#65D8FF")
    }
    private val filamentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = android.graphics.BlurMaskFilter(18f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        maskFilter = android.graphics.BlurMaskFilter(7f, android.graphics.BlurMaskFilter.Blur.NORMAL)
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private var phase = 0f
    private var running = false
    private var mode = MODE_CONNECTING
    private var modeBlend = 0f
    private var targetModeBlend = 0f
    @Volatile private var targetAudioLevel = 0f
    private var audioLevel = 0f

    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            val modeSpeed = if (mode == MODE_RESPONDING) 0.075f else 0.045f
            phase += modeSpeed + audioLevel * if (mode == MODE_RESPONDING) 0.16f else 0.11f
            audioLevel += (targetAudioLevel - audioLevel) * 0.16f
            modeBlend += (targetModeBlend - modeBlend) * 0.10f
            invalidate()
            postOnAnimation(this)
        }
    }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
    }

    fun setAudioLevel(level: Float) {
        targetAudioLevel = level.coerceIn(0f, 1f)
    }

    fun setMode(newMode: Int) {
        mode = newMode
        targetModeBlend = when (newMode) {
            MODE_RESPONDING -> 1f
            MODE_CLOSING -> 0f
            else -> 0f
        }
        invalidate()
    }

    fun start() {
        running = true
        removeCallbacks(frame)
        postOnAnimation(frame)
    }

    fun stop() {
        running = false
        targetAudioLevel = 0f
        audioLevel = 0f
        removeCallbacks(frame)
        invalidate()
    }

    private fun mixColor(a: Int, b: Int, t: Float): Int {
        val x = t.coerceIn(0f, 1f)
        val ar = Color.red(a); val ag = Color.green(a); val ab = Color.blue(a)
        val br = Color.red(b); val bg = Color.green(b); val bb = Color.blue(b)
        return Color.rgb(
            (ar + (br - ar) * x).toInt(),
            (ag + (bg - ag) * x).toInt(),
            (ab + (bb - ab) * x).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val size = kotlin.math.min(width, height).toFloat()
        if (size <= 0f) return

        // The same object morphs between listening and answering instead of
        // replacing the view. This keeps the animation continuous.
        val response = modeBlend
        val breath = 0.5f + 0.5f * kotlin.math.sin(phase * if (mode == MODE_RESPONDING) 1.75f else 1.55f)
        val voice = audioLevel * (0.72f + 0.28f * breath)
        val responsePulse = if (mode == MODE_RESPONDING) 0.16f + 0.12f * breath else 0f
        val energy = (voice + responsePulse).coerceIn(0f, 1f)

        val baseR = size * 0.335f
        val r = baseR * (1f + 0.025f * breath + 0.095f * voice + 0.035f * response)

        val listenCyan = Color.parseColor("#65D8FF")
        val responseCyan = Color.parseColor("#B18CFF")
        val responseGlow = Color.parseColor("#8A6BFF")
        val filamentColor = mixColor(listenCyan, responseCyan, response)
        val glowColor = mixColor(Color.parseColor("#55D8FF"), responseGlow, response)

        // Deep halo: slow breathing at idle, larger and brighter during speech
        // or model output.
        glowPaint.color = glowColor
        glowPaint.strokeWidth = size * (0.075f + 0.055f * energy)
        glowPaint.alpha = (38 + 132 * energy + 18 * breath).toInt().coerceAtMost(205)
        canvas.drawCircle(cx, cy, r, glowPaint)

        // A second halo gives the response state a softer, more dimensional bloom.
        if (response > 0.02f) {
            glowPaint.strokeWidth = size * (0.035f + 0.025f * response)
            glowPaint.alpha = (24 + 90 * response).toInt()
            canvas.drawCircle(cx, cy, r * (1.055f + 0.018f * breath), glowPaint)
        }

        // White core stays recognizable as Echo's identity.
        corePaint.color = mixColor(Color.parseColor("#F7FBFF"), Color.parseColor("#F1ECFF"), response)
        corePaint.strokeWidth = size * (0.068f + 0.016f * voice)
        corePaint.alpha = 246
        canvas.drawCircle(cx, cy, r, corePaint)

        cyanPaint.color = filamentColor
        cyanPaint.strokeWidth = size * (0.011f + 0.008f * energy)
        cyanPaint.alpha = (175 + 75 * energy).toInt()
        canvas.drawCircle(cx, cy, r - size * 0.055f, cyanPaint)

        // Seven counter-rotating filaments. During a response they tighten into
        // a faster orbit, creating a visible but smooth change of personality.
        val filamentR = r - size * 0.01f
        filamentPaint.color = filamentColor
        for (i in 0 until 7) {
            val direction = if (i % 2 == 0) 1f else -1f
            val speedBase = if (mode == MODE_RESPONDING) 0.66f else 0.42f
            val speed = speedBase + i * 0.065f + energy * (1.15f + i * 0.12f)
            val rotation = Math.toDegrees((phase * direction * speed).toDouble()).toFloat()
            val weave = kotlin.math.sin(phase * 1.1f + i)
            val sweep = 105f + 20f * weave + 48f * voice + 18f * response
            val start = rotation + i * 51f + 10f * weave * energy

            filamentPaint.strokeWidth = size * (0.0075f + i * 0.0010f + 0.004f * energy)
            filamentPaint.alpha = (82 + i * 18 + 85 * energy + 20 * response).toInt().coerceAtMost(240)
            canvas.save()
            canvas.rotate(start, cx, cy)
            canvas.drawArc(
                cx - filamentR, cy - filamentR,
                cx + filamentR, cy + filamentR,
                18f, sweep, false, filamentPaint
            )
            canvas.restore()
        }

        // Inner woven threads move more delicately, preventing a mechanical spinner look.
        for (i in 0 until 5) {
            val rr = r - size * (0.040f + i * 0.024f)
            val direction = if (i % 2 == 0) -1f else 1f
            val start = direction * Math.toDegrees((phase * (0.45f + response * 0.45f)).toDouble()).toFloat() + i * 72f
            filamentPaint.strokeWidth = size * (0.0045f + 0.0035f * energy)
            filamentPaint.alpha = (55 + i * 15 + 70 * energy).toInt().coerceAtMost(190)
            canvas.drawArc(
                cx - rr, cy - rr, cx + rr, cy + rr,
                start, 45f + 35f * voice + 10f * breath + 12f * response, false, filamentPaint
            )
        }

        // Center becomes a quiet beacon while listening and a brighter pulse while Echo speaks.
        val pulse = size * (0.058f + 0.045f * voice + 0.018f * response + 0.012f * breath)
        innerGlowPaint.color = mixColor(Color.WHITE, responseCyan, response)
        innerGlowPaint.strokeWidth = size * (0.012f + 0.012f * energy)
        innerGlowPaint.alpha = (75 + 150 * energy).toInt().coerceAtMost(230)
        canvas.drawCircle(cx, cy, pulse, innerGlowPaint)

        centerPaint.color = mixColor(Color.WHITE, responseCyan, response)
        centerPaint.alpha = (150 + 95 * energy).toInt().coerceAtMost(245)
        canvas.drawCircle(cx, cy, pulse * (0.22f + 0.18f * energy), centerPaint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }
}
