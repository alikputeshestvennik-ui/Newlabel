package com.echo.app.wear

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private class SwipeFrameLayout(context: Context) : FrameLayout(context) {
    var onHorizontalSwipe: ((Boolean) -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var intercepting = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                intercepting = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (abs(dx) > 90f && abs(dx) > abs(dy) * 1.5f) {
                    intercepting = true
                    return true
                }
            }
        }
        return intercepting
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP && intercepting) {
            val dx = event.x - downX
            onHorizontalSwipe?.invoke(dx < 0f)
            intercepting = false
            return true
        }
        if (event.actionMasked == MotionEvent.ACTION_CANCEL) intercepting = false
        return true
    }
}

class WatchMainActivity : Activity() {
    private lateinit var root: SwipeFrameLayout
    private lateinit var pager: ViewFlipper
    private lateinit var recordRing: TextView
    private lateinit var status: TextView
    @Volatile private var recording = false
    private var output: OutputStream? = null
    private var channel: com.google.android.gms.wearable.ChannelClient.Channel? = null
    private var recordThread: Thread? = null
    private val handler = Handler(Looper.getMainLooper())
    private var downX = 0f
    private var downY = 0f
    private var cards: List<WatchCard> = emptyList()

    data class WatchCard(val id: Long, val text: String, val time: String, val favorite: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadCards()
    }

    override fun onResume() {
        super.onResume()
        loadCards()
    }

    private fun buildUi() {
        root = SwipeFrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        pager = ViewFlipper(this).apply { setInAnimation(this@WatchMainActivity, android.R.anim.fade_in); setOutAnimation(this@WatchMainActivity, android.R.anim.fade_out) }
        pager.addView(buildRecordScreen())
        pager.addView(buildCardsScreen())
        root.addView(pager, FrameLayout.LayoutParams(-1, -1))
        root.onHorizontalSwipe = { toCards ->
            pager.displayedChild = if (toCards) 1 else 0
            if (toCards) loadCards()
        }
        setContentView(root)
    }

    private fun buildRecordScreen(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 10, 14, 10)
        }
        val title = TextView(this).apply { text = "ECHO"; textSize = 10f; setTextColor(Color.GRAY); gravity = Gravity.CENTER }
        recordRing = TextView(this).apply {
            text = "○"
            textSize = 76f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setOnClickListener { if (recording) stopRecording() else startRecording() }
        }
        status = TextView(this).apply { text = "Тап — запись · смахни влево → карточки"; textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        box.addView(title, LinearLayout.LayoutParams(-1, 28))
        box.addView(recordRing, LinearLayout.LayoutParams(-1, 0, 1f))
        box.addView(status, LinearLayout.LayoutParams(-1, 34))
        return box
    }

    private fun buildCardsScreen(): View {
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10, 8, 10, 8) }
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = TextView(this).apply {
            text = "← ЗАПИСЬ"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(20, 20, 22))
            setOnClickListener { pager.displayedChild = 0 }
        }
        val header = TextView(this).apply {
            text = "КАРТОЧКИ"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        nav.addView(back, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(header, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(Space(this), LinearLayout.LayoutParams(0, 1))
        list.addView(nav, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(list)
        scroll.tag = list
        return scroll
    }

    private fun loadCards() {
        val json = getSharedPreferences("watch", Context.MODE_PRIVATE).getString("cards", "[]") ?: "[]"
        val parsed = mutableListOf<WatchCard>()
        try {
            val arr = org.json.JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                parsed += WatchCard(o.getLong("id"), o.getString("text"), o.getString("time"), o.getBoolean("favorite"))
            }
        } catch (_: Exception) { }
        cards = parsed
        val scroll = pager.getChildAt(1) as? ScrollView ?: return
        val list = scroll.tag as? LinearLayout ?: return
        if (list.childCount > 1) list.removeViews(1, list.childCount - 1)
        if (cards.isEmpty()) {
            list.addView(TextView(this).apply { text = "Нет карточек"; textSize = 14f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(8, 60, 8, 60) })
            return
        }
        cards.forEach { card ->
            val row = TextView(this).apply {
                text = (if (card.favorite) "★ " else "") + card.text + "\n" + card.time
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(12, 12, 12, 12)
                setBackgroundColor(Color.rgb(20, 20, 22))
                setOnClickListener { WatchDataService.sendAction(this@WatchMainActivity, card.id, "favorite") ; handler.postDelayed({ loadCards() }, 250) }
                setOnLongClickListener { WatchDataService.sendAction(this@WatchMainActivity, card.id, "delete"); handler.postDelayed({ loadCards() }, 250); true }
            }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 7; list.addView(row, lp)
        }
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        Thread {
            try {
                runBlocking {
                    val nodes = Wearable.getNodeClient(this@WatchMainActivity).connectedNodes.await()
                    val node = nodes.firstOrNull() ?: throw IllegalStateException("Телефон не подключён")
                    val path = "/echo/manual-audio/" + System.currentTimeMillis()
                    val ch = Wearable.getChannelClient(this@WatchMainActivity).openChannel(node.id, path).await()
                    val out = Wearable.getChannelClient(this@WatchMainActivity).getOutputStream(ch).await()
                    val min = AudioRecord.getMinBufferSize(
                        16000,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    val buffer = ByteArray(maxOf(min, 2048))
                    val recorder = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        16000,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        buffer.size * 2
                    )
                    channel = ch
                    output = out
                    recording = true
                    runOnUiThread {
                        recordRing.text = "●"
                        recordRing.setTextColor(Color.rgb(255, 90, 90))
                        status.text = "Идёт запись"
                    }
                    recorder.startRecording()
                    recordThread = Thread {
                        try {
                            while (recording) {
                                val n = recorder.read(buffer, 0, buffer.size)
                                if (n > 0) out.write(buffer, 0, n)
                            }
                        } catch (_: Exception) { }
                        try { recorder.stop() } catch (_: Exception) { }
                        recorder.release()
                    }.also { it.start() }
                }
            } catch (_: Exception) {
                runOnUiThread { status.text = "Телефон не подключён" }
            }
        }.start()
    }

    private fun stopRecording() {
        recording = false
        val t = recordThread
        try { t?.join(1200) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        try { output?.flush() } catch (_: Exception) { }
        try { output?.close() } catch (_: Exception) { }
        val ch = channel
        if (ch != null) {
            try { Wearable.getChannelClient(this).close(ch) } catch (_: Exception) { }
        }
        output = null
        channel = null
        recordThread = null
        recordRing.text = "○"
        recordRing.setTextColor(Color.WHITE)
        status.text = "Передано телефону · готово"
    }
}
