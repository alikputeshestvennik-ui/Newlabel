package com.echo.app

import android.app.*
import android.content.*
import android.media.*
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.LinkedBlockingQueue

/**
 * Continuous Live transcription without VAD.
 *
 * Rules (product):
 * - One card == one continuous recording segment
 * - Transcript is written to the card in-flight (interim + final chunks)
 * - Automatic hard split every 10 minutes (session + card boundary)
 * - No silence-based segmentation
 */
class ListeningService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var running = false
    private var source = "phone"
    private val watchAudioQueue = LinkedBlockingQueue<ByteArray>(64)

    private var activeCardId: Long = 0L
    private var activeAudioFile: File? = null
    private var activeAudioOut: FileOutputStream? = null
    private var segmentStartedAt: Long = 0L

    // Accumulated transcript text for the current card (interim is replaced in-place).
    private val transcriptLock = Any()
    private var committedText = StringBuilder()
    private var interimText = ""

    // 20 ms frames batched into ~100 ms Gemini chunks.
    private val sendBatch = ArrayList<ByteArray>(5)

    // Audio captured before the Live handshake completes.
    private val networkBacklog = ArrayList<ByteArray>()

    // gemini-3.5-transcribe-live hard-closes after ~10 min; we split a bit earlier.
    private val SEGMENT_MS = 10L * 60L * 1000L

    override fun onCreate() {
        super.onCreate()
        startForeground(7, notification())
    }

    private fun notification(): Notification {
        val ch = NotificationChannel("echo", "Эхо", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)

        return Notification.Builder(this, "echo")
            .setContentTitle("Эхо слушает")
            .setContentText("Непрерывная расшифровка без VAD")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            running = false
            WearDataService.livePcmSink = null
            WearBridge.sendRecordingStop(this)
            Gemini.stopLive()
            stopSelf()
        } else if (!running) {
            source = intent?.getStringExtra("source") ?: "phone"
            running = true
            if (source == "watch") listenFromWatch() else listen()
        }
        return START_NOT_STICKY
    }

    private val onFinalTranscript: (String) -> Unit = onFinalTranscript@{ finalText ->
        if (finalText.isBlank()) return@onFinalTranscript
        val cardId = activeCardId
        if (cardId == 0L) return@onFinalTranscript
        synchronized(transcriptLock) {
            if (committedText.isNotEmpty()) committedText.append(' ')
            committedText.append(finalText.trim())
            interimText = ""
            val snapshot = committedText.toString()
            scope.launch {
                try {
                    EchoDb.get(this@ListeningService).cards().updateText(cardId, snapshot)
                    sendBroadcast(
                        Intent(WearDataService.ACTION_CARDS_CHANGED).setPackage(packageName)
                    )
                } catch (e: Exception) {
                    Log.e("EchoService", "Failed to persist final transcript", e)
                }
            }
        }
    }

    // Throttle in-flight UI updates so the phone list does not flicker.
    @Volatile private var lastInterimUiAt = 0L

    private val onInterimTranscript: (String) -> Unit = onInterimTranscript@{ interim ->
        if (interim.isBlank()) return@onInterimTranscript
        val cardId = activeCardId
        if (cardId == 0L) return@onInterimTranscript
        val now = System.currentTimeMillis()
        synchronized(transcriptLock) {
            interimText = interim.trim()
            if (now - lastInterimUiAt < 450L) return@onInterimTranscript
            lastInterimUiAt = now
            val snapshot = buildDisplayText()
            scope.launch {
                try {
                    EchoDb.get(this@ListeningService).cards().updateText(cardId, snapshot)
                    sendBroadcast(
                        Intent(WearDataService.ACTION_CARDS_CHANGED).setPackage(packageName)
                    )
                } catch (_: Exception) { }
            }
        }
    }

    private fun buildDisplayText(): String {
        val base = committedText.toString()
        return when {
            interimText.isBlank() && base.isBlank() -> "Расшифровка..."
            interimText.isBlank() -> base
            base.isBlank() -> interimText
            else -> "$base $interimText"
        }
    }

    private suspend fun renewLiveSessionIfNeeded() {
        if (!Gemini.isConnected() || Gemini.needsRenewal()) {
            Log.d("EchoService", "Renewing Gemini Live session")
            Gemini.stopLive()
            if (!Gemini.startLive(onFinalTranscript, onInterimTranscript)) {
                Log.e("EchoService", "Live session renewal failed; will retry")
            }
        }
    }

    private fun sendOrBacklog(bytes: ByteArray) {
        if (Gemini.isConnected()) {
            if (networkBacklog.isNotEmpty()) {
                val backlog = ArrayList(networkBacklog)
                networkBacklog.clear()
                backlog.forEach { sendRealtimeChunk(it) }
            }
            sendRealtimeChunk(bytes)
        } else {
            networkBacklog.add(bytes)
        }
    }

    private suspend fun openNewSegment() {
        closeCurrentSegment(endSpeech = true)

        activeAudioFile = File(filesDir, "audio_${System.currentTimeMillis()}.pcm")
        activeAudioOut = FileOutputStream(activeAudioFile)
        segmentStartedAt = System.currentTimeMillis()
        synchronized(transcriptLock) {
            committedText = StringBuilder()
            interimText = ""
        }

        activeCardId = EchoDb.get(this@ListeningService)
            .cards()
            .insert(
                SpeechCard(
                    createdAt = segmentStartedAt,
                    text = "Расшифровка...",
                    audioPath = activeAudioFile!!.absolutePath
                )
            )

        sendBroadcast(Intent(WearDataService.ACTION_CARDS_CHANGED).setPackage(packageName))
        Log.d("EchoService", "Opened continuous card=$activeCardId")
    }

    private suspend fun closeCurrentSegment(endSpeech: Boolean) {
        val cardId = activeCardId
        if (cardId == 0L) return

        flushSendBatch()
        if (endSpeech) {
            try { Gemini.endSpeech() } catch (_: Exception) {}
        }

        try { activeAudioOut?.close() } catch (_: Exception) {}
        activeAudioOut = null
        activeAudioFile = null

        val finalDisplay = synchronized(transcriptLock) {
            interimText = ""
            val t = committedText.toString().trim()
            if (t.isBlank()) "Расшифровка..." else t
        }

        try {
            val dao = EchoDb.get(this@ListeningService).cards()
            if (finalDisplay == "Расшифровка...") {
                // Empty segment — drop the placeholder card.
                val card = dao.byId(cardId)
                card?.audioPath?.let { try { File(it).delete() } catch (_: Exception) {} }
                dao.delete(cardId)
            } else {
                dao.updateText(cardId, finalDisplay)
            }
            sendBroadcast(Intent(WearDataService.ACTION_CARDS_CHANGED).setPackage(packageName))
        } catch (e: Exception) {
            Log.e("EchoService", "Failed closing segment card=$cardId", e)
        }

        activeCardId = 0L
        segmentStartedAt = 0L
        synchronized(transcriptLock) {
            committedText = StringBuilder()
            interimText = ""
        }
    }

    private fun listenFromWatch() {
        scope.launch {
            watchAudioQueue.clear()
            WearDataService.livePcmSink = { bytes ->
                if (running) watchAudioQueue.offer(bytes)
            }
            try {
                val connecting = async { Gemini.startLive(onFinalTranscript, onInterimTranscript) }
                openNewSegment()
                WearBridge.sendRecordingStart(this@ListeningService, "watch-live")
                if (!connecting.await()) {
                    Log.e("EchoService", "Could not establish persistent Gemini Live session for watch")
                    return@launch
                }
                while (running) {
                    val bytes = watchAudioQueue.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                    if (segmentStartedAt > 0L && System.currentTimeMillis() - segmentStartedAt >= SEGMENT_MS) {
                        flushSendBatch()
                        Gemini.endSpeech()
                        openNewSegment()
                        Gemini.stopLive()
                        if (!Gemini.startLive(onFinalTranscript, onInterimTranscript)) break
                    }
                    appendAndSend(bytes)
                }
            } catch (e: Exception) {
                Log.e("EchoService", "Watch live failed", e)
            } finally {
                WearDataService.livePcmSink = null
                try { closeCurrentSegment(endSpeech = true) } catch (_: Exception) {}
                Gemini.stopLive()
                WearBridge.sendRecordingStop(this@ListeningService)
                watchAudioQueue.clear()
            }
        }
    }

    private fun listen() {
        scope.launch {
            val minBuffer = AudioRecord.getMinBufferSize(
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )

            val bufferBytes = maxOf(6400, minBuffer)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                16000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes
            )

            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                running = false
                return@launch
            }

            val ns = if (NoiseSuppressor.isAvailable()) {
                NoiseSuppressor.create(ar.audioSessionId)
            } else null

            val agc = if (AutomaticGainControl.isAvailable()) {
                AutomaticGainControl.create(ar.audioSessionId)
            } else null

            // Capture immediately; handshake runs concurrently.
            ar.startRecording()
            val connecting = async { Gemini.startLive(onFinalTranscript, onInterimTranscript) }
            var connectFailed = false

            val buf = ShortArray(320) // 20 ms @ 16 kHz

            try {
                openNewSegment()

                while (running) {
                    val n = ar.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                    if (n <= 0) continue

                    if (!connectFailed && connecting.isCompleted && !connecting.getCompleted()) {
                        Log.e("EchoService", "Could not establish persistent Gemini Live session")
                        connectFailed = true
                        running = false
                        continue
                    }

                    val bytes = ByteArray(n * 2)
                    for (k in 0 until n) {
                        val sample = buf[k].toInt()
                        bytes[k * 2] = (sample and 0xff).toByte()
                        bytes[k * 2 + 1] = (sample shr 8).toByte()
                    }

                    // Auto-split every 10 minutes: new card + renewed Live session.
                    if (segmentStartedAt > 0L &&
                        System.currentTimeMillis() - segmentStartedAt >= SEGMENT_MS
                    ) {
                        Log.d("EchoService", "10-minute split — rotating card")
                        if (connecting.isCompleted) {
                            renewLiveSessionIfNeeded()
                        }
                        openNewSegment()
                    } else if (connecting.isCompleted) {
                        renewLiveSessionIfNeeded()
                    }

                    appendAndSend(bytes)
                }
            } finally {
                try { ar.stop() } catch (_: Exception) {}
                ar.release()
                ns?.release()
                agc?.release()
                try {
                    closeCurrentSegment(endSpeech = true)
                } catch (_: Exception) {}
                connecting.cancel()
                networkBacklog.clear()
                Gemini.stopLive()
            }
        }
    }

    private fun appendAndSend(bytes: ByteArray) {
        try {
            activeAudioOut?.write(bytes)
        } catch (e: Exception) {
            Log.e("EchoService", "Failed writing audio to disk", e)
        }
        sendOrBacklog(bytes)
    }

    private fun sendRealtimeChunk(bytes: ByteArray) {
        sendBatch.add(bytes)
        if (sendBatch.size >= 5) flushSendBatch()
    }

    private fun flushSendBatch() {
        if (sendBatch.isEmpty()) return

        val total = sendBatch.sumOf { it.size }
        val merged = ByteArray(total)
        var offset = 0

        for (part in sendBatch) {
            part.copyInto(merged, offset)
            offset += part.size
        }

        if (!Gemini.sendAudio(merged)) {
            Log.e("EchoService", "Failed to send audio batch to persistent Gemini session")
        }

        sendBatch.clear()
    }

    override fun onDestroy() {
        running = false
        WearDataService.livePcmSink = null
        WearBridge.sendRecordingStop(this)
        Gemini.stopLive()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
