package com.echo.app.wear

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlin.math.sqrt

/**
 * Keeps the exact v9 ChannelClient/PCM transport, but moves the recorder into
 * a microphone foreground service so the watch can continue recording with
 * the display off or Activity paused.
 */
class WatchRecordingService : Service() {
    @Volatile private var recording = false
    private var liveMode = false
    private var output: java.io.OutputStream? = null
    private var channel: com.google.android.gms.wearable.ChannelClient.Channel? = null
    private var recordThread: Thread? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                liveMode = intent.getStringExtra(EXTRA_MODE) == MODE_LIVE
                startCapture()
            }
            ACTION_STOP -> stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        if (recording) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendState("error", "Нет доступа к микрофону")
            stopSelf()
            return
        }

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, notification())
        }

        Thread {
            try {
                runBlocking {
                    val nodes = Wearable.getNodeClient(this@WatchRecordingService).connectedNodes.await()
                    val node = nodes.firstOrNull() ?: throw IllegalStateException("Телефон не подключён")
                    val path = (if (liveMode) "/echo/live-audio/" else "/echo/manual-audio/") + System.currentTimeMillis()
                    val ch = Wearable.getChannelClient(this@WatchRecordingService).openChannel(node.id, path).await()
                    val out = Wearable.getChannelClient(this@WatchRecordingService).getOutputStream(ch).await()
                    val minBuffer = AudioRecord.getMinBufferSize(
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    val buffer = ByteArray(maxOf(minBuffer, 2048))
                    val recorder = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        SAMPLE_RATE,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        buffer.size * 2
                    )

                    channel = ch
                    output = out
                    recording = true
                    isRunning = true
                    sendState("started")
                    if (!liveMode) WatchDataService.sendRecordingState(this@WatchRecordingService, true, "watch")
                    recorder.startRecording()

                    recordThread = Thread {
                        try {
                            while (recording) {
                                val n = recorder.read(buffer, 0, buffer.size)
                                if (n > 0) {
                                    out.write(buffer, 0, n)
                                    var sum = 0.0
                                    var i = 0
                                    while (i + 1 < n) {
                                        val lo = buffer[i].toInt() and 0xff
                                        val hi = buffer[i + 1].toInt()
                                        val sample = (hi shl 8) or lo
                                        val signed = if (sample > 32767) sample - 65536 else sample
                                        val x = signed / 32768.0
                                        sum += x * x
                                        i += 2
                                    }
                                    val rms = if (n > 1) sqrt(sum / (n / 2)) else 0.0
                                    sendLevel((rms * 5.5).coerceIn(0.02, 1.0).toFloat())
                                }
                            }
                        } catch (_: Exception) { }
                        try { recorder.stop() } catch (_: Exception) { }
                        recorder.release()
                    }.also { it.start() }
                }
            } catch (e: Exception) {
                recording = false
                isRunning = false
                sendState("error", e.message ?: "Не удалось открыть канал")
                if (!liveMode) WatchDataService.sendRecordingState(this@WatchRecordingService, false, "watch")
                cleanupChannel()
                stopForegroundCompat()
                stopSelf()
            }
        }.start()
    }

    private fun stopCapture() {
        if (!recording && output == null && channel == null) {
            stopForegroundCompat()
            stopSelf()
            return
        }
        recording = false
        isRunning = false
        val t = recordThread
        try { t?.join(1200) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        try { output?.flush() } catch (_: Exception) { }
        try { output?.close() } catch (_: Exception) { }
        cleanupChannel()
        recordThread = null
        output = null
        sendState("stopped")
        if (!liveMode) WatchDataService.sendRecordingState(this, false, "watch")
        stopForegroundCompat()
        stopSelf()
    }

    private fun cleanupChannel() {
        val ch = channel
        if (ch != null) {
            try { Wearable.getChannelClient(this).close(ch) } catch (_: Exception) { }
        }
        channel = null
    }

    private fun sendLevel(level: Float) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra("state", "level").putExtra("level", level))
    }

    private fun sendState(state: String, message: String? = null) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).apply {
            putExtra("state", state)
            if (message != null) putExtra("message", message)
        })
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else @Suppress("DEPRECATION") stopForeground(true)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Запись Echo", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification =
        if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Echo записывает")
                .setContentText("Запись с микрофона часов продолжается")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Echo записывает")
                .setContentText("Запись с микрофона часов продолжается")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }

    override fun onDestroy() {
        if (recording || output != null || channel != null) stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.echo.app.wear.RECORD_START"
        const val ACTION_STOP = "com.echo.app.wear.RECORD_STOP"
        const val ACTION_STATE = "com.echo.app.wear.RECORD_STATE"
        const val EXTRA_MODE = "mode"
        const val MODE_OFFLINE = "offline"
        const val MODE_LIVE = "live"
        private const val CHANNEL_ID = "echo_watch_recording"
        private const val NOTIFICATION_ID = 71
        private const val SAMPLE_RATE = 16000

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
