package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object Gemini {

    private const val TAG = "EchoGemini"
    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    private val client = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var connected = false
    @Volatile private var setupReady = false
    private var setupLatch: CountDownLatch? = null
    private val sendLock = Any()

    // gemini-3.5-transcribe-live hard-closes any session after 10 minutes.
    // We proactively reconnect a bit earlier so background listening never
    // silently stops working mid-day.
    @Volatile private var sessionStartedAt: Long = 0L
    private const val MAX_SESSION_MS = 9 * 60 * 1000L

    fun isConnected(): Boolean = connected && setupReady

    fun needsRenewal(): Boolean =
        connected && setupReady && (System.currentTimeMillis() - sessionStartedAt) >= MAX_SESSION_MS

    // One persistent Live session is shared by all speech cards while listening.
    suspend fun startLive(onFinalTranscript: (String) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            if (connected && setupReady) return@withContext true

            val key = BuildConfig.GEMINI_API_KEY.trim()
            if (key.isBlank()) {
                Log.e(TAG, "GEMINI_API_KEY is empty")
                return@withContext false
            }

            val latch = CountDownLatch(1)
            setupLatch = latch

            fun handleServerMessage(text: String) {
                try {
                    val json = JSONObject(text)

                    if (json.has("setupComplete")) {
                        setupReady = true
                        setupLatch?.countDown()
                        Log.d(TAG, "Live setup complete")
                    }

                    val server = json.optJSONObject("serverContent") ?: return

                    server.optJSONObject("interimInputTranscription")
                        ?.optString("text")
                        ?.takeIf { it.isNotBlank() }
                        ?.let {
                            Log.d(TAG, "INTERIM: $it")
                        }

                    server.optJSONObject("inputTranscription")
                        ?.optString("text")
                        ?.takeIf { it.isNotBlank() }
                        ?.let {
                            Log.d(TAG, "FINAL: $it")
                            onFinalTranscript(it.trim())
                        }

                } catch (e: Exception) {
                    Log.e(TAG, "Cannot parse Live message: $text", e)
                }
            }

            val ws = client.newWebSocket(
                Request.Builder().url("$WS?key=$key").build(),
                object : WebSocketListener() {

                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        socket = webSocket
                        connected = true
                        setupReady = false
                        sessionStartedAt = System.currentTimeMillis()

                        val setup = JSONObject()
                            .put(
                                "setup",
                                JSONObject()
                                    .put("model", "models/gemini-3.5-transcribe-live")
                                    .put(
                                        "generationConfig",
                                        JSONObject().put(
                                            "responseModalities",
                                            JSONArray().put("TEXT")
                                        )
                                    )
                                    .put(
                                        "inputAudioTranscription",
                                        JSONObject()
                                            .put("languageCodes", JSONArray())
                                            .put("mode", "SMART")
                                    )
                            )

                        Log.d(TAG, "Live WebSocket opened; sending setup")
                        webSocket.send(setup.toString())
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        handleServerMessage(text)
                    }

                    // Gemini Live (BidiGenerateContent) sends server messages as
                    // binary WebSocket frames, not text frames. Without this override
                    // every response -- including setupComplete -- is silently dropped
                    // by WebSocketListener's default no-op implementation.
                    override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) {
                        handleServerMessage(bytes.utf8())
                    }

                    override fun onFailure(
                        webSocket: WebSocket,
                        t: Throwable,
                        response: Response?
                    ) {
                        Log.e(TAG, "Live WebSocket failure HTTP=${response?.code}", t)
                        connected = false
                        setupReady = false
                        setupLatch?.countDown()
                    }

                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                        Log.d(TAG, "Live WebSocket closed code=$code reason=$reason")
                        connected = false
                        setupReady = false
                    }
                }
            )

            socket = ws

            if (!latch.await(10, TimeUnit.SECONDS)) {
                Log.e(TAG, "Live setup timeout")
                ws.cancel()
                socket = null
                connected = false
                setupReady = false
                return@withContext false
            }

            setupReady
        }

    // Sends PCM continuously through the already-open Live session.
    // The caller supplies approximately 100 ms batches (or smaller final batches).
    fun sendAudio(chunk: ByteArray): Boolean {
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false

            val message = JSONObject()
                .put(
                    "realtimeInput",
                    JSONObject().put(
                        "audio",
                        JSONObject()
                            .put("mimeType", "audio/pcm;rate=16000")
                            .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
                    )
                )

            return ws.send(message.toString())
        }
    }

    // Ends only the current speech turn. The WebSocket stays alive for the next card.
    fun endSpeech(): Boolean {
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false

            Log.d(TAG, "Ending current speech turn")
            return ws.send(
                JSONObject()
                    .put(
                        "realtimeInput",
                        JSONObject().put("audioStreamEnd", true)
                    )
                    .toString()
            )
        }
    }

    fun stopLive() {
        synchronized(sendLock) {
            socket?.close(1000, "listening stopped")
            socket = null
            connected = false
            setupReady = false
            setupLatch = null
        }
    }

    // Shared one-shot (non-Live) text generation call used both for structured
    // fact extraction (JSON) and free-form creative text (the day digest).
    private suspend fun generateContent(prompt: String, jsonMode: Boolean): String =
        withContext(Dispatchers.IO) {
            val key = BuildConfig.GEMINI_API_KEY.trim()
            if (key.isBlank()) return@withContext ""

            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", prompt))
                        )
                    )
                )

            if (jsonMode) {
                body.put(
                    "generationConfig",
                    JSONObject().put("responseMimeType", "application/json")
                )
            }

            val request = Request.Builder()
                .url(
                    "https://generativelanguage.googleapis.com/v1beta/models/" +
                        "gemini-3.5-flash-lite:generateContent?key=$key"
                )
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext ""

                val responseBody = response.body?.string() ?: return@withContext ""
                val json = JSONObject(responseBody)

                json.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
            }
        }

    // Structured fact extraction for long-term memory (strict JSON).
    suspend fun extract(prompt: String): String = generateContent(prompt, jsonMode = true)

    // Free-form creative text -- used for the "Анализ дня" digest.
    suspend fun summarize(prompt: String): String = generateContent(prompt, jsonMode = false)

    // Offline/manual recordings are uploaded later as a normal audio request.
    // Small WAV payloads are sent inline; Gemini's GenerateContent API accepts
    // inline audio, while larger files should use the Files API. We keep the
    // local recorder conservative and reject payloads that would exceed the
    // inline request budget rather than silently losing the recording.
    suspend fun transcribeOfflinePcm(pcmFile: java.io.File, expectedSpeakers: Int = 0): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                val key = BuildConfig.GEMINI_API_KEY.trim()
                if (key.isBlank()) return@withContext Result.failure(IllegalStateException("GEMINI_API_KEY is empty"))
                if (!pcmFile.exists() || pcmFile.length() <= 0L) {
                    return@withContext Result.failure(IllegalArgumentException("Audio file is empty"))
                }

                val wav = pcmToWav(pcmFile)
                try {
                    val size = wav.length()
                    val startBody = JSONObject().put(
                        "file",
                        JSONObject().put("display_name", wav.name)
                    )
                    val startRequest = Request.Builder()
                        .url("https://generativelanguage.googleapis.com/upload/v1beta/files")
                        .header("x-goog-api-key", key)
                        .header("X-Goog-Upload-Protocol", "resumable")
                        .header("X-Goog-Upload-Command", "start")
                        .header("X-Goog-Upload-Header-Content-Length", size.toString())
                        .header("X-Goog-Upload-Header-Content-Type", "audio/wav")
                        .post(startBody.toString().toRequestBody("application/json".toMediaType()))
                        .build()

                    val uploadUrl = client.newCall(startRequest).execute().use { response ->
                        if (!response.isSuccessful) {
                            val raw = response.body?.string().orEmpty()
                            Log.e(TAG, "Files API start HTTP ${response.code}: $raw")
                            return@withContext Result.failure(IllegalStateException("Upload start HTTP ${response.code}"))
                        }
                        response.header("X-Goog-Upload-URL")
                            ?: return@withContext Result.failure(IllegalStateException("Upload URL missing"))
                    }

                    val uploadRequest = Request.Builder()
                        .url(uploadUrl)
                        .header("Content-Length", size.toString())
                        .header("X-Goog-Upload-Offset", "0")
                        .header("X-Goog-Upload-Command", "upload, finalize")
                        .post(wav.asRequestBody("audio/wav".toMediaType()))
                        .build()

                    val fileUri = client.newCall(uploadRequest).execute().use { response ->
                        val raw = response.body?.string().orEmpty()
                        if (!response.isSuccessful) {
                            Log.e(TAG, "Files API upload HTTP ${response.code}: $raw")
                            return@withContext Result.failure(IllegalStateException("Upload HTTP ${response.code}"))
                        }
                        JSONObject(raw).optJSONObject("file")?.optString("uri").orEmpty()
                    }

                    if (fileUri.isBlank()) {
                        return@withContext Result.failure(IllegalStateException("Uploaded file URI missing"))
                    }

                    val audioConfig = JSONObject()
                    if (expectedSpeakers != 1) {
                        audioConfig.put("diarization", true)
                    }

                    // The API currently exposes diarization as an on/off feature,
                    // not as a hard speaker-count parameter. expectedSpeakers is
                    // therefore used as a hint in the instruction while the model
                    // performs the actual voice separation.
                    val hint = when {
                        expectedSpeakers in 2..4 ->
                            "Ожидаемое число спикеров: $expectedSpeakers. Используй эти данные как подсказку при разделении голосов, но не выдумывай спикеров."
                        expectedSpeakers == 1 ->
                            "В записи ожидается один спикер. Не разделяй речь на несколько спикеров."
                        else ->
                            "Автоматически определи разные голоса и корректно раздели их по спикерам."
                    }

                    val body = JSONObject()
                        .put(
                            "contents",
                            JSONArray().put(
                                JSONObject().put(
                                    "parts",
                                    JSONArray()
                                        .put(JSONObject().put("text", "$hint Точно расшифруй речь из этой аудиозаписи. Сохрани язык оригинала."))
                                        .put(
                                            JSONObject().put(
                                                "fileData",
                                                JSONObject()
                                                    .put("mimeType", "audio/wav")
                                                    .put("fileUri", fileUri)
                                            )
                                        )
                                )
                            )
                        )
                        .put("generationConfig", JSONObject().put("audioTranscriptionConfig", audioConfig))

                    val request = Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-transcribe:generateContent")
                        .header("x-goog-api-key", key)
                        .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                        .build()

                    client.newCall(request).execute().use { response ->
                        val raw = response.body?.string().orEmpty()
                        if (!response.isSuccessful) {
                            Log.e(TAG, "Offline transcription HTTP ${response.code}: $raw")
                            return@withContext Result.failure(IllegalStateException("HTTP ${response.code}"))
                        }
                        val json = JSONObject(raw)
                        val transcript = if (expectedSpeakers == 1) {
                            extractPlainTranscript(json)
                        } else {
                            extractSpeakerTranscript(json)
                        }
                        if (transcript.isBlank()) Result.failure(IllegalStateException("Пустая расшифровка"))
                        else Result.success(transcript)
                    }
                } finally {
                    // Keep the original PCM recording. Only the temporary WAV
                    // conversion is removed after upload/transcription.
                    wav.delete()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Offline transcription failed", e)
                Result.failure(e)
            }
        }

    private fun extractPlainTranscript(json: JSONObject): String {
        val candidates = json.optJSONArray("candidates") ?: return ""
        val parts = candidates.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        return buildString {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                val t = part.optString("text").orEmpty()
                if (t.isNotBlank()) append(t)
            }
        }.trim()
    }

    private fun extractSpeakerTranscript(json: JSONObject): String {
        val candidates = json.optJSONArray("candidates") ?: return extractPlainTranscript(json)
        val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return extractPlainTranscript(json)
        val parts = content.optJSONArray("parts") ?: return extractPlainTranscript(json)
        val turns = mutableListOf<Pair<String, StringBuilder>>()
        var fallback = StringBuilder()

        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val transcription = part.optJSONObject("audioTranscription") ?: continue
            val speaker = transcription.optString("speakerLabel").ifBlank { "spk_1" }
            val words = transcription.optJSONArray("words")
            if (words == null || words.length() == 0) continue
            val text = buildString {
                for (w in 0 until words.length()) {
                    val word = words.optJSONObject(w)?.optString("word").orEmpty()
                    if (word.isBlank()) continue
                    if (isNotEmpty()) append(' ')
                    append(word)
                }
            }.trim()
            if (text.isBlank()) continue
            val last = turns.lastOrNull()
            if (last != null && last.first == speaker) {
                if (last.second.isNotEmpty()) last.second.append(' ')
                last.second.append(text)
            } else {
                turns += speaker to StringBuilder(text)
            }
        }

        if (turns.isEmpty()) return extractPlainTranscript(json)
        return turns.joinToString("\n\n") { (speaker, text) ->
            val label = speaker.removePrefix("spk_").ifBlank { "1" }
            "Спикер $label: ${text.toString().trim()}"
        }.trim()
    }

    private fun pcmToWav(pcmFile: java.io.File): java.io.File {
        val wav = java.io.File(pcmFile.parentFile, pcmFile.nameWithoutExtension + ".wav")
        val dataLength = pcmFile.length()
        java.io.RandomAccessFile(wav, "rw").use { out ->
            out.setLength(0)
            out.write("RIFF".toByteArray(Charsets.US_ASCII))
            out.writeIntLE((36L + dataLength).toInt())
            out.write("WAVE".toByteArray(Charsets.US_ASCII))
            out.write("fmt ".toByteArray(Charsets.US_ASCII))
            out.writeIntLE(16)
            out.writeShortLE(1)
            out.writeShortLE(1)
            out.writeIntLE(16000)
            out.writeIntLE(16000 * 2)
            out.writeShortLE(2)
            out.writeShortLE(16)
            out.write("data".toByteArray(Charsets.US_ASCII))
            out.writeIntLE(dataLength.toInt())
            pcmFile.inputStream().use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    out.write(buffer, 0, n)
                }
            }
        }
        return wav
    }

    private fun java.io.RandomAccessFile.writeIntLE(v: Int) {
        write(byteArrayOf((v and 255).toByte(), ((v ushr 8) and 255).toByte(), ((v ushr 16) and 255).toByte(), ((v ushr 24) and 255).toByte()))
    }
    private fun java.io.RandomAccessFile.writeShortLE(v: Int) {
        write(byteArrayOf((v and 255).toByte(), ((v ushr 8) and 255).toByte()))
    }

}
