package com.echo.app

import android.content.Context
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object WearBridge {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    const val CARDS_PATH = "/echo/cards"
    const val ACTION_PATH = "/echo/card/action"
    const val AUDIO_PATH_PREFIX = "/echo/manual-audio/"
    const val LIVE_CONTROL_PATH = "/echo/live/control"
    const val LIVE_TEXT_PATH = "/echo/live/text"
    const val LIVE_AUDIO_PATH_PREFIX = "/echo/live-audio/"

    fun syncCards(context: Context, cards: List<SpeechCard>) {
        scope.launch {
            try {
                val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
                val arr = JSONArray()
                cards.take(50).forEach { c ->
                    arr.put(JSONObject().apply {
                        put("id", c.id)
                        put("text", c.text)
                        put("time", fmt.format(Date(c.createdAt)))
                        put("favorite", c.favorite)
                    })
                }
                val request = PutDataMapRequest.create(CARDS_PATH).apply {
                    dataMap.putString("json", arr.toString())
                    dataMap.putLong("updatedAt", System.currentTimeMillis())
                }.asPutDataRequest().setUrgent()
                Wearable.getDataClient(context.applicationContext).putDataItem(request)
            } catch (_: Exception) { }
        }
    }
}
