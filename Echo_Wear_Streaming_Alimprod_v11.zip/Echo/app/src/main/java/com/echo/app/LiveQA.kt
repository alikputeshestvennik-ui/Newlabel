package com.echo.app

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

// Independent Live session for conversational Q&A about the user's own history.
// Uses gemini-3.8-live with AUDIO output + outputAudioTranscription for subtitles.
//
// Echo cancellation strategy:
//   1. Android system AEC is applied at AudioRecord level in MainActivity
//      (MODE_IN_COMMUNICATION + AcousticEchoCanceler) — this is the primary defence.
//   2. modelSpeaking flag: while the model is streaming audio back we suppress
//      sending microphone chunks so VAD never sees our own speaker output.
//      The flag is cleared on turnComplete or interrupted.
object LiveQA {

    private const val TAG = "EchoLiveQA"
    private const val WS =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var connected = false
    @Volatile private var setupReady = false

    // True while the model is playing back audio — mic chunks are suppressed
    // during this window to prevent the speaker output re-entering the VAD.
    @Volatile var modelSpeaking: Boolean = false
        private set

    private var setupLatch: CountDownLatch? = null
    // Bumped on every start()/stop() so a late onClosed from a previous
    // socket cannot countDown the latch belonging to a newer attempt.
    @Volatile private var sessionGen: Int = 0
    private val sendLock = Any()

    fun isConnected(): Boolean = connected && setupReady

    // systemContext carries the 7-day transcripts + long-term memory + full
    // day-summary history.
    // onAnswerChunk   — audio PCM bytes arriving from the model (play these)
    // onSubtitleChunk — text transcript of the model's audio output (show as subtitles)
    // onTurnComplete  — model finished speaking this turn
    suspend fun start(
        systemContext: String,
        onAnswerChunk: (ByteArray) -> Unit,
        onSubtitleChunk: (String) -> Unit,
        onTurnComplete: () -> Unit,
        audioOutput: Boolean = true
    ): Boolean = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY.trim()
        if (key.isBlank()) {
            Log.e(TAG, "GEMINI_API_KEY is empty")
            return@withContext false
        }

        // Tear down any previous half-open session so we never race two sockets.
        stop()

        val myGen = ++sessionGen
        val latch = CountDownLatch(1)
        setupLatch = latch

        fun handleServerMessage(text: String) {
            try {
                val json = JSONObject(text)

                if (json.has("setupComplete")) {
                    if (sessionGen == myGen) {
                        setupReady = true
                        setupLatch?.countDown()
                        Log.d(TAG, "LiveQA setup complete")
                    }
                    return
                }

                val server = json.optJSONObject("serverContent") ?: return

                // Model interrupted itself (e.g. user spoke over it).
                // Clear speaking flag so mic resumes immediately.
                if (server.optBoolean("interrupted", false)) {
                    modelSpeaking = false
                    Log.d(TAG, "LiveQA interrupted by user speech")
                }

                // Audio chunks from the model — deliver to playback and suppress mic.
                server.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i) ?: continue
                        val inlineData = part.optJSONObject("inlineData")
                        if (inlineData != null && audioOutput) {
                            val b64 = inlineData.optString("data")
                            if (b64.isNotEmpty()) {
                                modelSpeaking = true
                                val pcm = Base64.decode(b64, Base64.NO_WRAP)
                                onAnswerChunk(pcm)
                            }
                        }
                        part.optString("text").takeIf { it.isNotBlank() }?.let(onSubtitleChunk)
                    }
                }

                // Output audio transcription (subtitles for the model's speech).
                server.optJSONObject("outputTranscription")
                    ?.optString("text")
                    ?.takeIf { it.isNotBlank() }
                    ?.let { onSubtitleChunk(it) }

                if (server.optBoolean("turnComplete", false)) {
                    modelSpeaking = false
                    onTurnComplete()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Cannot parse LiveQA message: $text", e)
            }
        }

        val ws = client.newWebSocket(
            Request.Builder().url("$WS?key=$key").build(),
            object : WebSocketListener() {

                override fun onOpen(webSocket: WebSocket, response: Response) {
                    socket = webSocket
                    connected = true
                    setupReady = false
                    modelSpeaking = false

                    // responseModalities stays in generationConfig (works for all Live models).
                    // outputAudioTranscription MUST be a top-level setup field, not nested
                    // under generationConfig — otherwise the server rejects the session
                    // without sending setupComplete.
                    val setup = JSONObject().put(
                        "setup",
                        JSONObject()
                            .put("model", "models/gemini-3.8-live")
                            .put(
                                "generationConfig",
                                JSONObject()
                                    .put("responseModalities", JSONArray().put(if (audioOutput) "AUDIO" else "TEXT"))
                            )
                            .put("outputAudioTranscription", JSONObject())
                            .put(
                                "systemInstruction",
                                JSONObject().put(
                                    "parts",
                                    JSONArray().put(JSONObject().put("text", systemContext))
                                )
                            )
                    )

                    Log.d(TAG, "LiveQA WebSocket opened; sending setup")
                    webSocket.send(setup.toString())
                }

                override fun onMessage(webSocket: WebSocket, text: String) =
                    handleServerMessage(text)

                override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) =
                    handleServerMessage(bytes.utf8())

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    Log.e(TAG, "LiveQA failure HTTP=${response?.code}", t)
                    if (sessionGen == myGen) {
                        connected = false
                        setupReady = false
                        modelSpeaking = false
                        setupLatch?.countDown()
                    }
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    Log.d(TAG, "LiveQA closed code=$code reason=$reason")
                    if (sessionGen == myGen) {
                        connected = false
                        setupReady = false
                        modelSpeaking = false
                        // Unblock start() if the server rejected setup without setupComplete.
                        setupLatch?.countDown()
                    }
                }
            }
        )

        socket = ws

        if (!latch.await(15, TimeUnit.SECONDS)) {
            Log.e(TAG, "LiveQA setup timeout (setupReady=$setupReady connected=$connected)")
            ws.cancel()
            socket = null
            connected = false
            setupReady = false
            return@withContext false
        }

        if (!setupReady) {
            Log.e(TAG, "LiveQA setup finished without setupComplete")
            ws.cancel()
            socket = null
            connected = false
            return@withContext false
        }

        Log.d(TAG, "LiveQA session ready")
        true
    }

    // Send mic PCM only when the model is NOT currently speaking.
    // Callers should also check LiveQA.modelSpeaking before calling to
    // avoid the lock overhead on every 20 ms frame, but the check here is
    // the authoritative gate.
    fun sendAudio(chunk: ByteArray): Boolean {
        if (modelSpeaking) return true  // silently drop — AEC layer 2
        synchronized(sendLock) {
            val ws = socket ?: return false
            if (!connected || !setupReady) return false

            val message = JSONObject().put(
                "realtimeInput",
                JSONObject().put(
                    "audio",
                    JSONObject()
                        .put("mimeType", "audio/pcm;rate=16000")
                        .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
                )
            )
            return ws.send(message.toString())
        }
    }

    fun stop() {
        synchronized(sendLock) {
            sessionGen++
            socket?.close(1000, "qa done")
            socket = null
            connected = false
            setupReady = false
            modelSpeaking = false
            setupLatch = null
        }
    }
}
