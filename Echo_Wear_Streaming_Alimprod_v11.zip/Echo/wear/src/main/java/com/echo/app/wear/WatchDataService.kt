package com.echo.app.wear

import android.content.Context
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataEventBuffer
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Wearable
import com.google.android.gms.wearable.WearableListenerService
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await

class WatchDataService : WearableListenerService() {
    override fun onDataChanged(events: DataEventBuffer) {
        events.forEach { event ->
            if (event.type == DataEvent.TYPE_CHANGED && event.dataItem.uri.path == "/echo/cards") {
                val json = DataMapItem.fromDataItem(event.dataItem).dataMap.getString("json", "[]")
                getSharedPreferences("watch", Context.MODE_PRIVATE).edit()
                    .putString("cards", json)
                    .apply()
            }
        }
    }

    override fun onMessageReceived(event: MessageEvent) {
        if (event.path == LIVE_TEXT_PATH) {
            try {
                val o = JSONObject(String(event.data, Charsets.UTF_8))
                getSharedPreferences("watch", Context.MODE_PRIVATE).edit()
                    .putString("liveKind", o.optString("kind"))
                    .putString("liveText", o.optString("text"))
                    .apply()
                sendBroadcast(android.content.Intent(ACTION_LIVE_UPDATE).setPackage(packageName))
            } catch (_: Exception) {}
        }
    }

    companion object {
        const val CARDS_PATH = "/echo/cards"
        const val ACTION_PATH = "/echo/card/action"
        const val LIVE_CONTROL_PATH = "/echo/live/control"
        const val LIVE_TEXT_PATH = "/echo/live/text"
        const val ACTION_LIVE_UPDATE = "com.echo.app.LIVE_UPDATE"

        fun sendLiveControl(context: Context, action: String) {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject().put("action", action).toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context).sendMessage(node.id, LIVE_CONTROL_PATH, payload).await()
                    } catch (_: Exception) {}
                }
            }.start()
        }

        fun sendAction(context: Context, id: Long, action: String) {
            Thread {
                runBlocking {
                    try {
                        val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                        val node = nodes.firstOrNull() ?: return@runBlocking
                        val payload = JSONObject().apply {
                            put("id", id)
                            put("action", action)
                        }.toString().toByteArray(Charsets.UTF_8)
                        Wearable.getMessageClient(context).sendMessage(node.id, ACTION_PATH, payload).await()
                    } catch (_: Exception) { }
                }
            }.start()
        }
    }
}
